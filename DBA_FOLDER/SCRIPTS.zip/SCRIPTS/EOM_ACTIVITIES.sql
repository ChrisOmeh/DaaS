=============================
EOM START
=============================
Initiate Finacle Full back after SOL CLOSURE usually 5pm
Recreate CUSTOM.UNLOCK_USER_REPLAT PROCEDURE using the new procedure from PRODUCTION TEAM(DAYO OR RICHARD)
Run ENABLE_USER_REPLATFORM JOB consistently as per request by PROD TEAM(Richard and Dayo)

From Ernest
@Omeh, Chukwuemeka C, I will also like to know transaction count in DTD(tbaadm.DAILY_TRAN_DETAIL_TABLE) before transaction movement to History.


=======================================
WORK ON CUSTOM.IDX_C_EIT_HIST TABLE
=======================================
drop LOG GROUP GGS_12219983 but create bkp before drop
select * from dba_log_groups
where LOG_GROUP_NAME = 'GGS_12219983';
DROP LOG GROUP GGS_12219983;

Rename INDEX 1 CUSTOM.IDX_C_EIT_HIST_31MAR2023
Rename INDEX 2 CUSTOM.IDX_C_EIT_HIST_LCHG_31MAR2023

select count(*) from CUSTOM.C_EIT_HIST; --206,050,207
====================================
RENAME THE TABLE CUSTOM.C_EIT_HIST
====================================
ALTER TABLE CUSTOM.C_EIT_HIST RENAME TO CUSTOM.C_EIT_HIST_31MAY2023;

====================================
RENAME THE INDEXES
====================================
Alter INDEX CUSTOM.IDX_C_EIT_HIST rename to IDX_C_EIT_HIST_31MAY2023;
Alter INDEX CUSTOM.IDX_C_EIT_HIST_LCHG rename to IDX_C_EIT_HIST_LCHG_31MAY2023;


==================================
CREATE THE TABLE CUSTOM.C_EIT_HIST
USING THE SCRIPT OF THE TABLE
--Change to date accordingly
--Once SOL closure is done and HBKOD starts. Extract the SQL script for the CUSTOM.C_EIT_HIST 
--Rename the table, rename the indexes, drop the loggroup file, then use the script to create the new table. Then login to putty on 17.93 
==================================

ALTER TABLE CUSTOM.C_EIT_HIST RENAME TO C_EIT_HIST_30APR2024;
ALTER TABLE CUSTOM.C_EIT_HIST_30APR2024 DROP SUPPLEMENTAL LOG GROUP GGS_12219983;

CREATE TABLE CUSTOM.C_EIT_HIST
(
  ENTITY_ID                       VARCHAR2(12 CHAR),
  ENTITY_TYPE                     VARCHAR2(5 CHAR),
  BOD_DATE                        DATE,
  ACCRUED_UPTO_DATE_CR            DATE,
  ACCRUED_UPTO_DATE_DR            DATE,
  LAST_ACCRUAL_RUN_DATE_CR        DATE,
  LAST_ACCRUAL_RUN_DATE_DR        DATE,
  BOOKED_UPTO_DATE_CR             DATE,
  BOOKED_UPTO_DATE_DR             DATE,
  LAST_BOOK_RUN_DATE_CR           DATE,
  LAST_BOOK_RUN_DATE_DR           DATE,
  BOOK_FOR_REV_DATE_CR            DATE,
  BOOK_FOR_REV_DATE_DR            DATE,
  LAST_BOOK_CR_TRAN_ID            VARCHAR2(9 CHAR),
  LAST_BOOK_DR_TRAN_ID            VARCHAR2(9 CHAR),
  LAST_BOOK_CR_TAN_DATE           DATE,
  LAST_BOOK_DR_TAN_DATE           DATE,
  INTEREST_CALC_UPTO_DATE_CR      DATE,
  INTEREST_CALC_UPTO_DATE_DR      DATE,
  LAST_INTEREST_RUN_DATE_CR       DATE,
  LAST_INTEREST_RUN_DATE_DR       DATE,
  LAST_INT_CR_TRAN_ID             VARCHAR2(9 CHAR),
  LAST_INT_DR_TRAN_ID             VARCHAR2(9 CHAR),
  LAST_INT_CR_TRAN_DATE           DATE,
  LAST_INT_DR_TRAN_DATE           DATE,
  CUMM_CR_INT_ADJ_AMT             NUMBER(20,4),
  CUMM_DR_INT_ADJ_AMT             NUMBER(20,4),
  NEXT_INT_RUN_DATE_DR            DATE,
  TOT_INT_PAID_LAST_FY            NUMBER(20,4),
  TOT_INT_COLL_LAST_FY            NUMBER(20,4),
  TOT_DR_INT_ACC_LAST_FY          NUMBER(20,4),
  TOT_CR_INT_ACC_LAST_FY          NUMBER(20,4),
  NRML_ACCRUED_AMOUNT_CR          NUMBER(22,6),
  NRML_ACCRUED_AMOUNT_DR          NUMBER(22,6),
  NRML_BOOKED_AMOUNT_CR           NUMBER(22,6),
  NRML_BOOKED_AMOUNT_DR           NUMBER(22,6),
  NRML_INTEREST_AMOUNT_CR         NUMBER(22,6),
  NRML_INTEREST_AMOUNT_DR         NUMBER(22,6),
  NRML_ADV_INT_AMOUNT_CR          NUMBER(22,6),
  NRML_ADV_INT_AMOUNT_DR          NUMBER(22,6),
  NRML_AMORTIZED_AMOUNT_CR        NUMBER(22,6),
  NRML_AMORTIZED_AMOUNT_DR        NUMBER(22,6),
  NRML_INT_SUSPENSE_AMT_DR        NUMBER(22,6),
  PENAL_ACCRUED_AMOUNT_DR         NUMBER(22,6),
  PENAL_BOOKED_AMOUNT_DR          NUMBER(22,6),
  PENAL_INTEREST_AMOUNT_DR        NUMBER(22,6),
  PENAL_ADV_INT_AMOUNT_DR         NUMBER(22,6),
  PENAL_AMORTIZED_AMOUNT_DR       NUMBER(22,6),
  PENAL_INT_SUSPENSE_AMT_DR       NUMBER(22,6),
  ADDNL_ACCRUED_AMOUNT_DR         NUMBER(22,6),
  ADDNL_BOOKED_AMOUNT_DR          NUMBER(22,6),
  ADDNL_INTEREST_AMOUNT_DR        NUMBER(22,6),
  QIS_ACCRUED_AMOUNT_DR           NUMBER(22,6),
  QIS_BOOKED_AMOUNT_DR            NUMBER(22,6),
  QIS_INTEREST_AMOUNT_DR          NUMBER(22,6),
  STOCK_ACCRUED_AMOUNT_DR         NUMBER(22,6),
  STOCK_BOOKED_AMOUNT_DR          NUMBER(22,6),
  STOCK_INTEREST_AMOUNT_DR        NUMBER(22,6),
  OVDU_ACCRUED_AMOUNT_DR          NUMBER(22,6),
  OVDU_BOOKED_AMOUNT_DR           NUMBER(22,6),
  OVDU_INTEREST_AMOUNT_DR         NUMBER(22,6),
  NO_RECALC_BEFORE_DATE           DATE,
  CURR_ADV_INT_AMT                NUMBER(20,4),
  INT_DAILY_FACTOR                NUMBER(22,6),
  COMPINT_ACCRUED_AMOUNT_DR       NUMBER(22,6),
  COMPINT_BOOKED_AMOUNT_DR        NUMBER(22,6),
  COMPINT_INTEREST_AMOUNT_DR      NUMBER(22,6),
  PENALINT_ACCRUED_AMOUNT_DR      NUMBER(22,6),
  PENALINT_BOOKED_AMOUNT_DR       NUMBER(22,6),
  PENALINT_INTEREST_AMOUNT_DR     NUMBER(22,6),
  PENALPRNC_ACCRUED_AMOUNT_DR     NUMBER(22,6),
  PENALPRNC_BOOKED_AMOUNT_DR      NUMBER(22,6),
  PENALPRNC_INTEREST_AMOUNT_DR    NUMBER(22,6),
  COMPPRNC_ACCRUED_AMOUNT_DR      NUMBER(22,6),
  COMPPRNC_BOOKED_AMOUNT_DR       NUMBER(22,6),
  COMPPRNC_INTEREST_AMOUNT_DR     NUMBER(22,6),
  UNPAID_NRML_INT_AMOUNT_CR       NUMBER(22,6),
  LAST_NRML_BOOKED_AMOUNT_CR      NUMBER(22,6),
  LAST_NRML_BOOKED_AMOUNT_DR      NUMBER(22,6),
  LAST_PENAL_BOOKED_AMOUNT_DR     NUMBER(22,6),
  LAST_ADDNL_BOOKED_AMOUNT_DR     NUMBER(22,6),
  LAST_QIS_BOOKED_AMOUNT_DR       NUMBER(22,6),
  LAST_STOCK_BOOKED_AMOUNT_DR     NUMBER(22,6),
  LAST_OVDU_BOOKED_AMOUNT_DR      NUMBER(22,6),
  LAST_COMPINT_BOOKED_AMOUNT_DR   NUMBER(22,6),
  LAST_PENALINT_BOOKED_AMOUNT_DR  NUMBER(22,6),
  LAST_PENPRNC_BOOKED_AMOUNT_DR   NUMBER(22,6),
  LAST_COMPPRNC_BOOKED_AMOUNT_DR  NUMBER(22,6),
  COMPOUND_AMOUNT_CR              NUMBER(22,6),
  COMPOUND_DATE_CR                DATE,
  INTEREST_RATE                   NUMBER(9,6),
  LCHG_USER_ID                    VARCHAR2(15 CHAR),
  LCHG_TIME                       DATE,
  RCRE_USER_ID                    VARCHAR2(15 CHAR),
  RCRE_TIME                       DATE,
  BANK_ID                         VARCHAR2(8 CHAR),
  SUPPLEMENTAL LOG GROUP GGS_12219983 (ENTITY_ID,ENTITY_TYPE,BOD_DATE,BANK_ID) ALWAYS
)
NOCOMPRESS 
TABLESPACE CUSTOM_TBLS
PCTFREE    10
INITRANS   100
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING
PARTITION BY HASH (ENTITY_ID)
(  
  PARTITION TAB_C_EIT_HIST01_PT1
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_C_EIT_HIST02_PT2
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_C_EIT_HIST03_PT3
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_C_EIT_HIST04_PT4
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_C_EIT_HIST05_PT5
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_C_EIT_HIST06_PT6
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_C_EIT_HIST07_PT7
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_C_EIT_HIST08_PT8
    TABLESPACE CUSTOM_TBLS
)
NOCACHE
ENABLE ROW MOVEMENT;


CREATE UNIQUE INDEX CUSTOM.IDX_C_EIT_HIST30042024 ON CUSTOM.C_EIT_HIST
(ENTITY_ID, ENTITY_TYPE, BOD_DATE, BANK_ID)
LOGGING
TABLESPACE CUSTOM_IDXSPACE
PCTFREE    10
INITRANS   50
MAXTRANS   255
STORAGE    (
            INITIAL          500M
            NEXT             500M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           );

CREATE INDEX CUSTOM.IDX_C_EIT_HIST_LCHG30042024 ON CUSTOM.C_EIT_HIST
(LCHG_TIME)
LOGGING
TABLESPACE CUSTOM_IDXSPACE
PCTFREE    10
INITRANS   50
MAXTRANS   255
STORAGE    (
            INITIAL          500M
            NEXT             500M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           );

CREATE OR REPLACE SYNONYM CUSTOM.EITH FOR CUSTOM.C_EIT_HIST;


CREATE OR REPLACE SYNONYM TBAADM.C_EIT_HIST FOR CUSTOM.C_EIT_HIST;


CREATE OR REPLACE SYNONYM TBAGEN.C_EIT_HIST FOR CUSTOM.C_EIT_HIST;


CREATE OR REPLACE SYNONYM TBAUTIL.C_EIT_HIST FOR CUSTOM.C_EIT_HIST;


GRANT DELETE ON CUSTOM.C_EIT_HIST TO A172219;

GRANT DELETE ON CUSTOM.C_EIT_HIST TO A220583;

GRANT DELETE ON CUSTOM.C_EIT_HIST TO A222930;

GRANT DELETE ON CUSTOM.C_EIT_HIST TO A225523;

GRANT DELETE ON CUSTOM.C_EIT_HIST TO A229472;

GRANT DELETE ON CUSTOM.C_EIT_HIST TO A235730;

GRANT DELETE ON CUSTOM.C_EIT_HIST TO A239739;

GRANT DELETE ON CUSTOM.C_EIT_HIST TO A250096;

GRANT SELECT ON CUSTOM.C_EIT_HIST TO ALERTUSER;

GRANT DELETE, INSERT, SELECT, UPDATE ON CUSTOM.C_EIT_HIST TO CRMUSER;

GRANT SELECT ON CUSTOM.C_EIT_HIST TO DEDUPADM;

GRANT DELETE ON CUSTOM.C_EIT_HIST TO EA225523;

GRANT DELETE ON CUSTOM.C_EIT_HIST TO EA239739;

GRANT SELECT ON CUSTOM.C_EIT_HIST TO MIGADM;

GRANT SELECT ON CUSTOM.C_EIT_HIST TO ODSUSER;

GRANT DELETE, INSERT, SELECT, UPDATE ON CUSTOM.C_EIT_HIST TO TBAADM;

GRANT ALTER, DELETE, INDEX, INSERT, REFERENCES, SELECT, UPDATE, ON COMMIT REFRESH, QUERY REWRITE, DEBUG, FLASHBACK ON CUSTOM.C_EIT_HIST TO TBAGEN;

GRANT ALTER, DELETE, INDEX, INSERT, REFERENCES, SELECT, UPDATE, ON COMMIT REFRESH, QUERY REWRITE, DEBUG, FLASHBACK ON CUSTOM.C_EIT_HIST TO TBAUTIL;



==================================================================================================
open several putty sessions and run the scripts below. But modify to reflect the new backup table
==================================================================================================

insert into CUSTOM.C_EIT_HIST select * from CUSTOM.C_EIT_HIST_30APR2024 where bod_date='24-APR-2024'; 
commit;

insert into CUSTOM.C_EIT_HIST select * from CUSTOM.C_EIT_HIST_30APR2024 where bod_date='25-APR-2024';
commit;

insert into CUSTOM.C_EIT_HIST select * from CUSTOM.C_EIT_HIST_30APR2024 where bod_date='26-APR-2024';
commit;

insert into CUSTOM.C_EIT_HIST select * from CUSTOM.C_EIT_HIST_30APR2024 where bod_date='27-APR-2024';
commit;

insert into CUSTOM.C_EIT_HIST select * from CUSTOM.C_EIT_HIST_30APR2024 where bod_date='28-APR-2024';
commit;

insert into CUSTOM.C_EIT_HIST select * from CUSTOM.C_EIT_HIST_30APR2024 where bod_date='29-APR-2024';
commit;

insert into CUSTOM.C_EIT_HIST select * from CUSTOM.C_EIT_HIST_30APR2024 where bod_date='30-APR-2024';
commit;



======================================================
Gather Stats on Newly created Table CUSTOM.C_EIT_HIST
======================================================
--5. Gather statistics on the table

exec dbms_stats.gather_table_stats(ownname =>'CUSTOM', tabname =>'C_EIT_HIST', estimate_percent => 5, cascade => TRUE, method_opt => 'FOR ALL COLUMNS SIZE 1',  no_invalidate =>false,degree=>10);



===============================================================================================================================
Check the table count for DTD/DTH  make sure it is not more than what is recorded for statistics once it is more run the below.
===============================================================================================================================
select count(*) from tbaadm.DAILY_TRAN_HEADER_TABLE; --511950

But you should do it close to movement. So always consult with the Production team.
--SELECT COUNT(*) FROM tbaadm.DAILY_TRAN_DETAIL_TABLE; --7,573,080;8,194,291 stat @Num Rows	10,764,240

--select count(*) from tbaadm.DAILY_TRAN_HEADER_TABLE;  --2,675,367;2,764,523 stat @Num Rows	3,137,660



exec dbms_stats.unlock_table_stats('TBAADM', 'DAILY_TRAN_HEADER_TABLE'); 
 
exec dbms_stats.gather_table_stats(ownname =>'TBAADM', tabname =>'DAILY_TRAN_HEADER_TABLE', estimate_percent => 5, cascade => TRUE, method_opt => 'FOR ALL COLUMNS SIZE 1',  no_invalidate =>false,degree=>10);
 
exec dbms_stats.lock_table_stats('TBAADM', 'DAILY_TRAN_HEADER_TABLE');
 
 
exec dbms_stats.unlock_table_stats('TBAADM', 'DAILY_TRAN_DETAIL_TABLE');
 
exec dbms_stats.gather_table_stats(ownname =>'TBAADM', tabname =>'DAILY_TRAN_DETAIL_TABLE', estimate_percent => 5, cascade => TRUE, method_opt => 'FOR ALL COLUMNS SIZE 1',  no_invalidate =>false,degree=>10);
 
exec dbms_stats.lock_table_stats('TBAADM', 'DAILY_TRAN_DETAIL_TABLE');

===============================
CAM TABLE MAINTENANCE
===============================
--===================================
--CAM table maintenance for EOM
--Change to date accordingly
--===================================

ALTER TABLE CUSTOM.LV_DTDTRANDETAILS_LV RENAME TO LV_DTDTRANDETAILS_LV_30APR2024;

--Alter INDEX CUSTOM.IDX_LDTDTRANDETAILS_TNOCHGTYP0008       RENAME TO IDX_LDTDTRANDETAILS_TNOCHGTYP0008_30SEP2023;
--Alter INDEX CUSTOM.P13LV_DTDTRANDETAILSTRANDETAILS_LV008   RENAME TO P13LV_DTDTRANDETAILSTRANDETAILS_LV008_30SEP2023;
--Alter INDEX CUSTOM.P15LV_DTDTRANDETAILSTRANDETAILS_LV1008  RENAME TO P15LV_DTDTRANDETAILSTRANDETAILS_LV1008_30SEP2023;
--Alter INDEX CUSTOM.P16LV_DTDTRANDETAILSTRANDETAILS_LV1008  RENAME TO P16LV_DTDTRANDETAILSTRANDETAILS_LV1008_30SEP2023;
--Alter INDEX CUSTOM.P1KLV_DTDTRANDETAILSTRANDETAILS_LV009   RENAME TO P1KLV_DTDTRANDETAILSTRANDETAILS_LV009_30SEP2023;
--Alter INDEX CUSTOM.P1KLV_DTDTRANDETAILSTRANDETAILS_LV1008  RENAME TO P1KLV_DTDTRANDETAILSTRANDETAILS_LV1008_30SEP2023;
--Alter INDEX CUSTOM.P31LV_DTDTRANDETAILSTRANDETAILS_LV71010 RENAME TO P31LV_DTDTRANDETAILSTRANDETAILS_LV71010_30SEP2023;

CREATE TABLE CUSTOM.LV_DTDTRANDETAILS_LV
(
  LV_TRANDATE           DATE,
  LV_TRANID             VARCHAR2(9 CHAR),
  IV_BANKID             VARCHAR2(8 CHAR),
  LV_VALUEDATE          DATE,
  LV_PARTTRANSRLNUM     VARCHAR2(4 CHAR),
  LV_TRANAMT            NUMBER(20,4),
  LV_TRANCRNCYCODE      VARCHAR2(3 CHAR),
  LV_TRANTYPE           CHAR(1 BYTE),
  LV_TRANSUBTYPE        VARCHAR2(2 CHAR),
  LV_PARTTRANTYPE       CHAR(1 BYTE),
  LV_REFCRNCYCODE       VARCHAR2(3 CHAR),
  LV_RATECODE           VARCHAR2(5 CHAR),
  LV_RATE               NUMBER(21,10),
  LV_FORACID            VARCHAR2(16 CHAR),
  LV_INITSOLID          VARCHAR2(8 CHAR),
  LV_CIFID              VARCHAR2(50 CHAR),
  LV_TRANPARTICULAR     VARCHAR2(50 CHAR),
  LV_TRANREMARKS        VARCHAR2(30 CHAR),
  LV_REFNUM             VARCHAR2(20 CHAR),
  LV_DELIVERYCHANNELID  VARCHAR2(10 CHAR),
  LV_RPTCODE            VARCHAR2(5 CHAR),
  LV_DELFLG             CHAR(1 BYTE),
  LV_TRN_PRTCLR_CODE    VARCHAR2(5 CHAR),
  LV_INSTRMNTTYPE       VARCHAR2(5 CHAR),
  LV_SCHM_CODE          VARCHAR2(5 CHAR),
  LV_TURNOVER_TYPE      VARCHAR2(5 CHAR),
  LV_ACID               VARCHAR2(11 CHAR),
  CHG_TYPE              NVARCHAR2(10)           DEFAULT 'Default',
  ISCHARGEABLE          CHAR(1 BYTE)            DEFAULT 'N',
  CHG_NOCHG_REASON      NVARCHAR2(100),
  LV_COT_AMT            NUMBER(20,4)            DEFAULT (-9),
  LV_VAT_AMT            NUMBER(20,4)            DEFAULT (-9),
  SUBSEGMENT            NVARCHAR2(50),
  THREADNO              NUMBER                  DEFAULT (0),
  LV_ORG_ACID           VARCHAR2(11 CHAR),
  LV_ORG_FORACID        VARCHAR2(16 CHAR),
  LV_ORG_CIFID          VARCHAR2(50 CHAR),
  LV_SAME_CIF           VARCHAR2(1 CHAR),
  LV_MANUAL_REVERSAL    VARCHAR2(1 CHAR),
  LV_SAME_GROUP         VARCHAR2(1 CHAR)        DEFAULT NULL,
  LV_TRANAMT_ORIG       NUMBER(20,4)            DEFAULT 0,
  LV_TRANAMT_ADJ        NUMBER(20,4)            DEFAULT 0
)
NOCOMPRESS 
TABLESPACE CUSTOM_TBLS
PCTFREE    40
INITRANS   100
MAXTRANS   255
STORAGE    (
            INITIAL          200M
            NEXT             200M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING
PARTITION BY HASH (LV_TRANID)
(  
  PARTITION TAB_DTDTRANDET_PART1
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_DTDTRANDET_PART2
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_DTDTRANDET_PART3
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_DTDTRANDET_PART4
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_DTDTRANDET_PART5
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_DTDTRANDET_PART6
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_DTDTRANDET_PART7
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_DTDTRANDET_PART8
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_DTDTRANDET_PART9
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_DTDTRANDET_PART10
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_DTDTRANDET_PART11
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_DTDTRANDET_PART12
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_DTDTRANDET_PART13
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_DTDTRANDET_PART14
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_DTDTRANDET_PART15
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_DTDTRANDET_PART16
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_DTDTRANDET_PART17
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_DTDTRANDET_PART18
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_DTDTRANDET_PART19
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_DTDTRANDET_PART20
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_DTDTRANDET_PART21
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_DTDTRANDET_PART22
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_DTDTRANDET_PART23
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_DTDTRANDET_PART24
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_DTDTRANDET_PART25
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_DTDTRANDET_PART26
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_DTDTRANDET_PART27
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_DTDTRANDET_PART28
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_DTDTRANDET_PART29
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_DTDTRANDET_PART30
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_DTDTRANDET_PART31
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_DTDTRANDET_PART32
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_DTDTRANDET_PART33
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_DTDTRANDET_PART34
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_DTDTRANDET_PART35
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_DTDTRANDET_PART36
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_DTDTRANDET_PART37
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_DTDTRANDET_PART38
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_DTDTRANDET_PART39
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_DTDTRANDET_PART40
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_DTDTRANDET_PART41
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_DTDTRANDET_PART42
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_DTDTRANDET_PART43
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_DTDTRANDET_PART44
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_DTDTRANDET_PART45
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_DTDTRANDET_PART46
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_DTDTRANDET_PART47
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_DTDTRANDET_PART48
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_DTDTRANDET_PART49
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_DTDTRANDET_PART50
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_DTDTRANDET_PART51
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_DTDTRANDET_PART52
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_DTDTRANDET_PART53
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_DTDTRANDET_PART54
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_DTDTRANDET_PART55
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_DTDTRANDET_PART56
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_DTDTRANDET_PART57
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_DTDTRANDET_PART58
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_DTDTRANDET_PART59
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_DTDTRANDET_PART60
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_DTDTRANDET_PART61
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_DTDTRANDET_PART62
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_DTDTRANDET_PART63
    TABLESPACE CUSTOM_TBLS,  
  PARTITION TAB_DTDTRANDET_PART64
    TABLESPACE CUSTOM_TBLS
)
NOCACHE
ENABLE ROW MOVEMENT;


ALTER TABLE CUSTOM.LV_DTDTRANDETAILS_LV ADD (
  CHECK (Chg_Type in ('Default','PAYAS','CONDP','CONSN','IGNORE','HYCA','REPRI','BSA01','HYCAG','BSA02'))
  ENABLE VALIDATE
,  CHECK (IschargeAble in ('Y','N','P'))
  ENABLE VALIDATE);


CREATE INDEX CUSTOM.IDX_LDTDTRANDETAILS_TNOCHGTYP30042024 ON CUSTOM.LV_DTDTRANDETAILS_LV
(THREADNO, CHG_TYPE)
LOGGING
TABLESPACE CUSTOM_IDXSPACE
PCTFREE    10
INITRANS   100
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            NEXT             16K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           );

CREATE INDEX CUSTOM.P13LV_DTDTRANDETAILSTRANDETAILS_LV30042024 ON CUSTOM.LV_DTDTRANDETAILS_LV
(LV_TRANDATE, LV_TRANID, LV_PARTTRANSRLNUM)
LOGGING
TABLESPACE CUSTOM_IDXSPACE
PCTFREE    10
INITRANS   100
MAXTRANS   255
STORAGE    (
            INITIAL          50M
            NEXT             10M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           );

CREATE INDEX CUSTOM.P15LV_DTDTRANDETAILSTRANDETAILS_LV30042024 ON CUSTOM.LV_DTDTRANDETAILS_LV
(LV_FORACID)
LOGGING
TABLESPACE CUSTOM_IDXSPACE
PCTFREE    10
INITRANS   100
MAXTRANS   255
STORAGE    (
            INITIAL          50M
            NEXT             10M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           );

CREATE INDEX CUSTOM.P16LV_DTDTRANDETAILSTRANDETAILS_LV30042024 ON CUSTOM.LV_DTDTRANDETAILS_LV
(LV_SCHM_CODE)
LOGGING
TABLESPACE CUSTOM_IDXSPACE
PCTFREE    10
INITRANS   100
MAXTRANS   255
STORAGE    (
            INITIAL          50M
            NEXT             10M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           );

CREATE INDEX CUSTOM.P1KLV_DTDTRANDETAILSTRANDETAILS_LV30042024 ON CUSTOM.LV_DTDTRANDETAILS_LV
(LV_ACID, LV_FORACID)
LOGGING
TABLESPACE CUSTOM_IDXSPACE
PCTFREE    10
INITRANS   100
MAXTRANS   255
STORAGE    (
            INITIAL          50M
            NEXT             10M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           );

CREATE INDEX CUSTOM.P2KLV_DTDTRANDETAILSTRANDETAILS_LV30042024 ON CUSTOM.LV_DTDTRANDETAILS_LV
(LV_TRANDATE, LV_TURNOVER_TYPE, CHG_TYPE)
LOGGING
TABLESPACE CUSTOM_IDXSPACE
PCTFREE    10
INITRANS   100
MAXTRANS   255
STORAGE    (
            INITIAL          50M
            NEXT             10M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           );

CREATE INDEX CUSTOM.P31LV_DTDTRANDETAILSTRANDETAILS_LV30042024 ON CUSTOM.LV_DTDTRANDETAILS_LV
(LV_TRANDATE, LV_INITSOLID)
LOGGING
TABLESPACE CUSTOM_IDXSPACE
PCTFREE    10
INITRANS   100
MAXTRANS   255
STORAGE    (
            INITIAL          50M
            NEXT             10M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           );

GRANT SELECT ON CUSTOM.LV_DTDTRANDETAILS_LV TO ALERTUSER;

GRANT DELETE, INSERT, SELECT, UPDATE ON CUSTOM.LV_DTDTRANDETAILS_LV TO CRMUSER;

GRANT SELECT ON CUSTOM.LV_DTDTRANDETAILS_LV TO DEDUPADM;

GRANT SELECT ON CUSTOM.LV_DTDTRANDETAILS_LV TO MIGADM;

GRANT ALTER, DELETE, INDEX, INSERT, REFERENCES, SELECT, UPDATE, ON COMMIT REFRESH, QUERY REWRITE, DEBUG, FLASHBACK ON CUSTOM.LV_DTDTRANDETAILS_LV TO TBAADM;

GRANT ALTER, DELETE, INDEX, INSERT, REFERENCES, SELECT, UPDATE, ON COMMIT REFRESH, QUERY REWRITE, DEBUG, FLASHBACK ON CUSTOM.LV_DTDTRANDETAILS_LV TO TBAGEN;

GRANT ALTER, DELETE, INDEX, INSERT, REFERENCES, SELECT, UPDATE, ON COMMIT REFRESH, QUERY REWRITE, DEBUG, FLASHBACK ON CUSTOM.LV_DTDTRANDETAILS_LV TO TBAUTIL;



--4. Recreate the table using the table creation script extracted in step 1.
--5. Insert one month data back into the main table from the backup table

INSERT /*+ parallel 16 nologging */ INTO CUSTOM.LV_DTDTRANDETAILS_LV
SELECT * FROM CUSTOM.LV_DTDTRANDETAILS_LV_01AUG2024 WHERE  LV_TRANDATE >= '01-JUL-2024';
COMMIT;  

5. Gather statistics on the table

exec dbms_stats.gather_table_stats(ownname =>'CUSTOM', tabname =>'LV_DTDTRANDETAILS_LV', estimate_percent => 5, cascade => TRUE, method_opt => 'FOR ALL COLUMNS SIZE 1',  no_invalidate =>false,degree=>10);

================================================
EOM Statement Procedures
================================================

BEGIN 
  
  MISUSER.STE_MAIN_PKG.MONTHLY_STATEMENT_QUERIES();
  COMMIT; 
END;

BEGIN 
  
  MISUSER.STE_MAIN_PKG.MONTHLY_LOAN_STATEMENT_QUERIES();
  COMMIT; 
END;


BEGIN 
  
  MISUSER.MONTHLY_STATEMENT_QUERIES_NEW();
  COMMIT; 
END;

Please help run below packages, prerequisite to generation of Monthly E-Statements for April 2023.
 
MISUSER.STE_MAIN_PKG.MONTHLY_STATEMENT_QUERIES
MISUSER.STE_MAIN_PKG.MONTHLY_LOAN_STATEMENT_QUERIES

=============================
AUTOMATE RMAN BACKUP JOB
============================
#!/bin/bash
ORACLE_SID=ungagency; export ORACLE_SID
ORACLE_HOME=/u01/app/oracle/product/19.0.0/db_1; export ORACLE_HOME
$ORACLE_HOME/bin/rman log=/flashback/expdp/ungagency_rman0.log append <<EOF
connect target '/ AS SYSDBA';
set echo on;
run
{
        allocate channel c1 DEVICE TYPE DISK;
        allocate channel c2 DEVICE TYPE DISK;
        allocate channel c3 DEVICE TYPE DISK;
        allocate channel c4 DEVICE TYPE DISK;
        allocate channel c5 DEVICE TYPE DISK;
        allocate channel c6 DEVICE TYPE DISK;
        allocate channel c7 DEVICE TYPE DISK;
        allocate channel c8 DEVICE TYPE DISK;
        allocate channel c9 DEVICE TYPE DISK;
        allocate channel c10 DEVICE TYPE DISK;
        allocate channel c11 DEVICE TYPE DISK;
        allocate channel c12 DEVICE TYPE DISK;
        allocate channel c13 DEVICE TYPE DISK;
        allocate channel c14 DEVICE TYPE DISK;
        BACKUP AS COMPRESSED BACKUPSET DATABASE FORMAT '/flashback/rmanbkp/daily/ungagency/29NOV203_BASH_AUT_TEST/ungagency_%U.bkp';
        BACKUP AS COMPRESSED BACKUPSET ARCHIVELOG ALL FORMAT '/flashback/rmanbkp/daily/ungagency/29NOV203_BASH_AUT_TEST/ungagency_archive_%U.bkp';
        BACKUP CURRENT CONTROLFILE FORMAT '/flashback/rmanbkp/daily/ungagency/29NOV203_BASH_AUT_TEST/ungagency_ctrl_file_%U.bkp';
        release channel c1;
        release channel c2;
        release channel c3;
        release channel c4;
        release channel c5;
        release channel c6;
        release channel c7;
        release channel c8;
        release channel c9;
        release channel c10;
        release channel c11;
        release channel c12;
        release channel c13;
        release channel c14;
}
exit;
EOF


0 14 * * * sh /home/oracle/ungagency_rman_bkp.sh

=====================================================================================
=====================================================================================

select owner,table_name,num_rows,last_analyzed from dba_tables where owner='TBAADM'
union
select owner,index_name,num_rows,last_analyzed from dba_indexes where owner='TBAADM'


exec dbms_stats.gather_table_stats(ownname =>'TBAADM', tabname =>'DAILY_TRAN_DETAIL_TABLE', estimate_percent => 5, cascade => TRUE, method_opt => 'FOR ALL COLUMNS SIZE 1',  no_invalidate =>false,degree=>10);


exec dbms_stats.gather_table_stats(ownname =>'TBAADM', tabname =>'DAILY_TRAN_HEADER_TABLE', estimate_percent => 5, cascade => TRUE, method_opt => 'FOR ALL COLUMNS SIZE 1',  no_invalidate =>false,degree=>10);


exec dbms_stats.lock_table_stats('TBAADM', 'DAILY_TRAN_DETAIL_TABLE');

exec dbms_stats.unlock_table_stats('TBAADM', 'DAILY_TRAN_DETAIL_TABLE');


exec dbms_stats.lock_table_stats('TBAADM', 'DAILY_TRAN_HEADER_TABLE');

exec dbms_stats.unlock_table_stats('TBAADM', 'DAILY_TRAN_HEADER_TABLE');


================================================================================================================
BACKUP OF 3 MAIN DATABASES(PNGFIN, PNGRDBOX, PNGFIB)
-----------------------------backup FInacle EOM FEB 2023 ----------------------------------------------------- 
================================================================================================================
==============================
SEP 2023 EOM BACKUPS
==========================
PNGFIN
nohup rman target / @/flashback/rmanbkp/daily/pngfin/finaclebackup.full log=/flashback/expdp//backupFINACLEFUllDB22D31JUL2024.ful.log & 

tail -f /flashback/expdp/BackupPNGFINFUllDB31JAN2024.ful.log

Incremental BACKUP

nohup rman target / @/flashback/rmanbkp/daily/pngfin/finaclebackup.incrmt log=/flashback/expdp//backupFINACLEINCRMTDB07JUNE2024.ful.log & 
--Log is here. Change to date accordingly
backupFINACLEINCRMTDB01OCT2023.ful.log


REDBOX
nohup rman target / @/flashback/rmanbkp/daily/pngrdbox/redboxdbbackup.full log=/flashback/expdp//backupREDBOXFUllDB15JUNE2024.ful.log & 
--Log is here. Change to date accordingly
tail -f /flashback/expdp/backupREDBOXFUllDB03OCT2023.ful.log

INCREMENTAL
nohup rman target / @/flashback/rmanbkp/daily/pngrdbox/pngrdboxbackup.incrmt log=/flashback/expdp//backupREDBOXINCR22JUN2024.ful.log &
tail -f flashback/expdp/backupREDBOXINCR10JAN2023.ful.log


PNGFIB
nohup rman target / @/flashback/rmanbkp/daily/pngfib/pngfibdbbackup.full log=/flashback/expdp//backupPNGFIBFUllDB15JUNE2024.ful.log & 
--Log is here. Change to date accordingly
tail -f flashback/expdp/backupPNGFIBFUllDB03OCT2023.ful.log


INCREMENTAL
nohup rman target / @/flashback/rmanbkp/daily/pngfib/pngfibbackup.incrmt log=/flashback/expdp//backupFIBINCR15JUN2024.ful.log &
tail -f /flashback/expdp/backupFIBINCR06MAR2024.ful.log


nohup rman target / @/flashback/rmanbkp/daily/pngtfin/pngtfingbackup.full log=/flashback/expdp//pngtfin30APR2024.ful.log &

nohup rman target / @/flashback/rmanbkp/daily/pngtfin/pngtfingbackup.incrmt log=/flashback/expdp//pngtfin01MAY2024.ful.log &


nohup rman target / @/flashback/expdp/pngcfrm_restore.full log=/flashback/expdp//pngcfrm_restore_19jul24.ful.log &

