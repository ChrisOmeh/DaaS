SQL SERVER IMPORTANT METRICS TO BE MONITORED

METRICS TO WATCH	 DESCRIPTION
T-SQL Metrics	
Batch Request/sec	To get a high-level view of the overall usage of your database over time, you can measure the number of batch requests the database engine receives per second.
last elapsed time	The elapsed time of an execution plan is a good proxy for how well SQL Server’s optimization techniques are working.
SQL compilations/sec	 
SQL recompilations/sec	 
	
Buffer Cache Metrics	
Buffer cache hit ratio	Percentage of requested pages found in the buffer cache
Page life expectancy	Time a page is expected to spend in the buffer cache, in seconds
Checkpoint pages/sec	Number of pages written to disk per second by a checkpoint
Table resource metrics	
memory_used_by_table_kb	 
Disk usage	 
	
Metrics for locks	
Lock wait/sec	 Number of requests causing the calling transaction to wait for a lock, per second
Processed blocked	 Count of processes blocked at the time of measurement
 	 
Resource Pool Metrics	 
Used memory	 Kilobytes of memory used in the resource pool
CPU usage %	 Percentage of CPU used by all workload groups in the resource pool
Disk read IO/sec	 Count of disk read operations in the last second per resource pool
Disk write IO/sec	 Count of disk write operations in the last second per resource pool
	
Index Metrics	 
Page splits/sec	 Count of page splits resulting from index page overflows per second
avg_fragmentation_in_percent	 Percentage of leaf pages in an index that are out of order

	 
Metrics to alert on	
User connection	Count of users connected to SQL Server at the time of measurement
memory_used_by_table_kb	
Disk Usage	
CPU Usage %	
Used memory	

===============================
USING GROUP AND JOIN IN SQL
===============================
select  redbox.R.REGION_CD, C.CURRENCY_CD, A.SAM_POPULATION_GROUP_CD, AC.ACCOUNT_CLASSIFICATION_CD,  
AVG(B.ACCT_CURR_VALUE), STDEV(B.ACCT_CURR_VALUE) from UDM_CDS.ACCOUNT A
join UDM_CDS.BALANCE B on B.ACCOUNT_SK = A.ENTITY_SK
join UDM_CDS.ACCOUNT_CLASSIFICATION AC on AC.ENTITY_SK = A.ACCOUNT_CLASSIFICATION_SK
join UDM_CDS.REGION redbox.R on redbox.R.ENTITY_SK = A.REGION_SK
join UDM_CDS.CURRENCY C on C.ENTITY_SK = A.ACCT_CURR_SK
group by redbox.R.REGION_CD, C.CURRENCY_CD,A.SAM_POPULATION_GROUP_CD, AC.ACCOUNT_CLASSIFICATION_CD;



=================AG REPLICATION ISSUES================
ALTER AVAILABILITY GROUP [MyAGName] MODIFY REPLICA ON N'SQL01' WITH (SECONDARY_ROLE(ALLOW_CONNECTIONS = READ_ONLY));
ALTER AVAILABILITY GROUP [MyAGName] MODIFY REPLICA ON N'SQL01' WITH (SECONDARY_ROLE(ALLOW_CONNECTIONS = ALL));



Using ODP.NET without tnsnames.ora
Data Source=(DESCRIPTION=(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST=MyHost)(PORT=MyPort)))(CONNECT_DATA=(SERVER=DEDICATED)(SERVICE_NAME=MyOracleSID)));User Id=myUsername;Password=myPassword;

