edit database pngitms set state=TRANSPORT-OFF;
edit database dngitms set state=APPLY-OFF;


run
{
        allocate channel c1 DEVICE TYPE DISK;
        allocate channel c2 DEVICE TYPE DISK;
        allocate channel c3 DEVICE TYPE DISK;
        allocate channel c4 DEVICE TYPE DISK;
        allocate channel c5 DEVICE TYPE DISK;
        allocate channel c6 DEVICE TYPE DISK;
        allocate channel c7 DEVICE TYPE DISK;
        allocate channel c8 DEVICE TYPE DISK;
        allocate channel c9 DEVICE TYPE DISK;
        allocate channel c10 DEVICE TYPE DISK;
        allocate channel c11 DEVICE TYPE DISK;
        allocate channel c12 DEVICE TYPE DISK;
        allocate channel c13 DEVICE TYPE DISK;
        allocate channel c14 DEVICE TYPE DISK;
        BACKUP AS COMPRESSED BACKUPSET DATABASE FORMAT '/flashback/rmanbkp/daily/iconcept/ICONCEPT_INCR_NOV23/iconcept_%U.bkp';
        BACKUP AS COMPRESSED BACKUPSET ARCHIVELOG ALL FORMAT '/flashback/rmanbkp/daily/iconcept/ICONCEPT_INCR_NOV23/iconcept_archive_%U.bkp';
        BACKUP CURRENT CONTROLFILE FORMAT '/flashback/rmanbkp/daily/iconcept/ICONCEPT_INCR_NOV23/iconcept_ctrl_file_%U.bkp';
        release channel c1;
        release channel c2;
        release channel c3;
        release channel c4;
        release channel c5;
        release channel c6;
        release channel c7;
        release channel c8;
        release channel c9;
        release channel c10;
        release channel c11;
        release channel c12;
        release channel c13;
        release channel c14;
}

nohup rman target / @/flashback/expdp/itmsbackup/itmsSTBbackup.full log=/flashback/expdp//itmsSTBbackup.ful.log &

cd /flashback/expdp/itmsbackup/
scp * oracle@10.234.204.10:/flashback/expdp/itmsbackup


SYS@pngitms1 >select GROUP#,TYPE,MEMBER from v$logfile;  --Take note on standbyDB

SYS@pngitms1 > show parameter control_files;

NAME                                 TYPE        VALUE
------------------------------------ ----------- ------------------------------
control_files                        string      +DATA/PNGITMS/CONTROLFILE/cont 
                                                 rol01.ctl, +FRA/PNGITMS/CONTRO
                                                 LFILE/control02.ctl
												 
------backup controlfile------

RMAN> restore standby controlfile from '/flashback/expdp/itmsbackup/itms_ctrl_file_362avdoa_12390_1_1.bkp';

RMAN> catalog start with '/flashback/expdp/itmsbackup/';


run {
         set newname for database to "+DATA/DNGITMS/DATAFILE/%b";
         restore database;
		 recover database;
}

nohup rman target / @/flashback/expdp/itmsbackup/itmsSTBrestore.full log=/flashback/expdp//itmsSTBrestore.ful.log &


SYS@pngitms1 >select GROUP#,TYPE,MEMBER from v$logfile;    

    GROUP# TYPE    MEMBER
---------- ------- --------------------------------------------------
         1 ONLINE  +DATA/PNGITMS/ONLINELOG/group_1.1014.1049290995
         1 ONLINE  +FRA/PNGITMS/ONLINELOG/group_1.463.1049290997
         2 ONLINE  +DATA/PNGITMS/ONLINELOG/group_2.1015.1049290997
         2 ONLINE  +FRA/PNGITMS/ONLINELOG/group_2.464.1049290997
         3 ONLINE  +DATA/PNGITMS/ONLINELOG/group_3.1022.1049291787
         3 ONLINE  +FRA/PNGITMS/ONLINELOG/group_3.468.1049291787
         4 ONLINE  +DATA/PNGITMS/ONLINELOG/group_4.1023.1049291787
         4 ONLINE  +FRA/PNGITMS/ONLINELOG/group_4.469.1049291787
         5 STANDBY +REDO/PNGITMS/ONLINELOG/group_5.409.1079260935
         6 STANDBY +REDO/PNGITMS/ONLINELOG/group_6.410.1079260935
         7 STANDBY +REDO/PNGITMS/ONLINELOG/group_7.411.1079260937

    GROUP# TYPE    MEMBER
---------- ------- --------------------------------------------------
         8 STANDBY +REDO/PNGITMS/ONLINELOG/group_8.412.1079260937
         9 STANDBY +REDO/PNGITMS/ONLINELOG/group_9.413.1079260973

ASMCMD> ls
group_10.296.1061723349
group_11.297.1061723351
group_12.298.1061723353
group_13.299.1061723353
group_14.300.1061723355
group_5.334.1079260965
group_6.335.1079260967
group_7.336.1079260967
group_8.337.1079260967
group_9.338.1079260969

alter system set standby_file_management=manual;

alter database rename file '+REDO/PNGITMS/ONLINELOG/group_5.409.1079260935' to '+REDO/DNGITMS/ONLINELOG/group_5.334.1079260965';
alter database rename file '+REDO/PNGITMS/ONLINELOG/group_6.410.1079260935' to '+REDO/DNGITMS/ONLINELOG/group_6.335.1079260967';
alter database rename file '+REDO/PNGITMS/ONLINELOG/group_7.411.1079260937' to '+REDO/DNGITMS/ONLINELOG/group_7.336.1079260967';
alter database rename file '+REDO/PNGITMS/ONLINELOG/group_8.412.1079260937' to '+REDO/DNGITMS/ONLINELOG/group_8.337.1079260967';
alter database rename file '+REDO/PNGITMS/ONLINELOG/group_9.413.1079260973' to '+REDO/DNGITMS/ONLINELOG/group_9.338.1079260969';

alter system set standby_file_management=auto;


edit database pngitms set state=TRANSPORT-ON;
edit database dngitms set state=APPLY-ON;

