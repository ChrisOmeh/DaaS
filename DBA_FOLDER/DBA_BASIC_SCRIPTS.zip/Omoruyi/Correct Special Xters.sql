----- Run below to check for special xters in the acct name 

select acid from tbaadm.gam where translate(

upper(acct_name), 

CHR(0)||'QWERTYUIOPASDFGHJKLZXCVBNM ,./?;:''[{]}1234567890-=!@#$%^&*()_+\|`~',

CHR(0)

) IS NOT NULL;


----- Run below to Correct special xters in the acct name or acct_short name

update tbaadm.gam
set Acct_name = NVL(trim(regexp_replace(Acct_name,'[^A-Z^a-z^0-9^ ]','')),'NULL'),
        Acct_short_name = NVL(trim(regexp_replace(Acct_short_name,'[^A-Z^a-z^0-9^ ]','')),'NULL')
where acid in (select acid from tbaadm.gam where translate(

upper(acct_name), 

CHR(0)||'QWERTYUIOPASDFGHJKLZXCVBNM ,./?;:''[{]}1234567890-=!@#$%^&*()_+\|`~',

CHR(0)

) IS NOT NULL) ;




select * from tbaadm.gam where acid = 'SB8317124';
