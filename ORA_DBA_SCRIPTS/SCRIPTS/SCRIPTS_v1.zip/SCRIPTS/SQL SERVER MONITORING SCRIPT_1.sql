--================================== ALL SQL DB OBJECTS
SELECT * FROM sys.all_objects;

--===============================
SELECT * FROM sys.dm_exec_query_memory_grants;

--==========================================
SELECT * FROM sys.database_files;

--=================================
select CAST(create_date as date) as created_date,
database_id,
UPPER(name) as database_name,
compatibility_level,
user_access_desc,
state_desc,
recovery_model_desc,
log_reuse_wait_desc
from sys.databases;

select * from sys.databases;

select * from sys.master_files;

select @@VERSION
--Microsoft SQL Server 2016 (SP1) (KB3182545) - 13.0.4001.0 (X64)   Oct 28 2016 18:17:30   Copyright (c) Microsoft Corporation  
--Enterprise Edition: Core-based Licensing (64-bit) on Windows Server 2012 R2 Standard 6.3 <X64> (Build 9600: ) 

SELECT compatibility_level FROM sys.databases
where compatibility_level >=100;


--========================
select * from sys.sysusers;
select * from sys.sql_logins;
select * from sys.database_principals;
select * from sys.syslogins;
select * from sys.server_principals;
select db_name(database_id) from sys.database_recovery_status;

select * from sys.all_objects 
where name like '%recovery%';
--==============================

SELECT name AS Login_Name, type_desc AS Account_Type
FROM sys.server_principals 
WHERE TYPE IN ('U', 'S', 'G')
and name not like '%##%'
ORDER BY name, type_desc

--===============================
SELECT loginname as LOGIN_NAME,
CAST(createdate as date) as CREATED_DATE
from sys.syslogins;

select * from sys.syslogins;
select * FROM sys.server_principals;

--===================================
SELECT loginname as LOGIN_NAME,
type_desc as LOGIN_TYPE,
CAST(create_date as date) as CREATED_DATE,
case when is_disabled =1
then 'DISABLED'
else
'ENABLED'
END as ACCOUNT_STATUS
FROM sys.server_principals,sys.syslogins
ORDER BY LOGIN_NAME, ACCOUNT_STATUS;

--==============================================
--SQL CONDITIONAL  STATEMENT
DECLARE @MATH INT, @ENG INT, @CHEM INT, @PHY INT
SET @MATH = 80;
SET @ENG = 70;
SET @CHEM = 75;
SET @PHY = 85;

IF @MATH >70
BEGIN
PRINT 'CONGRATULATIONS YOU PASSED MATH'
END
ELSE
BEGIN
PRINT'YOU FAILED MATH'
END

IF @ENG >70
BEGIN
PRINT 'CONGRATULATIONS YOU PASSED MATH'
END
ELSE
BEGIN
PRINT'YOU FAILED MATH'
END

IF @CHEM >70
BEGIN
PRINT 'CONGRATULATIONS YOU PASSED MATH'
END
ELSE
BEGIN
PRINT'YOU FAILED MATH'
END

IF @PHY >70
BEGIN
PRINT 'CONGRATULATIONS YOU PASSED MATH'
END
ELSE
BEGIN
PRINT'YOU FAILED MATH'
END

--=============================================================
DECLARE @MATHS INT, @ENGG INT, @CHEMM INT, @PHYY INT
SET @MATHS = 80;
SET @ENGG = 70;
SET @CHEMM = 75;
SET @PHYY = 85;
IF (@MATHS >=50 AND @ENGG >= 50 AND @CHEMM >=50 AND @PHYY >=50)
BEGIN
	DECLARE @PERCENTAGE FLOAT
	SET @PERCENTAGE = ((@MATHS+@ENGG+@CHEMM+@PHYY)*100) / 300
	PRINT CONCAT('YOUR PERCENTAGE SCORE IS:', @PERCENTAGE)
END
ELSE
BEGIN
	PRINT "YOU DON'T HAVE A PERCENTAGE SCORE"
END


--=============================================
--DISK VOLUME 
SELECT db_name(f.database_id) AS [DATABASE NAME], 
f.database_id AS [DATABASES ID], 
f.file_id AS [FILE ID], 
volume_mount_point[Disk], 
CONVERT(DECIMAL(18,2),total_bytes/1073741824.0) AS [TOTAL SPACE SIZE(GB)], 
CONVERT(DECIMAL(18,2),available_bytes/1073741824.0) AS [AVAILABLE SPACE SIZE(GB)],
CAST(CAST(available_bytes AS FLOAT)/CAST(total_bytes AS FLOAT) AS DECIMAL(18,2)) *100 AS [PCT FREE SPACE(%)]
FROM sys.master_files AS f  
CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.file_id)
ORDER BY [PCT FREE SPACE(%)] DESC;


SELECT DISTINCT 
    CONVERT(CHAR(100), SERVERPROPERTY('Servername')) AS Server,
    volume_mount_point [Disk], 
    file_system_type [File System], 
    logical_volume_name as [Logical Drive Name], 
    CONVERT(DECIMAL(18,2),total_bytes/1073741824.0) AS [Total Size in GB], ---1GB = 1073741824 bytes
    CONVERT(DECIMAL(18,2),available_bytes/1073741824.0) AS [Available Size in GB],  
    CAST(CAST(available_bytes AS FLOAT)/ CAST(total_bytes AS FLOAT) AS DECIMAL(18,2)) * 100 AS [Space Free %] 
FROM sys.master_files 
CROSS APPLY sys.dm_os_volume_stats(database_id, file_id)
ORDER BY [Space Free %] DESC;

/*To check Disk utilization*/
SELECT DISTINCT vs.volume_mount_point,
vs.file_system_type,
vs.logical_volume_name,
CONVERT(DECIMAL(18,2),vs.total_bytes/1073741824.0) AS [Total Size (GB)],
CONVERT(DECIMAL(18,2),vs.available_bytes/1073741824.0) AS [Available Size (GB)],
CAST(CAST(vs.available_bytes AS FLOAT)/ CAST(vs.total_bytes AS FLOAT)
AS DECIMAL(18,2)) * 100 AS [Space Free %]
FROM sys.master_files AS f WITH (NOLOCK)
CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.[file_id]) AS vs OPTION (RECOMPILE);


--======================================================
SELECT * FROM sys.dm_os_sys_info;
select * from sys.dm_os_windows_info;
select * from sys.dm_server_services;


select * from sys.all_objects
where name like '%recovery%';

select * from sys.databases
where database_id not in (1,2,3,4) AND log_reuse_wait_desc = 'LOG_BACKUP'
order by name;


USE YOURDB
GO
EXEC sp_removedbreplication 'YOURDB'
GO
CHECKPOINT
GO

--===========================================================
select * from sys.security_predicates;
select * from sys.dm_tran_global_recovery_transactions;

--======================================
SELECT *
FROM sys.inventory.Storage
ORDER BY percent_free_space;

--======================================
--Adventureworks database
USE [AdventureWorksSales]
select COUNT(*) from [dbo].[Product];

declare @col varchar
set @col = 
(select TOP 1 Color
				from [dbo].[Product]
				where [StandardCost] = (select MAX([StandardCost]) from [dbo].[Product]));
select Name
from [dbo].[Product]
where Color = @col;


select Name 
from [dbo].[Product]
where Color = (select TOP 1 Color
				from [dbo].[Product]
				where [StandardCost] = (select MAX([StandardCost]) from [dbo].[Product]))



select TOP 5 * from [dbo].[Product];
select TOP 5 * from [dbo].[ProductCategory];

select distinct(year(cast([ModifiedDate] as date))) from [dbo].[SalesOrder];
select distinct(month(cast([ModifiedDate] as date))) from [dbo].[SalesOrder];
select distinct(day(cast([ModifiedDate] as date))) from [dbo].[SalesOrder];


select TOP 5 * FROM [dbo].[SalesOrder];

SELECT * FROM sys.traces;


--=======================================================
--FIND DB USERS, LOGINS AND PRIVILEGES
--=======================================================

USE MASTER
(SELECT DISTINCT p.name AS [loginname] ,
p.type ,
p.type_desc ,
CONVERT(VARCHAR(10),p.create_date ,101) AS [created],
CONVERT(VARCHAR(10),p.modify_date , 101) AS [update],
case when p.is_disabled = 1 then 'Disabled'
            else 'Enabled' end as status,
case when s.sysadmin = 1 then 'Admin'
            else 'Not Admin' end as Administrative_privilege
FROM sys.server_principals p
JOIN sys.syslogins s ON p.sid = s.sid
JOIN sys.server_permissions sp ON p.principal_id = sp.grantee_principal_id
WHERE p.type_desc IN ('SQL_LOGIN', 'WINDOWS_LOGIN', 'WINDOWS_GROUP')
-- Logins that are not process logins
AND p.name NOT LIKE '##%'
AND p.name NOT LIKE 'NT SERVICE%'
-- Logins that are sysadmins or have GRANT CONTROL SERVER
AND (s.sysadmin = 1)
)
UNION ALL
(SELECT DISTINCT p.name AS [loginname] ,
p.type ,
p.type_desc ,
CONVERT(VARCHAR(10),p.create_date ,101) AS [created],
CONVERT(VARCHAR(10),p.modify_date , 101) AS [update],
case when p.is_disabled = 1 then 'Disabled'
            else 'Enabled' end as status,
case when s.sysadmin = 1 then 'Admin'
            else 'Not Admin' end as Administrative_privilege
FROM sys.server_principals p
JOIN sys.syslogins s ON p.sid = s.sid
JOIN sys.server_permissions sp ON p.principal_id = sp.grantee_principal_id
RIGHT JOIN sys.database_principals dp ON p.name COLLATE DATABASE_DEFAULT = dp.name COLLATE DATABASE_DEFAULT
WHERE p.type_desc IN ('SQL_LOGIN', 'WINDOWS_LOGIN', 'WINDOWS_GROUP')
-- Logins that are not process logins
AND p.name NOT LIKE '##%'
-- Logins that are sysadmins or have GRANT CONTROL SERVER
--AND (s.sysadmin = 1 OR sp.permission_name = 'CONTROL SERVER')
)

--===================================
--MASTER COUNT DB OBJECTS
--===================================
SELECT COUNT(*) FROM SYS.all_columns;
SELECT COUNT(*) FROM SYS.all_objects;
SELECT COUNT(*) FROM SYS.all_parameters;
SELECT COUNT(*) FROM SYS.all_views;

--===================================
--ALL DB VIEWS
--==================================
SELECT * FROM SYS.all_views
WHERE name LIKE '%sp%';


--====SQL SERVER CDC=====
USE AdventureWorksSales
SELECT	name AS object_name   
		,SCHEMA_NAME(schema_id) AS schema_name  
		,type_desc  
		,is_ms_shipped  
FROM sys.objects 
WHERE is_ms_shipped= 1 AND SCHEMA_NAME(schema_id) = 'cdc';

select TOP 5 * FROM [dbo].[Product];
select TOP 5 * FROM [dbo].[ProductCategory];


--========================================
--VERIFYING VALID AND INVALID DB OBJECTS
--========================================

USE [AdventureWorksSales]
DECLARE @DB_ID INT;
DECLARE @OBJ_ID INT;
SET @DB_ID = DB_ID(N'[AdventureWorksSales]');
SET @OBJ_ID = OBJECT_ID(N'[AdventureWorksSales].[dbo].[Product]');
IF @DB_ID IS NULL
BEGIN
	PRINT N'INVALID DATABASE'
END;
ELSE IF @OBJ_ID IS NULL
BEGIN;
	PRINT 'N INVALID DATABASE OBJECT'
END;
ELSE
BEGIN;
	SELECT * FROM SYS.dm_db_index_operational_stats(@DB_ID, @OBJ_ID, NULL, NULL);
END;
GO


 

 --=======================
 SELECT @@VERSION;

SELECT name, database_id, create_date FROM SYS.DATABASES
WHERE database_id NOT IN (1,2,3,4)
ORDER BY create_date DESC;

EXEC sp_who;
EXEC sp_who2;

SELECT spid, DB_NAME(dbid) as database_name, status,
hostname, program_name, hostprocess,
nt_domain, nt_username, loginame
FROM SYS.sysprocesses
where DB_NAME(dbid) not in ('master','msdb', 'tempdb','model');



USE [DeviceFinanceWorkerLogs] ---[StanbicIBTCChatBot]
GO
SELECT log_reuse_wait_desc FROM SYS.DATABASES
WHERE database_id = DB_ID();



--======CHECK DATABASE CONNECTIONS TO A PARTICULAR DB INSTANCE.=======
--Query one
SELECT loginame, DB_NAME(dbid) as DBName,
       COUNT(dbid) as NumberOfConnections      
FROM sys.sysprocesses
WHERE dbid > 0
GROUP BY dbid, loginame;


--Query 2:
select a.dbid,b.name, count(a.dbid) as TotalConnections
from sys.sysprocesses a
inner join sys.databases b on a.dbid = b.database_id
group by a.dbid, b.name

select name, log_reuse_wait_desc from sys.databases
where log_reuse_wait_desc = 'LOG_BACKUP';

--CHECK DATABASE SYS.DATABASES
select 
name, create_date, compatibility_level, user_access_desc,
state_desc,recovery_model_desc, log_reuse_wait_desc
from sys.databases
where database_id not in (1,2,3,4)
order by create_date desc;



--==============================
--BULK INSERT  
--==============================
BULK INSERT TABLE_NAME 
FROM 'FILE_PATH'
WITH (
FIELDTERMINATOR = ',',
ROWTERMINATOR = '\n',
FORMAT = 'csv'
)


--=============================================
--GRANT ACCESS TO USE TO SPECIFIC DDL, DML ETC
--=============================================
USE
RSVRRealtimeFinacleNG
GRANT SELECT ON "dbo"."HTD_JAN_2022" TO "NTNIGE\C854375";
GRANT SELECT ON "dbo"."HTD_JAN_2022" TO "NTNIGE\C854419";


--=======================================================
--SHRINK DATABASE LOG FILE
--=======================================================
SELECT name, database_id, log_reuse_wait, log_reuse_wait_desc FROM sys.databases;

USE [UDM];
GO
---- Truncate the log by changing the database recovery model to SIMPLE.
ALTER DATABASE [UDM] SET RECOVERY SIMPLE;
---- Shrink the truncated log file to 1 MB.
DBCC SHRINKFILE (UDM_log, 1);
ALTER DATABASE [UDM] SET RECOVERY FULL;
GO



--==========================================
--CHECK SESSION STATUS AND WAIT TYPE IN SQL SERVER
--================================================
SELECT  wt.session_id, 
    ot.task_state, 
    wt.wait_type, 
    wt.wait_duration_ms, 
    wt.blocking_session_id, 
    wt.resource_description, 
    es.[host_name], 
    es.[program_name] 
FROM  sys.dm_os_waiting_tasks  wt  
INNER  JOIN sys.dm_os_tasks ot ON ot.task_address = wt.waiting_task_address 
INNER JOIN sys.dm_exec_sessions es ON es.session_id = wt.session_id 
WHERE es.is_user_process =  1;


---===========================================================================
---======================ARCHIVING TABLE IN SQL SERVER========================
---===========================================================================
--====RPA_BOT DB=================
--•	CARD_GL - PSTD_DATE
--•	EFT_Exceptions - ReconDate
--•	FEPARCHIVE -  DATETIME_TRAN_LOCAL
--•	T464_Settlement - SettlementDate

--=====UIPATH DB=====
--•	Logs  - TimeStamp

--Archive should be from 01- January-2021 to 31-October-2022

--==================CARD_GL========================
--TEST SCRIPT
SELECT COUNT(*) FROM CARD_GL
WHERE CAST(PSTD_DATE as date) > '2022-10-31';---2297276

--CARD_GL_10FEB2023 TO BE CREATED
exec sp_rename 'CARD_GL', 'CARD_GL_temp'
exec sp_rename 'CARD_GL_10FEB2023', 'CARD_GL'
exec sp_rename 'CARD_GL_temp', 'CARD_GL_10FEB2023'

USE [RPA_BotDB]
INSERT INTO CARD_GL SELECT * FROM [dbo].[CARD_GL_10FEB2023]
WHERE CAST(PSTD_DATE as date) > '2022-10-31'
--==================CARD_GL  DONE========================


--==================EFT_Exceptions========================
SELECT COUNT(*) FROM [dbo].[EFT_Exceptions]
WHERE CAST(Recon_Date as date) > '2022-10-31';  ---9639426

--EFT_Exceptions_10FEB2023 TO BE CREATED
--exec sp_rename 'EFT_Exceptions', 'EFT_Exceptions_temp'
--exec sp_rename 'EFT_Exceptions_10FEB2023', 'EFT_Exceptions'
--exec sp_rename 'EFT_Exceptions_temp', 'EFT_Exceptions_10FEB2023'

USE [RPA_BotDB]
GO
INSERT INTO EFT_Exceptions SELECT * FROM EFT_Exceptions_10FEB2023
WHERE CAST(Recon_Date as date) > '2022-10-31';

--==================EFT_Exceptions Done===========================


--==================[dbo].[FEPArchive]========================
SELECT COUNT(*) FROM [dbo].[FEPArchive]
WHERE CAST(DATETIME_TRAN_LOCAL as date) > '2022-10-31';

--FEPArchive_10FEB2023 TO BE CREATED
--exec sp_rename 'FEPArchive', 'FEPArchive_temp'
--exec sp_rename 'FEPArchive_10FEB2023', 'FEPArchive'
--exec sp_rename 'FEPArchive_temp', 'FEPArchive_10FEB2023'
USE [RPA_BotDB]
GO
INSERT INTO FEPArchive SELECT * FROM FEPArchive_10FEB2023
WHERE CAST(DATETIME_TRAN_LOCAL as date) > '2022-10-31';

--==================FEPArchive Done===========================



--==================[dbo].[T464_Settlement]========================
SELECT COUNT(*) FROM [dbo].[T464_Settlement]
WHERE CAST(SettlementDate as date) > '2022-10-31';

--T464_Settlement_10FEB2023 TO BE CREATED
--exec sp_rename 'T464_Settlement', 'T464_Settlement_temp'
--exec sp_rename 'T464_Settlement_10FEB2023', 'T464_Settlement'
--exec sp_rename 'T464_Settlement_temp', 'T464_Settlement_10FEB2023'
USE [RPA_BotDB]
GO
INSERT INTO T464_Settlement SELECT * FROM T464_Settlement_10FEB2023
WHERE CAST(SettlementDate as date) > '2022-10-31';

DELETE FROM T464_Settlement_10FEB2023
WHERE CAST(SettlementDate as date) > '2022-10-31';

--==================T464_Settlement Done===========================


--==============BATCH SCRIPT TO DO BATCH DELETE OPERATION=============
USE [RPA_BotDB]
GO
SET NOCOUNT ON;
DECLARE @r INT;
SET @r = 1;
WHILE @r > 0
BEGIN
  BEGIN TRANSACTION;
 
  DELETE TOP(100000) FROM  [RPA_BotDB].dbo.FEPArchive WHERE DATETIME_TRAN_LOCAL <= DATEADD(DD, -30, GETDATE());
 
  SET @r = @@ROWCOUNT;
 
  COMMIT TRANSACTION;

  ALTER DATABASE [RPA_BotDB] SET RECOVERY SIMPLE;
---- Shrink the truncated log file to prevent the growth of transaction log file.
  DBCC SHRINKFILE (N'RPA_BotDB_log' , 0, TRUNCATEONLY);
  ALTER DATABASE [RPA_BotDB] SET RECOVERY FULL;
  -- CHECKPOINT;    -- if simple
  -- BACKUP LOG ... -- if full

END


DECLARE @BatchSize INT = 50000
WHILE 1 = 1
BEGIN
DELETE TOP (@BatchSize)
FROM [RPA_BotDB].dbo.FEPArchive 
WHERE DATETIME_TRAN_LOCAL <= DATEADD(DD, -30, GETDATE());
IF @@ROWCOUNT < @BatchSize BREAK
END


--=====================================
--FIND TABLE SIZES
--=====================================
SELECT 
    t.NAME AS TableName,
    s.Name AS SchemaName,
    p.rows,
    SUM(a.total_pages) * 8 AS TotalSpaceKB, 
    CAST(ROUND(((SUM(a.total_pages) * 8) / 1024.00), 2) AS NUMERIC(36, 2)) AS TotalSpaceMB,
    SUM(a.used_pages) * 8 AS UsedSpaceKB, 
    CAST(ROUND(((SUM(a.used_pages) * 8) / 1024.00), 2) AS NUMERIC(36, 2)) AS UsedSpaceMB, 
    (SUM(a.total_pages) - SUM(a.used_pages)) * 8 AS UnusedSpaceKB,
    CAST(ROUND(((SUM(a.total_pages) - SUM(a.used_pages)) * 8) / 1024.00, 2) AS NUMERIC(36, 2)) AS UnusedSpaceMB
FROM 
    sys.tables t
INNER JOIN      
    sys.indexes i ON t.OBJECT_ID = i.object_id
INNER JOIN 
    sys.partitions p ON i.object_id = p.OBJECT_ID AND i.index_id = p.index_id
INNER JOIN 
    sys.allocation_units a ON p.partition_id = a.container_id
LEFT OUTER JOIN 
    sys.schemas s ON t.schema_id = s.schema_id
WHERE 
    t.NAME NOT LIKE 'dt%' 
    AND t.is_ms_shipped = 0
    AND i.OBJECT_ID > 255 
GROUP BY 
    t.Name, s.Name, p.Rows
ORDER BY 
    TotalSpaceMB DESC, t.Name;
	
	
--================================
--SETUP JOB ON ALWAYSON HA
--================================
if (select
ars.role_desc
from sys.dm_hadr_availability_replica_states ars
inner join sys.availability_groups ag
on ars.group_id = ag.group_id
where ag.name = 'AGRPTDBS'
and ars.is_local = 1) = 'PRIMARY'
begin;
EXEC [dbo].[sp_ArchiverUIPATHTables];
end;


--===========================================================
--CHECK VLF COUNT TO SEE IF A DB WILL 
--ENTER RECOVERY MODE IF THE SQL SERVER SERVICE IS RESTARTED
--IF VLF COUNT IS ABOVE 300, DON'T RESTART SQL SERVER SERVICE
--============================================================
SELECT [name] AS 'Database Name',
COUNT(l.database_id) AS 'VLF Count',
SUM(CAST(vlf_active AS INT)) AS 'Active VLF',
COUNT(l.database_id)-SUM(CAST(vlf_active AS INT)) AS 'Inactive VLF',
SUM(vlf_size_mb) AS 'VLF Size (MB)',
SUM(vlf_active*vlf_size_mb) AS 'Active VLF Size (MB)',
SUM(vlf_size_mb)-SUM(vlf_active*vlf_size_mb) AS 'Inactive VLF Size (MB)'
FROM sys.databases s
CROSS APPLY sys.dm_db_log_info(s.database_id) l
GROUP BY [name]
ORDER BY COUNT(l.database_id)

--========================================
--CHECK IF SQL SERVER INSTANCE IS Running
--===========================================
SELECT [servicename], [status_desc], [startup_type],
case when s.status_desc = 'Running' then 1
	else 0 end as status_desc_int
FROM sys.dm_server_services s;

--==========================================================================
--#Extract information regarding the state of always on availability group
--==========================================================================
SELECT C.name, CS.replica_server_name, CS.join_state_desc, 
RS.role_desc, RS.operational_state_desc, RS.connected_state_desc, 
RS.synchronization_health_desc
FROM sys.availability_groups_cluster AS C
INNER JOIN sys.dm_hadr_availability_replica_cluster_states AS CS
ON CS.group_id = C.group_id
INNER JOIN sys.dm_hadr_availability_replica_states AS RS
ON RS.replica_id = CS.replica_id;


--==================================
--DISABLE INACTIVE USERS
--==================================
Update Users  set isEnabled=0  where DATEDIFF(day, lastLoginDate, GetDate()) > 30
GO
Update Users  set isEnabled=0  where DATEDIFF(day, dateCreated, GetDate()) > 30 and lastLoginDate is null
GO

SELECT s.session_id, s.login_time, s.host_name, s.program_name,
s.login_name, s.nt_user_name, s.is_user_process,
s.database_id, DB_NAME(s.database_id) AS [database], 
s.status,
s.reads, s.writes, s.logical_reads, s.row_count,
c.session_id, c.net_transport, c.protocol_type, 
c.client_net_address, c.client_tcp_port, 
c.num_writes AS DataPacketWrites 
FROM sys.dm_exec_sessions s
INNER JOIN sys.dm_exec_connections c
ON s.session_id = c.session_id 
INNER JOIN sys.dm_exec_requests r 
ON s.session_id = r.session_id;

update sys.server_principals set isEnabled=0  where DATEDIFF(day, lastLoginDate, GetDate()) > 30;



SELECT login_name, max(login_time) as last_logged_in
FROM sys.dm_exec_sessions GROUP BY login_name
sys.dm_exec_sessions;

==========================================
CHECK RUNNING QUERIES IN SQL SERVER
==========================================
SELECT top 5 deqs.last_execution_time AS [Time], dest.TEXT AS [Query]
FROM sys.dm_exec_query_stats AS deqs
CROSS APPLY sys.dm_exec_sql_text(deqs.sql_handle) AS dest
Where dbid = (select database_id from sys.databases Where name = 'TWIGPOSTELLER')
ORDER BY deqs.last_execution_time DESC;

SELECT sqltext.TEXT,
req.session_id,
req.status,
req.command,
req.cpu_time,
req.total_elapsed_time
FROM sys.dm_exec_requests req
CROSS APPLY sys.dm_exec_sql_text(sql_handle) AS sqltext
--where req.command = 'INSERT';


=============================================
VIEW BLOCKING SESSIONS ON SQL SERVER DB
=============================================
SELECT  req.session_id
       ,blocking_session_id
       ,ses.host_name
       ,DB_NAME(req.database_id) AS DB_NAME
       ,ses.login_name
       ,req.status
       ,req.command
       ,req.start_time
       ,req.cpu_time
       ,req.total_elapsed_time / 1000.0 AS total_elapsed_time
       ,req.command
       ,req.wait_type
       ,sqltext.text
FROM    sys.dm_exec_requests req
CROSS APPLY sys.dm_exec_sql_text(sql_handle) AS sqltext
JOIN    sys.dm_exec_sessions ses
        ON ses.session_id = req.session_id
WHERE req.wait_type IS NOT NULL;
--WHERE req.wait_type = '?'


=============================================
CHECK TABLE FRAGMENTATION PERCENT
=============================================
SELECT S.name as 'Schema',
T.name as 'Table',
I.name as 'Index',
DDIPS.avg_fragmentation_in_percent,
DDIPS.page_count
FROM sys.dm_db_index_physical_stats (DB_ID(), NULL, NULL, NULL, NULL) AS DDIPS
INNER JOIN sys.tables T on T.object_id = DDIPS.object_id
INNER JOIN sys.schemas S on T.schema_id = S.schema_id
INNER JOIN sys.indexes I ON I.object_id = DDIPS.object_id
AND DDIPS.index_id = I.index_id
WHERE t.name = 'Table_name_here'
and I.name is not null
AND DDIPS.avg_fragmentation_in_percent > 0
ORDER BY DDIPS.avg_fragmentation_in_percent desc;