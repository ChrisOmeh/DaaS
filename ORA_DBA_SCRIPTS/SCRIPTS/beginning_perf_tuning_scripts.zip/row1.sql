select * from &tab where rowid = '&row_id'
/
