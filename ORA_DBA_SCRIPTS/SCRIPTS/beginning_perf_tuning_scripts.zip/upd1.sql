update t1 set col2 = 'B' where col1 = 1
/
