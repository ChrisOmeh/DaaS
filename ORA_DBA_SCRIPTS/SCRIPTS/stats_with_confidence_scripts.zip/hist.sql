select to_char(stats_update_time,'mm/dd/yy hh24:mi:ss')
from dba_tab_stats_history
where owner = 'ARUP'
and table_name = 'SALES'
/
