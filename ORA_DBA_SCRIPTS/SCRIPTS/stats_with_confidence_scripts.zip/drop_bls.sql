variable ret number
begin
	:ret := dbms_spm.drop_sql_plan_baseline (
		'SQL_11ebc8bc53c0d2fc');
end;
/
begin
	:ret := dbms_spm.drop_sql_plan_baseline (
		'SQL_194746499381d87d');
end;
/
