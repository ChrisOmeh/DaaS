select to_char(last_analyzed,'mm/dd/yy hh24:mi:ss') from user_tables where table_name = 'SALES'
/
