alter session set optimizer_index_cost_adj = &1
/
