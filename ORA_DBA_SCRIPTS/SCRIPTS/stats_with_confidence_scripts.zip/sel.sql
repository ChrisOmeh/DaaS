select state_code, count(1)
from sales
group by state_code
/
