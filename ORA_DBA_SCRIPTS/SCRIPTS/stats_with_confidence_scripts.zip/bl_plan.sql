select * from table(
    dbms_xplan.display_sql_plan_baseline(
        sql_handle=>'SQL_11ebc8bc53c0d2fc',
        format=>'basic note'))
/
pau Press ENTER to continue ...
select * from table(
    dbms_xplan.display_sql_plan_baseline(
        sql_handle=>'SQL_194746499381d87d',
        format=>'basic note'))
/