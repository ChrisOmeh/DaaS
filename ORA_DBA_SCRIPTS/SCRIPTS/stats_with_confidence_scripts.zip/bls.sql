select SQL_HANDLE, PLAN_NAME, accepted, enabled, fixed
from dba_sql_plan_baselines
where SQL_TEXT like 'select * from sales where state_code =%'
/
