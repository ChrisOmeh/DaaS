begin
	dbms_stats.gather_table_stats (
		ownname => 'ARUP',
		tabname => 'SALES',
		estimate_percent => 100,
		cascade => true,
		method_opt => 'for all columns size auto'

);
end;
/
