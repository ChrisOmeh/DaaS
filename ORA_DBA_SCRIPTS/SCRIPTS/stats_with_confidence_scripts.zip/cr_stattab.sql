begin
DBMS_STATS.CREATE_STAT_TABLE (
   ownname  => 'ARUP',
   stattab  => 'STAT_TABLE'
);
end;
/
