drop table sales
/
create table sales
as
select object_id as sales_id,
cast('NY' as varchar2(2)) as state_code
from all_objects
/
update sales
set state_code = 'CT'
where rownum < 2
/
commit;
select state_code, count(1)
from sales
group by state_code
/
create index in_sales_01 on sales (state_code)
/
