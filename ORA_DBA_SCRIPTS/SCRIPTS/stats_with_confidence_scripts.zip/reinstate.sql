set pages 45 lines 132 echo on
prompt check the number of row now
select num_rows from user_tables where table_name = 'SALES'
/
pau
prompt check plan
@@plans
pau
prompt delete records
delete sales where rownum < 70000
/
pau
prompt gather stats
begin
	dbms_stats.gather_table_stats (
		ownname => 'ARUP',
		tabname => 'SALES',
		estimate_percent => 100,
		cascade => true,
		method_opt => 'for all columns size auto'

);
end;
/
pau
prompt check the number of rows now
select num_rows from user_tables where table_name = 'SALES'
pau
prompt check plan
@@plans
pau
prompt check the stats collection history
/
select to_char(stats_update_time,'mm/dd/yy hh24:mi:ss')
from dba_tab_stats_history
where owner = 'ARUP'
and table_name = 'SALES'
/
pau
prompt Now reinstate an older stat set
begin
   dbms_stats.restore_table_stats (
       ownname         => 'ARUP',
       tabname         => 'SALES',
       as_of_timestamp => '01-MAR-10 10:34:34 PM'
   );
end;
/
pau
prompt check for number of rows now
select num_rows from user_tables where table_name = 'SALES'
/
pau
prompt check plan
@@plans
