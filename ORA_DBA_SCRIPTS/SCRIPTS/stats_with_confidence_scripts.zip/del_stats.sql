begin
	dbms_stats.delete_table_stats (
		ownname => 'ARUP',
		tabname => 'SALES',
		cascade_indexes => true,
		cascade_columns => true
);
end;
/
