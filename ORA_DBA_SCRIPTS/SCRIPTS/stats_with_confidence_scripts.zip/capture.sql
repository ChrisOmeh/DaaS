alter session set optimizer_capture_sql_plan_baselines = true
/
