begin
DBMS_STATS.IMPORT_TABLE_STATS (
	ownname    => 'ARUP',
    tabname    => 'SALES',
    stattab    => 'STAT_TABLE',
	cascade	   => true
);
end;
/
