begin
   dbms_stats.publish_pending_stats
      ('ARUP', 'SALES');
end;
/
