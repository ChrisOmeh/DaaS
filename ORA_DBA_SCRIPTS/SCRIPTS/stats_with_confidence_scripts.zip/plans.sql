set echo on lines 132
explain plan for select * from sales where state_code = 'NY'
/
pau "Press ENTER to continue ..."
select * from table(dbms_xplan.display())
/
explain plan for select * from sales where state_code = 'CT'
/
pau "Press ENTER to continue ..."
select * from table(dbms_xplan.display())
/
