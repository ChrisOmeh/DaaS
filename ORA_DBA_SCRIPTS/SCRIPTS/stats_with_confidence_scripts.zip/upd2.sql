update sales set state_code = decode(state_code,'CT','NY','NY','CT',null)
/
