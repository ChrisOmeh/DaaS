update sales set state_code = decode(state_code,'NY','CT','CT','NY',null)
/
