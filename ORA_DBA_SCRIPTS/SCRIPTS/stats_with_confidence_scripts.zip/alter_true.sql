alter session set optimizer_use_pending_statistics = true
/
