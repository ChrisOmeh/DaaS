begin
DBMS_STATS.EXPORT_PENDING_STATS (
    tabname    => 'SALES',
    stattab    => 'STAT_TABLE'
);
end;
/
