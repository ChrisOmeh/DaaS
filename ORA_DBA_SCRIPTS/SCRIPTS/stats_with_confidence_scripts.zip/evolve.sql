set long 9999
var rep clob
begin
   :rep := dbms_spm.evolve_sql_plan_baseline (
           sql_handle => 'SQL_194746499381d87d',
           verify => 'NO'
   );
end;
/
print rep
pau "Press ENTER to continue ..."
begin
   :rep := dbms_spm.evolve_sql_plan_baseline (
           sql_handle => 'SQL_11ebc8bc53c0d2fc',
           verify => 'NO'
   );
end;
/
print rep