select hotel_id, rate_code, count(1)
from bookings
group by hotel_id, rate_code
order by hotel_id, rate_code
/
