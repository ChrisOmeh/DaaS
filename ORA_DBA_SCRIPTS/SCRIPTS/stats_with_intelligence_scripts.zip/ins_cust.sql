declare
	l_num_of_rows	constant number := 1000000;
	l_rand 			number;
	l_last_name		customers.last_name%type;
begin
	for ctr in 1 .. l_num_of_rows loop
		l_rand := floor(dbms_random.value(1,11));
		l_last_name := 
		case 
			when (l_rand > 1 and l_rand <= 2) then 'McDonald'
			when (l_rand > 2 and l_rand <= 4) then 'MCDONALD'
			when (l_rand > 4 and l_rand <= 5) then 'McDONALD'
			when (l_rand > 5 and l_rand <= 6) then 'mcdonald'
		else
			dbms_random.string('A',30)
		end;
		insert into customers
		values
		(
			dbms_random.string('A',30),
			l_last_name
		);
	end loop;
end;
/
