create index in_bookings_01 on bookings (hotel_id,rate_code)
/
