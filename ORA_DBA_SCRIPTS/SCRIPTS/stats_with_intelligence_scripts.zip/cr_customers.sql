create table customers (
	first_name	varchar2(30),
	last_name	varchar2(30)
)
/
