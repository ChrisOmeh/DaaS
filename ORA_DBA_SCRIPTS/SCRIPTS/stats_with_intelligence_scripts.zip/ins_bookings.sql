declare
	l_no_of_bookings		constant number := 1000000;
	l_book_amt				number;
	l_hotel_id				number(2);
	l_rate_code				number(2);
	l_rand					number;
begin
	for ctr in 1 .. l_no_of_bookings loop
		l_rand := dbms_random.value(1,100);
		l_hotel_id :=
			case 
				when l_rand < 50 then 10
			else
				20
			end;
		l_rate_code := 
			case l_hotel_id
				when 10 then 
					case 
				    	when l_rand < 45 then 11
						when l_rand < 90 then 12
					else
						13
					end
				when 20 then 
					case 
				    	when l_rand < 30 then 21
						when l_rand < 60 then 22
					else
						23
					end
				else
					30
				end
			;
		l_book_amt := 
			case l_rate_code
				when 11 then floor(dbms_random.value(100,200))
				when 12 then floor(dbms_random.value(200,300))
				when 13 then floor(dbms_random.value(300,400))
				when 21 then floor(dbms_random.value(1000,2000))
				when 22 then floor(dbms_random.value(2000,3000))
				when 23 then floor(dbms_random.value(3000,4000))
				else 0
			end;
		insert into bookings
		values
		(
			ctr,
			l_hotel_id,
			l_rate_code,
			l_book_amt
		);
	end loop;
end;
/
