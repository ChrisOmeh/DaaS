begin
	:ret := dbms_stats.create_extended_stats (
		'ARUP', 'BOOKINGS','(HOTEL_ID, RATE_CODE)');
end;
/
