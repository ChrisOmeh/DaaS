explain plan for
select min(book_txn)
from bookings
where hotel_id = &hotel_id
and rate_Code = &rate_code
/
select * from table(dbms_xplan.display())
/
