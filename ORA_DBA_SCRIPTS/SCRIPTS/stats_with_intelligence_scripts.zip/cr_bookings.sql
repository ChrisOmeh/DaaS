create table bookings
(
	booking_id	number,
	hotel_id	number(2),
	rate_code	number(2),
	book_txn	number
)
/
