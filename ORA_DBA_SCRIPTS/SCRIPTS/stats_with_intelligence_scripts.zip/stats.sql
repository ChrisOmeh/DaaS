begin
	dbms_stats.gather_table_stats (
		ownname	=> 'ARUP',
		tabname	=> 'BOOKINGS',
		estimate_percent	=> 100,
		method_opt			=> 'FOR ALL COLUMNS SIZE SKEWONLY',
		cascade			=> true
	);
end;
/
