explain plan for select * from customers where upper(last_name) = 'MCDONALD'
/
select * from table(dbms_xplan.display())
/
