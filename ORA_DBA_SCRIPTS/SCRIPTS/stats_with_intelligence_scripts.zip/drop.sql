begin
   dbms_stats.drop_extended_stats (
      ownname => 'ARUP',
      tabname => 'BOOKINGS',
      extension => '("HOTEL_ID","RATE_CODE")'
   );
end;
/
