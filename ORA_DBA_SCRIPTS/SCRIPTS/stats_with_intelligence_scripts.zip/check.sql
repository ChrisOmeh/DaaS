select extension_name, extension
from dba_stat_extensions
where table_name='BOOKINGS'
/
