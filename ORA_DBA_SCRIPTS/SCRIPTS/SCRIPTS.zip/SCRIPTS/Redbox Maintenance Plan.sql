============================================================
REDBOX AND INTERNET BANKING DATABASES MAINTENANCE PLAN
=============================================================

-- TABLESPACE = REDBOXTBS_DATA Every monthly
--REDBOX.RBX_P_REQ_MGR_D_LOG260623 -- SYS_LOB0000564762C00005$$
--REDBOX.RBX_P_FIN_BETA_LOG   -- SYS_LOB0000635126C00005$$
--REDBOX.RBX_P_NIBBS_BVN_VALIDATION  -- SYS_LOB0000232813C00006$$
---REDBOX.RBX_P_FIN_BETA_LOG  -- SYS_LOB0000635126C00003$$
---REDBOX.RBX_P_GENERIC_TRANSFER_LOG  -- SYS_LOB0000565029C00012$$
--RBX_A_CHN_ACTIVITY_LOG and RBX_P_NIPOUT_LOG  

--Archival of RBX_A_CHN_ACTIVITY_LOG and RBX_P_REQ_MGR_D_LOG should be done monthly
--Compliance report from python script.
--Check python script to and note it was done using 12c. So, we need to allign with 19c standard.
--Upgrade of postilion.


--===============================================================================================
-------------------------------------------PNGFIB------------------------------------------------
--===============================================================================================

OWNER		TABL_NAME					TYPE				TABLESPACE_NAME			SIZE_GB
ECECUSER	AUDIT_SERVICE_DATA_TABLE	TABLE PARTITION	MORE THAN 1 TABLESPACE		2,581
ECECUSER	CUSTAUDITTBL				TABLE				HISTORY					1,215
ECECUSER	AUDIT_TABLE					TABLE				HISTORY					469
ECECUSER	TRANSACTION_DETAILS			TABLE				MASTER					88
SYS			AUD$						TABLE				SYSTEM					87
ECECUSER	TRANSACTION_REQUEST_DETAILS	TABLE				MASTER					81
ECECUSER	TRANSACTION_REQUEST_HEADER	TABLE				MASTER					75
ECECUSER	TRANSACTION_HEADER			TABLE				MASTER					75

--==========================
--TABLE 1
--=========================
ALTER TABLE ECECUSER.AUDIT_SERVICE_DATA_TABLE RENAME TO AUDIT_SERVICE_DATA_TABLE_05JUL23BKP;
ALTER INDEX ECECUSER.IDX_ASDT02 RENAME TO IDX_ASDT02_05JUL23BKP;
ALTER INDEX ECECUSER.IDX_ACTVTY_INQRY02 RENAME TO IDX_ACTVTY_INQRY02_05JUL23BKP;
ALTER INDEX ECECUSER.IDX_ASDT_INQRY02 RENAME TO IDX_ASDT_INQRY02_05JUL23BKP;

CREATE TABLE ECECUSER.AUDIT_SERVICE_DATA_TABLE
(
  DB_TS               NUMBER(5),
  BANK_ID             NVARCHAR2(11)             NOT NULL,
  LOG_SRL_NUM         NUMBER(10)                NOT NULL,
  SERVICE_SEQ_NUM     NUMBER(10)                NOT NULL,
  ACTIVITY_ID         NVARCHAR2(80),
  ACTIVITY_DESC       NVARCHAR2(255),
  SERVICE_DATA        CLOB,
  TRANSACTION_KEY     NVARCHAR2(255),
  PRIMARY_TABLE_NAME  NVARCHAR2(65),
  STATUS              NVARCHAR2(10),
  MESSAGE             NVARCHAR2(255),
  ADDITIONAL_INFO     CLOB,
  MODULE_NAME         NVARCHAR2(255),
  R_CRE_ID            NVARCHAR2(65),
  R_CRE_TIME          DATE,
  ACTUAL_USER_ID      NVARCHAR2(65)
)
LOB (ADDITIONAL_INFO) STORE AS SECUREFILE (
  TABLESPACE  HISTORY
  ENABLE      STORAGE IN ROW
  CHUNK       8192
  RETENTION
  NOCACHE
  NOLOGGING)
LOB (SERVICE_DATA) STORE AS SECUREFILE (
  TABLESPACE  HISTORY
  ENABLE      STORAGE IN ROW
  CHUNK       8192
  RETENTION
  NOCACHE
  NOLOGGING)
NOCOMPRESS 
TABLESPACE HISTORY
PCTFREE    10
INITRANS   100
MAXTRANS   255
STORAGE    (
            INITIAL          10M
            NEXT             10M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING
PARTITION BY RANGE (R_CRE_TIME)
INTERVAL (NUMTOYMINTERVAL(1, 'MONTH'))
(  
  PARTITION VALUES LESS THAN (TO_DATE(' 2022-06-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN'))
    LOGGING
    NOCOMPRESS 
    TABLESPACE HISTORY
    LOB (ADDITIONAL_INFO) STORE AS SECUREFILE (
      TABLESPACE  HISTORY
      ENABLE      STORAGE IN ROW
      CHUNK       8192
      RETENTION
      NOCACHE
      LOGGING)
    LOB (SERVICE_DATA) STORE AS SECUREFILE (
      TABLESPACE  HISTORY
      ENABLE      STORAGE IN ROW
      CHUNK       8192
      RETENTION
      NOCACHE
      LOGGING)
    PCTFREE    10
    INITRANS   100
    MAXTRANS   255
    STORAGE    (
                INITIAL          10M
                NEXT             10M
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                BUFFER_POOL      DEFAULT
               ),  
  PARTITION VALUES LESS THAN (TO_DATE(' 2022-07-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN'))
    LOGGING
    NOCOMPRESS 
    TABLESPACE HISTORY
    LOB (ADDITIONAL_INFO) STORE AS SECUREFILE (
      TABLESPACE  HISTORY
      ENABLE      STORAGE IN ROW
      CHUNK       8192
      RETENTION
      NOCACHE
      LOGGING)
    LOB (SERVICE_DATA) STORE AS SECUREFILE (
      TABLESPACE  HISTORY
      ENABLE      STORAGE IN ROW
      CHUNK       8192
      RETENTION
      NOCACHE
      LOGGING)
    PCTFREE    10
    INITRANS   100
    MAXTRANS   255
    STORAGE    (
                INITIAL          10M
                NEXT             10M
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                BUFFER_POOL      DEFAULT
               ),  
  PARTITION VALUES LESS THAN (TO_DATE(' 2022-08-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN'))
    LOGGING
    NOCOMPRESS 
    TABLESPACE HISTORY
    LOB (ADDITIONAL_INFO) STORE AS SECUREFILE (
      TABLESPACE  HISTORY
      ENABLE      STORAGE IN ROW
      CHUNK       8192
      RETENTION
      NOCACHE
      LOGGING)
    LOB (SERVICE_DATA) STORE AS SECUREFILE (
      TABLESPACE  HISTORY
      ENABLE      STORAGE IN ROW
      CHUNK       8192
      RETENTION
      NOCACHE
      LOGGING)
    PCTFREE    10
    INITRANS   100
    MAXTRANS   255
    STORAGE    (
                INITIAL          10M
                NEXT             10M
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                BUFFER_POOL      DEFAULT
               ),  
  PARTITION VALUES LESS THAN (TO_DATE(' 2022-09-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN'))
    LOGGING
    NOCOMPRESS 
    TABLESPACE HISTORY
    LOB (ADDITIONAL_INFO) STORE AS SECUREFILE (
      TABLESPACE  HISTORY
      ENABLE      STORAGE IN ROW
      CHUNK       8192
      RETENTION
      NOCACHE
      LOGGING)
    LOB (SERVICE_DATA) STORE AS SECUREFILE (
      TABLESPACE  HISTORY
      ENABLE      STORAGE IN ROW
      CHUNK       8192
      RETENTION
      NOCACHE
      LOGGING)
    PCTFREE    10
    INITRANS   100
    MAXTRANS   255
    STORAGE    (
                INITIAL          10M
                NEXT             10M
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                BUFFER_POOL      DEFAULT
               ),  
  PARTITION VALUES LESS THAN (TO_DATE(' 2022-10-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN'))
    LOGGING
    NOCOMPRESS 
    TABLESPACE HISTORY
    LOB (ADDITIONAL_INFO) STORE AS SECUREFILE (
      TABLESPACE  HISTORY
      ENABLE      STORAGE IN ROW
      CHUNK       8192
      RETENTION
      NOCACHE
      LOGGING)
    LOB (SERVICE_DATA) STORE AS SECUREFILE (
      TABLESPACE  HISTORY
      ENABLE      STORAGE IN ROW
      CHUNK       8192
      RETENTION
      NOCACHE
      LOGGING)
    PCTFREE    10
    INITRANS   100
    MAXTRANS   255
    STORAGE    (
                INITIAL          10M
                NEXT             10M
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                BUFFER_POOL      DEFAULT
               ),  
  PARTITION VALUES LESS THAN (TO_DATE(' 2022-11-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN'))
    LOGGING
    NOCOMPRESS 
    TABLESPACE HISTORY
    LOB (ADDITIONAL_INFO) STORE AS SECUREFILE (
      TABLESPACE  HISTORY
      ENABLE      STORAGE IN ROW
      CHUNK       8192
      RETENTION
      NOCACHE
      LOGGING)
    LOB (SERVICE_DATA) STORE AS SECUREFILE (
      TABLESPACE  HISTORY
      ENABLE      STORAGE IN ROW
      CHUNK       8192
      RETENTION
      NOCACHE
      LOGGING)
    PCTFREE    10
    INITRANS   100
    MAXTRANS   255
    STORAGE    (
                INITIAL          10M
                NEXT             10M
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                BUFFER_POOL      DEFAULT
               ),  
  PARTITION VALUES LESS THAN (TO_DATE(' 2022-12-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN'))
    LOGGING
    NOCOMPRESS 
    TABLESPACE HISTORY
    LOB (ADDITIONAL_INFO) STORE AS SECUREFILE (
      TABLESPACE  HISTORY
      ENABLE      STORAGE IN ROW
      CHUNK       8192
      RETENTION
      NOCACHE
      LOGGING)
    LOB (SERVICE_DATA) STORE AS SECUREFILE (
      TABLESPACE  HISTORY
      ENABLE      STORAGE IN ROW
      CHUNK       8192
      RETENTION
      NOCACHE
      LOGGING)
    PCTFREE    10
    INITRANS   100
    MAXTRANS   255
    STORAGE    (
                INITIAL          10M
                NEXT             10M
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                BUFFER_POOL      DEFAULT
               ),  
  PARTITION VALUES LESS THAN (TO_DATE(' 2023-01-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN'))
    LOGGING
    NOCOMPRESS 
    TABLESPACE HISTORY
    LOB (ADDITIONAL_INFO) STORE AS SECUREFILE (
      TABLESPACE  HISTORY
      ENABLE      STORAGE IN ROW
      CHUNK       8192
      RETENTION
      NOCACHE
      LOGGING
      STORAGE    (
                  INITIAL          8M
                  NEXT             1M
                  MINEXTENTS       1
                  MAXEXTENTS       UNLIMITED
                  PCTINCREASE      0
                  BUFFER_POOL      DEFAULT
                 ))
    LOB (SERVICE_DATA) STORE AS SECUREFILE (
      TABLESPACE  HISTORY
      ENABLE      STORAGE IN ROW
      CHUNK       8192
      RETENTION
      NOCACHE
      LOGGING
      STORAGE    (
                  INITIAL          8M
                  NEXT             1M
                  MINEXTENTS       1
                  MAXEXTENTS       UNLIMITED
                  PCTINCREASE      0
                  BUFFER_POOL      DEFAULT
                 ))
    PCTFREE    10
    INITRANS   100
    MAXTRANS   255
    STORAGE    (
                INITIAL          10M
                NEXT             10M
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                BUFFER_POOL      DEFAULT
               ),  
  PARTITION VALUES LESS THAN (TO_DATE(' 2023-02-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN'))
    LOGGING
    NOCOMPRESS 
    TABLESPACE HISTORY
    LOB (ADDITIONAL_INFO) STORE AS SECUREFILE (
      TABLESPACE  HISTORY
      ENABLE      STORAGE IN ROW
      CHUNK       8192
      RETENTION
      NOCACHE
      LOGGING
      STORAGE    (
                  INITIAL          8M
                  NEXT             1M
                  MINEXTENTS       1
                  MAXEXTENTS       UNLIMITED
                  PCTINCREASE      0
                  BUFFER_POOL      DEFAULT
                 ))
    LOB (SERVICE_DATA) STORE AS SECUREFILE (
      TABLESPACE  HISTORY
      ENABLE      STORAGE IN ROW
      CHUNK       8192
      RETENTION
      NOCACHE
      LOGGING
      STORAGE    (
                  INITIAL          8M
                  NEXT             1M
                  MINEXTENTS       1
                  MAXEXTENTS       UNLIMITED
                  PCTINCREASE      0
                  BUFFER_POOL      DEFAULT
                 ))
    PCTFREE    10
    INITRANS   100
    MAXTRANS   255
    STORAGE    (
                INITIAL          10M
                NEXT             10M
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                BUFFER_POOL      DEFAULT
               ),  
  PARTITION VALUES LESS THAN (TO_DATE(' 2023-03-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN'))
    LOGGING
    NOCOMPRESS 
    TABLESPACE HISTORY
    LOB (ADDITIONAL_INFO) STORE AS SECUREFILE (
      TABLESPACE  HISTORY
      ENABLE      STORAGE IN ROW
      CHUNK       8192
      RETENTION
      NOCACHE
      LOGGING
      STORAGE    (
                  INITIAL          8M
                  NEXT             1M
                  MINEXTENTS       1
                  MAXEXTENTS       UNLIMITED
                  PCTINCREASE      0
                  BUFFER_POOL      DEFAULT
                 ))
    LOB (SERVICE_DATA) STORE AS SECUREFILE (
      TABLESPACE  HISTORY
      ENABLE      STORAGE IN ROW
      CHUNK       8192
      RETENTION
      NOCACHE
      LOGGING
      STORAGE    (
                  INITIAL          8M
                  NEXT             1M
                  MINEXTENTS       1
                  MAXEXTENTS       UNLIMITED
                  PCTINCREASE      0
                  BUFFER_POOL      DEFAULT
                 ))
    PCTFREE    10
    INITRANS   100
    MAXTRANS   255
    STORAGE    (
                INITIAL          10M
                NEXT             10M
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                BUFFER_POOL      DEFAULT
               ),  
  PARTITION VALUES LESS THAN (TO_DATE(' 2023-04-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN'))
    LOGGING
    NOCOMPRESS 
    TABLESPACE HISTORY
    LOB (ADDITIONAL_INFO) STORE AS SECUREFILE (
      TABLESPACE  HISTORY
      ENABLE      STORAGE IN ROW
      CHUNK       8192
      RETENTION
      NOCACHE
      LOGGING
      STORAGE    (
                  INITIAL          8M
                  NEXT             1M
                  MINEXTENTS       1
                  MAXEXTENTS       UNLIMITED
                  PCTINCREASE      0
                  BUFFER_POOL      DEFAULT
                 ))
    LOB (SERVICE_DATA) STORE AS SECUREFILE (
      TABLESPACE  HISTORY
      ENABLE      STORAGE IN ROW
      CHUNK       8192
      RETENTION
      NOCACHE
      LOGGING
      STORAGE    (
                  INITIAL          8M
                  NEXT             1M
                  MINEXTENTS       1
                  MAXEXTENTS       UNLIMITED
                  PCTINCREASE      0
                  BUFFER_POOL      DEFAULT
                 ))
    PCTFREE    10
    INITRANS   100
    MAXTRANS   255
    STORAGE    (
                INITIAL          10M
                NEXT             10M
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                BUFFER_POOL      DEFAULT
               ),  
  PARTITION VALUES LESS THAN (TO_DATE(' 2023-05-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN'))
    LOGGING
    NOCOMPRESS 
    TABLESPACE HISTORY
    LOB (ADDITIONAL_INFO) STORE AS SECUREFILE (
      TABLESPACE  HISTORY
      ENABLE      STORAGE IN ROW
      CHUNK       8192
      RETENTION
      NOCACHE
      LOGGING
      STORAGE    (
                  INITIAL          8M
                  NEXT             1M
                  MINEXTENTS       1
                  MAXEXTENTS       UNLIMITED
                  PCTINCREASE      0
                  BUFFER_POOL      DEFAULT
                 ))
    LOB (SERVICE_DATA) STORE AS SECUREFILE (
      TABLESPACE  HISTORY
      ENABLE      STORAGE IN ROW
      CHUNK       8192
      RETENTION
      NOCACHE
      LOGGING
      STORAGE    (
                  INITIAL          8M
                  NEXT             1M
                  MINEXTENTS       1
                  MAXEXTENTS       UNLIMITED
                  PCTINCREASE      0
                  BUFFER_POOL      DEFAULT
                 ))
    PCTFREE    10
    INITRANS   100
    MAXTRANS   255
    STORAGE    (
                INITIAL          10M
                NEXT             10M
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                BUFFER_POOL      DEFAULT
               ),  
  PARTITION VALUES LESS THAN (TO_DATE(' 2023-06-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN'))
    LOGGING
    NOCOMPRESS 
    TABLESPACE HISTORY
    LOB (ADDITIONAL_INFO) STORE AS SECUREFILE (
      TABLESPACE  HISTORY
      ENABLE      STORAGE IN ROW
      CHUNK       8192
      RETENTION
      NOCACHE
      LOGGING
      STORAGE    (
                  INITIAL          8M
                  NEXT             1M
                  MINEXTENTS       1
                  MAXEXTENTS       UNLIMITED
                  PCTINCREASE      0
                  BUFFER_POOL      DEFAULT
                 ))
    LOB (SERVICE_DATA) STORE AS SECUREFILE (
      TABLESPACE  HISTORY
      ENABLE      STORAGE IN ROW
      CHUNK       8192
      RETENTION
      NOCACHE
      LOGGING
      STORAGE    (
                  INITIAL          8M
                  NEXT             1M
                  MINEXTENTS       1
                  MAXEXTENTS       UNLIMITED
                  PCTINCREASE      0
                  BUFFER_POOL      DEFAULT
                 ))
    PCTFREE    10
    INITRANS   100
    MAXTRANS   255
    STORAGE    (
                INITIAL          10M
                NEXT             10M
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                BUFFER_POOL      DEFAULT
               ),  
  PARTITION VALUES LESS THAN (TO_DATE(' 2023-07-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN'))
    LOGGING
    NOCOMPRESS 
    TABLESPACE HISTORY
    LOB (ADDITIONAL_INFO) STORE AS SECUREFILE (
      TABLESPACE  HISTORY
      ENABLE      STORAGE IN ROW
      CHUNK       8192
      RETENTION
      NOCACHE
      LOGGING
      STORAGE    (
                  INITIAL          8M
                  NEXT             1M
                  MINEXTENTS       1
                  MAXEXTENTS       UNLIMITED
                  PCTINCREASE      0
                  BUFFER_POOL      DEFAULT
                 ))
    LOB (SERVICE_DATA) STORE AS SECUREFILE (
      TABLESPACE  HISTORY
      ENABLE      STORAGE IN ROW
      CHUNK       8192
      RETENTION
      NOCACHE
      LOGGING
      STORAGE    (
                  INITIAL          8M
                  NEXT             1M
                  MINEXTENTS       1
                  MAXEXTENTS       UNLIMITED
                  PCTINCREASE      0
                  BUFFER_POOL      DEFAULT
                 ))
    PCTFREE    10
    INITRANS   100
    MAXTRANS   255
    STORAGE    (
                INITIAL          10M
                NEXT             10M
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                BUFFER_POOL      DEFAULT
               ),  
  PARTITION VALUES LESS THAN (TO_DATE(' 2023-08-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN'))
    LOGGING
    NOCOMPRESS 
    TABLESPACE HISTORY
    LOB (ADDITIONAL_INFO) STORE AS SECUREFILE (
      TABLESPACE  HISTORY
      ENABLE      STORAGE IN ROW
      CHUNK       8192
      RETENTION
      NOCACHE
      LOGGING
      STORAGE    (
                  INITIAL          8M
                  NEXT             1M
                  MINEXTENTS       1
                  MAXEXTENTS       UNLIMITED
                  PCTINCREASE      0
                  BUFFER_POOL      DEFAULT
                 ))
    LOB (SERVICE_DATA) STORE AS SECUREFILE (
      TABLESPACE  HISTORY
      ENABLE      STORAGE IN ROW
      CHUNK       8192
      RETENTION
      NOCACHE
      LOGGING
      STORAGE    (
                  INITIAL          8M
                  NEXT             1M
                  MINEXTENTS       1
                  MAXEXTENTS       UNLIMITED
                  PCTINCREASE      0
                  BUFFER_POOL      DEFAULT
                 ))
    PCTFREE    10
    INITRANS   100
    MAXTRANS   255
    STORAGE    (
                INITIAL          10M
                NEXT             10M
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                BUFFER_POOL      DEFAULT
               )
)
NOCACHE;


CREATE UNIQUE INDEX ECECUSER.IDX_ASDT02 ON ECECUSER.AUDIT_SERVICE_DATA_TABLE
(LOG_SRL_NUM, SERVICE_SEQ_NUM, BANK_ID)
LOGGING
TABLESPACE IDX_HISTORY
PCTFREE    10
INITRANS   100
MAXTRANS   255
STORAGE    (
            INITIAL          100M
            NEXT             500M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           );

ALTER TABLE ECECUSER.AUDIT_SERVICE_DATA_TABLE ADD (
  CONSTRAINT ASDTDB_TS02
  CHECK (DB_TS BETWEEN 1 and 99999 or DB_TS = 0 )
  DISABLE NOVALIDATE
,  CONSTRAINT ASDTLOG_SRL_NUM02
  CHECK (LOG_SRL_NUM BETWEEN 1 and 99999999999999 or LOG_SRL_NUM = 0 )
  DISABLE NOVALIDATE
,  CONSTRAINT ASDTSERVICE_SEQ_NUM02
  CHECK (SERVICE_SEQ_NUM BETWEEN 1 and 9999999999 or SERVICE_SEQ_NUM = 0 )
  DISABLE NOVALIDATE
,  CONSTRAINT ASDTSTATUSCON02
  CHECK (REGEXP_count(STATUS,'[[:alpha:][:space:][:punct:]]')=length(STATUS))
  DISABLE NOVALIDATE);


CREATE INDEX ECECUSER.IDX_ACTVTY_INQRY02 ON ECECUSER.AUDIT_SERVICE_DATA_TABLE
(ACTIVITY_ID, R_CRE_TIME)
LOGGING
TABLESPACE IDX_HISTORY
PCTFREE    10
INITRANS   100
MAXTRANS   255
STORAGE    (
            INITIAL          9600M
            NEXT             500M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           );

CREATE INDEX ECECUSER.IDX_ASDT_INQRY02 ON ECECUSER.AUDIT_SERVICE_DATA_TABLE
(LOG_SRL_NUM, BANK_ID)
LOGGING
TABLESPACE IDX_HISTORY
PCTFREE    10
INITRANS   100
MAXTRANS   255
STORAGE    (
            INITIAL          9600M
            NEXT             500M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           );

CREATE OR REPLACE SYNONYM ECECUSER.ASDT FOR ECECUSER.AUDIT_SERVICE_DATA_TABLE;



--====================================
--TABLE 2 ECECUSER.CUSTAUDITTBL
--====================================

ALTER TABLE ECECUSER.CUSTAUDITTBL RENAME TO CUSTAUDITTBL_05JUL23BKP;
ALTER INDEX ECECUSER.IDX_CADT13 RENAME TO IDX_CADT13_05JUL23BKP;
ALTER INDEX ECECUSER.IDX_CUSTADTTBL_NEW_TBL_KEY2 RENAME TO IDX_CUSTADTTBL_NEW_TBL_KEY2_05JUL23BKP;

CREATE TABLE ECECUSER.CUSTAUDITTBL
(
  BANK_ID             NVARCHAR2(11)             NOT NULL,
  ADT_SRL_NO          NUMBER(14)                NOT NULL,
  LOG_SRL_NO          NUMBER(14)                NOT NULL,
  TBL_NAME            NVARCHAR2(6),
  TBL_KEY             NVARCHAR2(1024),
  AUDIT_FLG           NVARCHAR2(3),
  FUNC_CODE           CHAR(1 BYTE),
  ACCESS_CHANNEL      CHAR(1 BYTE),
  SESSION_ID          NVARCHAR2(100),
  IPADDRESS           NVARCHAR2(45),
  SESSION_START_TIME  DATE,
  R_CRE_ID            NVARCHAR2(65),
  R_CRE_TIME          DATE,
  CUR_REC             CLOB,
  FREE_TEXT_1         NVARCHAR2(256),
  FREE_TEXT_2         NVARCHAR2(256),
  ACTUAL_USER_ID      NVARCHAR2(65),
  SUPPLEMENTAL LOG GROUP GGS_CUSTAUDITTBL2 (BANK_ID,ADT_SRL_NO,LOG_SRL_NO) ALWAYS
)
LOB (CUR_REC) STORE AS SECUREFILE (
  TABLESPACE  HISTORY
  ENABLE      STORAGE IN ROW
  CHUNK       8192
  RETENTION
  NOCACHE
  LOGGING
  STORAGE    (
              INITIAL          104K
              NEXT             1M
              MINEXTENTS       1
              MAXEXTENTS       UNLIMITED
              PCTINCREASE      0
              BUFFER_POOL      DEFAULT
             ))
TABLESPACE HISTORY
PCTFREE    10
INITRANS   50
MAXTRANS   255
STORAGE    (
            INITIAL          10M
            NEXT             10M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE;


CREATE UNIQUE INDEX ECECUSER.IDX_CADT13 ON ECECUSER.CUSTAUDITTBL
(ADT_SRL_NO, LOG_SRL_NO, BANK_ID)
LOGGING
TABLESPACE IDX_HISTORY
PCTFREE    10
INITRANS   50
MAXTRANS   255
STORAGE    (
            INITIAL          10M
            NEXT             10M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           );

ALTER TABLE ECECUSER.CUSTAUDITTBL ADD (
  CONSTRAINT CADTACCESS_CHANNEL2
  CHECK (REGEXP_count(ACCESS_CHANNEL,'[AMGSIWTHU]')=1)
  DISABLE NOVALIDATE
,  CONSTRAINT CADTADT_SRL_NO2
  CHECK (ADT_SRL_NO BETWEEN 1 and 99999999999999 or ADT_SRL_NO = 0 )
  DISABLE NOVALIDATE
,  CONSTRAINT CADTFUNC_CODE2
  CHECK (REGEXP_count(FUNC_CODE,'[ADMLU]')=1)
  DISABLE NOVALIDATE
,  CONSTRAINT CADTLOG_SRL_NO2
  CHECK (LOG_SRL_NO BETWEEN 0 and 99999999999999 or LOG_SRL_NO = 0 )
  DISABLE NOVALIDATE
,  CONSTRAINT CADTTBL_NAMECASE2
  CHECK (TBL_NAME = upper(TBL_NAME)
)
  DISABLE NOVALIDATE
,  CONSTRAINT CADTTBL_NAMECON2
  CHECK (REGEXP_count(TBL_NAME,'[[:alpha:][:space:][:punct:]]')=length(TBL_NAME))
  DISABLE NOVALIDATE);


CREATE INDEX ECECUSER.IDX_CUSTADTTBL_NEW_TBL_KEY2 ON ECECUSER.CUSTAUDITTBL
(AUDIT_FLG, LOG_SRL_NO)
LOGGING
TABLESPACE IDX_HISTORY
PCTFREE    10
INITRANS   50
MAXTRANS   255
STORAGE    (
            INITIAL          10M
            NEXT             10M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           );

CREATE OR REPLACE SYNONYM ECECUSER.CADT FOR ECECUSER.CUSTAUDITTBL;


--===============================
---TABLE 3  ECECUSER.AUDIT_TABLE
--===============================

ALTER TABLE ECECUSER.AUDIT_TABLE RENAME TO ECECUSER.AUDIT_TABLE_05JUL23BKP;;
ALTER INDEX ECECUSER.IDX_ADTT02 RENAME TO IDX_ADTT02_05JUL23BKP;
ALTER INDEX ECECUSER.IDX_EVNT_INQRY02 RENAME TO IDX_EVNT_INQRY02_05JUL23BKP;
ALTER INDEX ECECUSER.IDX_USRTYP_INQRY02 RENAME TO IDX_USRTYP_INQRY02_05JUL23BKP;
ALTER INDEX ECECUSER.IDX_USR_INQRY02 RENAME TO IDX_USR_INQRY02_05JUL23BKP;


CREATE TABLE ECECUSER.AUDIT_TABLE
(
  BANK_ID              NVARCHAR2(11)            NOT NULL,
  LOG_SRL_NUM          NUMBER(10)               NOT NULL,
  EVENT_ID             NVARCHAR2(161),
  EVENT_DESC           NVARCHAR2(255),
  EVENT_SEQNO          NUMBER(10),
  OLD_FORM_DATA        CLOB,
  FORM_DATA            CLOB,
  REQUEST_MODE         CHAR(1 BYTE),
  SESSION_ID           NVARCHAR2(100),
  CORP_ID              NVARCHAR2(32),
  USER_ID              NVARCHAR2(32),
  CLNT_IP_ADDR         NVARCHAR2(45),
  CLNT_BROWSER_TYPE    NVARCHAR2(255),
  ACCESS_CHANNEL       CHAR(1 BYTE),
  MOBILE_NUMBER        NVARCHAR2(16),
  USER_TYPE            NVARCHAR2(10),
  AUTHORIZATION_MODE   NVARCHAR2(4),
  APP_ID               NVARCHAR2(9),
  THREAD_ID            NVARCHAR2(255),
  OPERATION            NVARCHAR2(10),
  MODULE_NAME          NVARCHAR2(255),
  IF_SIGNED            CHAR(1 BYTE),
  SIGNATURE            CLOB,
  SIGNATURE_CONTENT    CLOB,
  TIME_STAMP_RESPONSE  CLOB,
  SIGNATURE_VALIDITY   CHAR(1 BYTE),
  FREE_TEXT_1          CLOB,
  R_CRE_ID             NVARCHAR2(65),
  R_CRE_TIME           DATE,
  ACTUAL_USER_ID       NVARCHAR2(65),
  SUPPLEMENTAL LOG GROUP GGS_REPLC (BANK_ID,LOG_SRL_NUM) ALWAYS
)
LOB (FORM_DATA) STORE AS SECUREFILE (
  TABLESPACE  HISTORY
  ENABLE      STORAGE IN ROW
  CHUNK       8192
  RETENTION
  NOCACHE
  LOGGING
  STORAGE    (
              INITIAL          104K
              NEXT             1M
              MINEXTENTS       1
              MAXEXTENTS       UNLIMITED
              PCTINCREASE      0
              BUFFER_POOL      DEFAULT
             ))
LOB (FREE_TEXT_1) STORE AS SECUREFILE (
  TABLESPACE  HISTORY
  ENABLE      STORAGE IN ROW
  CHUNK       8192
  RETENTION
  NOCACHE
  LOGGING
  STORAGE    (
              INITIAL          104K
              NEXT             1M
              MINEXTENTS       1
              MAXEXTENTS       UNLIMITED
              PCTINCREASE      0
              BUFFER_POOL      DEFAULT
             ))
LOB (OLD_FORM_DATA) STORE AS SECUREFILE (
  TABLESPACE  HISTORY
  ENABLE      STORAGE IN ROW
  CHUNK       8192
  RETENTION
  NOCACHE
  LOGGING
  STORAGE    (
              INITIAL          104K
              NEXT             1M
              MINEXTENTS       1
              MAXEXTENTS       UNLIMITED
              PCTINCREASE      0
              BUFFER_POOL      DEFAULT
             ))
LOB (SIGNATURE) STORE AS SECUREFILE (
  TABLESPACE  HISTORY
  ENABLE      STORAGE IN ROW
  CHUNK       8192
  RETENTION
  NOCACHE
  LOGGING
  STORAGE    (
              INITIAL          104K
              NEXT             1M
              MINEXTENTS       1
              MAXEXTENTS       UNLIMITED
              PCTINCREASE      0
              BUFFER_POOL      DEFAULT
             ))
LOB (SIGNATURE_CONTENT) STORE AS SECUREFILE (
  TABLESPACE  HISTORY
  ENABLE      STORAGE IN ROW
  CHUNK       8192
  RETENTION
  NOCACHE
  LOGGING
  STORAGE    (
              INITIAL          104K
              NEXT             1M
              MINEXTENTS       1
              MAXEXTENTS       UNLIMITED
              PCTINCREASE      0
              BUFFER_POOL      DEFAULT
             ))
LOB (TIME_STAMP_RESPONSE) STORE AS SECUREFILE (
  TABLESPACE  HISTORY
  ENABLE      STORAGE IN ROW
  CHUNK       8192
  RETENTION
  NOCACHE
  LOGGING
  STORAGE    (
              INITIAL          104K
              NEXT             1M
              MINEXTENTS       1
              MAXEXTENTS       UNLIMITED
              PCTINCREASE      0
              BUFFER_POOL      DEFAULT
             ))
TABLESPACE HISTORY
PCTFREE    10
INITRANS   100
MAXTRANS   255
STORAGE    (
            INITIAL          10M
            NEXT             10M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE;


CREATE UNIQUE INDEX ECECUSER.IDX_ADTT02 ON ECECUSER.AUDIT_TABLE
(LOG_SRL_NUM, BANK_ID)
LOGGING
TABLESPACE IDX_HISTORY
PCTFREE    10
INITRANS   100
MAXTRANS   255
STORAGE    (
            INITIAL          10M
            NEXT             10M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           );

ALTER TABLE ECECUSER.AUDIT_TABLE ADD (
  CONSTRAINT ADTTACCESS_CHANNEL02
  CHECK (REGEXP_count(ACCESS_CHANNEL,'[AMGSIWTHU]')=1)
  DISABLE NOVALIDATE
,  CONSTRAINT ADTTEVENT_SEQNO02
  CHECK (EVENT_SEQNO BETWEEN 1 and 9999999999 or EVENT_SEQNO = 0 )
  DISABLE NOVALIDATE
,  CONSTRAINT ADTTIF_SIGNED02
  CHECK (REGEXP_count(IF_SIGNED,'[YN]')=1)
  DISABLE NOVALIDATE
,  CONSTRAINT ADTTLOG_SRL_NUM02
  CHECK (LOG_SRL_NUM BETWEEN 1 and 99999999999999 or LOG_SRL_NUM = 0 )
  DISABLE NOVALIDATE
,  CONSTRAINT ADTTSIGNATURE_VALIDITY02
  CHECK (REGEXP_count(SIGNATURE_VALIDITY,'[YN]')=1)
  DISABLE NOVALIDATE);

CREATE INDEX ECECUSER.IDX_EVNT_INQRY02 ON ECECUSER.AUDIT_TABLE
(R_CRE_TIME, USER_TYPE, EVENT_ID)
LOGGING
TABLESPACE IDX_HISTORY
PCTFREE    10
INITRANS   100
MAXTRANS   255
STORAGE    (
            INITIAL          10M
            NEXT             10M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           );

CREATE INDEX ECECUSER.IDX_USRTYP_INQRY02 ON ECECUSER.AUDIT_TABLE
(R_CRE_TIME, USER_TYPE, USER_ID)
LOGGING
TABLESPACE IDX_HISTORY
PCTFREE    10
INITRANS   100
MAXTRANS   255
STORAGE    (
            INITIAL          10M
            NEXT             10M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           );

CREATE INDEX ECECUSER.IDX_USR_INQRY02 ON ECECUSER.AUDIT_TABLE
(R_CRE_TIME, CORP_ID, USER_ID)
LOGGING
TABLESPACE IDX_HISTORY
PCTFREE    10
INITRANS   100
MAXTRANS   255
STORAGE    (
            INITIAL          10M
            NEXT             10M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           );

CREATE OR REPLACE SYNONYM ECECUSER.ADTT FOR ECECUSER.AUDIT_TABLE;



--=========================================================================================
-------------------------------------------PNGRDBOX----------------------------------------
--==========================================================================================
OWNER	TABL_NAME					TYPE			TABLESPACE_NAME			SIZE_GB    STATUS
REDBOX	RBX_P_REQ_MGR_D_LOG			TABLE PARTITION	MORE THAN 1 TABLESPACE	2,550     Done already.Just to drop archive after bkp
REDBOX	RBX_P_CHN_ACTIVITY_LOG		TABLE			REDBOXTBS_DATA_FLSH		1,093
REDBOX	RBX_P_NIPOUT_LOG			TABLE			REDBOXTBS_DATA			688
REDBOX	RBX_P_FIN_BETA_LOG			TABLE			REDBOXTBS_DATA			289
REDBOX	RBX_P_GENERIC_TRANSFER_LOG	TABLE			REDBOXTBS_DATA			126
REDBOX	RBX_P_NIPIN_NAMEENQ_LOG		TABLE			REDBOXTBS_DATA			125


--=============================================
--TABLE 1 REDBOX.RBX_P_CHN_ACTIVITY_LOG
--=============================================
ALTER TABLE REDBOX.RBX_P_CHN_ACTIVITY_LOG RENAME TO RBX_P_CHN_ACTIVITY_LOG_05JUL23BKP;

CREATE TABLE REDBOX.RBX_P_CHN_ACTIVITY_LOG
(
  ID                     NUMBER(19)             NOT NULL,
  CREATE_DATE            DATE                   DEFAULT SYSDATE,
  CREATE_TIME            TIMESTAMP(6)           DEFAULT SYSTIMESTAMP,
  REQ_PAYLOAD            CLOB,
  RESP_PAYLOAD           CLOB,
  PRODUCER_REQ_PAYLOAD   CLOB,
  PRODUCER_RESP_PAYLOAD  CLOB
)
LOB (PRODUCER_REQ_PAYLOAD) STORE AS SECUREFILE (
  TABLESPACE  REDBOXTBS_DATA_FLSH
  ENABLE      STORAGE IN ROW
  CHUNK       8192
  RETENTION
  NOCACHE
  LOGGING
  STORAGE    (
              INITIAL          104K
              NEXT             1M
              MINEXTENTS       1
              MAXEXTENTS       UNLIMITED
              PCTINCREASE      0
              BUFFER_POOL      DEFAULT
             ))
LOB (PRODUCER_RESP_PAYLOAD) STORE AS SECUREFILE (
  TABLESPACE  REDBOXTBS_DATA_FLSH
  ENABLE      STORAGE IN ROW
  CHUNK       8192
  RETENTION
  NOCACHE
  LOGGING
  STORAGE    (
              INITIAL          104K
              NEXT             1M
              MINEXTENTS       1
              MAXEXTENTS       UNLIMITED
              PCTINCREASE      0
              BUFFER_POOL      DEFAULT
             ))
LOB (REQ_PAYLOAD) STORE AS SECUREFILE (
  TABLESPACE  REDBOXTBS_DATA_FLSH
  ENABLE      STORAGE IN ROW
  CHUNK       8192
  RETENTION
  NOCACHE
  LOGGING
  STORAGE    (
              INITIAL          104K
              NEXT             1M
              MINEXTENTS       1
              MAXEXTENTS       UNLIMITED
              PCTINCREASE      0
              BUFFER_POOL      DEFAULT
             ))
LOB (RESP_PAYLOAD) STORE AS SECUREFILE (
  TABLESPACE  REDBOXTBS_DATA_FLSH
  ENABLE      STORAGE IN ROW
  CHUNK       8192
  RETENTION
  NOCACHE
  LOGGING
  STORAGE    (
              INITIAL          104K
              NEXT             1M
              MINEXTENTS       1
              MAXEXTENTS       UNLIMITED
              PCTINCREASE      0
              BUFFER_POOL      DEFAULT
             ))
TABLESPACE REDBOXTBS_DATA_FLSH
PCTFREE    10
INITRANS   100
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            NEXT             8M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE;


ALTER TABLE REDBOX.RBX_P_CHN_ACTIVITY_LOG ADD (
  PRIMARY KEY
  (ID)
  USING INDEX
    TABLESPACE REDBOXTBS_INDX
    PCTFREE    10
    INITRANS   100
    MAXTRANS   255
    STORAGE    (
                INITIAL          64K
                NEXT             1M
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                BUFFER_POOL      DEFAULT
               )
  ENABLE VALIDATE);


--  There is no statement for index REDBOX.SYS_C0070865.
--  The object is created when the parent object is created.

GRANT SELECT ON REDBOX.RBX_P_CHN_ACTIVITY_LOG TO ITSM;



--=================================
--TABLE 2 REDBOX.RBX_P_NIPOUT_LOG
--=================================
ALTER TABLE REDBOX.RBX_P_NIPOUT_LOG RENAME TO RBX_P_NIPOUT_LOG_05JUL23BKP;
ALTER INDEX REDBOX.RBX_P_NIPOUT_LOG_INDX6 RENAME TO RBX_P_NIPOUT_LOG_INDX6_05JUL23BKP;

CREATE TABLE REDBOX.RBX_P_NIPOUT_LOG
(
  ID                            NUMBER(19)      NOT NULL,
  COMPONENT_OPERATION_NAME      VARCHAR2(255 CHAR),
  COMPONENT_REQ_IN_OBJECT       CLOB,
  COMPONENT_ENC_REQ_IN_OBJECT   CLOB,
  COMPONENT_REQ_IN_TIME         TIMESTAMP(6),
  COMPONENT_REQ_OUT_OBJECT      CLOB,
  COMPONENT_ENC_REQ_OUT_OBJECT  CLOB,
  COMPONENT_REQ_OUT_TIME        TIMESTAMP(6),
  COMPONENT_RESP_CODE           VARCHAR2(255 CHAR),
  COMPONENT_RESP_DESC           VARCHAR2(255 CHAR),
  COMPONENT_SERVER_IP           VARCHAR2(255 CHAR),
  LIFE_TIME_ID                  VARCHAR2(255 CHAR),
  SRC_MODULE_ID                 VARCHAR2(255 CHAR),
  TRAN_DATE                     DATE,
  TRAN_TIME                     TIMESTAMP(6)
)
LOB (COMPONENT_ENC_REQ_IN_OBJECT) STORE AS SECUREFILE (
  TABLESPACE  REDBOXTBS_DATA
  ENABLE      STORAGE IN ROW
  CHUNK       8192
  RETENTION
  NOCACHE
  LOGGING
  STORAGE    (
              INITIAL          104K
              NEXT             1M
              MINEXTENTS       1
              MAXEXTENTS       UNLIMITED
              PCTINCREASE      0
              BUFFER_POOL      DEFAULT
             ))
LOB (COMPONENT_ENC_REQ_OUT_OBJECT) STORE AS SECUREFILE (
  TABLESPACE  REDBOXTBS_DATA
  ENABLE      STORAGE IN ROW
  CHUNK       8192
  RETENTION
  NOCACHE
  LOGGING
  STORAGE    (
              INITIAL          104K
              NEXT             1M
              MINEXTENTS       1
              MAXEXTENTS       UNLIMITED
              PCTINCREASE      0
              BUFFER_POOL      DEFAULT
             ))
LOB (COMPONENT_REQ_IN_OBJECT) STORE AS SECUREFILE (
  TABLESPACE  REDBOXTBS_DATA
  ENABLE      STORAGE IN ROW
  CHUNK       8192
  RETENTION
  NOCACHE
  LOGGING
  STORAGE    (
              INITIAL          104K
              NEXT             1M
              MINEXTENTS       1
              MAXEXTENTS       UNLIMITED
              PCTINCREASE      0
              BUFFER_POOL      DEFAULT
             ))
LOB (COMPONENT_REQ_OUT_OBJECT) STORE AS SECUREFILE (
  TABLESPACE  REDBOXTBS_DATA
  ENABLE      STORAGE IN ROW
  CHUNK       8192
  RETENTION
  NOCACHE
  LOGGING
  STORAGE    (
              INITIAL          104K
              NEXT             1M
              MINEXTENTS       1
              MAXEXTENTS       UNLIMITED
              PCTINCREASE      0
              BUFFER_POOL      DEFAULT
             ))
TABLESPACE REDBOXTBS_DATA
PCTFREE    10
INITRANS   100
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE;


ALTER TABLE REDBOX.RBX_P_NIPOUT_LOG ADD (
  PRIMARY KEY
  (ID)
  USING INDEX
    TABLESPACE REDBOXTBS_INDX
    PCTFREE    10
    INITRANS   100
    MAXTRANS   255
    STORAGE    (
                INITIAL          64K
                NEXT             1M
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                BUFFER_POOL      DEFAULT
               )
  ENABLE VALIDATE);


CREATE INDEX REDBOX.RBX_P_NIPOUT_LOG_INDX6 ON REDBOX.RBX_P_NIPOUT_LOG
(TRAN_DATE, SRC_MODULE_ID, COMPONENT_SERVER_IP, LIFE_TIME_ID)
LOGGING
TABLESPACE REDBOXTBS_INDX
PCTFREE    10
INITRANS   100
MAXTRANS   255
STORAGE    (
            INITIAL          100M
            NEXT             100M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           );

--  There is no statement for index REDBOX.SYS_C0077796.
--  The object is created when the parent object is created.




--==============================
--TABLE 3 RBX_P_FIN_BETA_LOG
--==============================
ALTER TABLE REDBOX.RBX_P_FIN_BETA_LOG RENAME TO RBX_P_FIN_BETA_LOG_05JUL23BKP;
ALTER INDEX REDBOX.FIN_BETA_INDEX6 RENAME TO FIN_BETA_INDEX6_05JUL23BKP;

CREATE TABLE REDBOX.RBX_P_FIN_BETA_LOG
(
  ID                        NUMBER(19)          NOT NULL,
  COMPONENT_OPERATION_NAME  VARCHAR2(255 CHAR),
  COMPONENT_REQ_IN_OBJECT   CLOB,
  COMPONENT_REQ_IN_TIME     TIMESTAMP(6),
  COMPONENT_REQ_OUT_OBJECT  CLOB,
  COMPONENT_REQ_OUT_TIME    TIMESTAMP(6),
  COMPONENT_RESP_CODE       VARCHAR2(255 CHAR),
  COMPONENT_RESP_DESC       VARCHAR2(255 CHAR),
  COMPONENT_SERVER_IP       VARCHAR2(255 CHAR),
  LIFE_TIME_ID              VARCHAR2(255 CHAR),
  SRC_MODULE_ID             VARCHAR2(255 CHAR),
  TRAN_DATE                 DATE,
  TRAN_TIME                 TIMESTAMP(6),
  REQUEST_REFERENCE         VARCHAR2(255 BYTE)
)
LOB (COMPONENT_REQ_IN_OBJECT) STORE AS SECUREFILE (
  TABLESPACE  REDBOXTBS_DATA
  ENABLE      STORAGE IN ROW
  CHUNK       8192
  RETENTION
  NOCACHE
  LOGGING
  STORAGE    (
              INITIAL          104K
              NEXT             1M
              MINEXTENTS       1
              MAXEXTENTS       UNLIMITED
              PCTINCREASE      0
              BUFFER_POOL      DEFAULT
             ))
LOB (COMPONENT_REQ_OUT_OBJECT) STORE AS SECUREFILE (
  TABLESPACE  REDBOXTBS_DATA
  ENABLE      STORAGE IN ROW
  CHUNK       8192
  RETENTION
  NOCACHE
  LOGGING
  STORAGE    (
              INITIAL          104K
              NEXT             1M
              MINEXTENTS       1
              MAXEXTENTS       UNLIMITED
              PCTINCREASE      0
              BUFFER_POOL      DEFAULT
             ))
TABLESPACE REDBOXTBS_DATA
PCTFREE    10
INITRANS   100
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE;


ALTER TABLE REDBOX.RBX_P_FIN_BETA_LOG ADD (
  PRIMARY KEY
  (ID)
  USING INDEX
    TABLESPACE REDBOXTBS_INDX
    PCTFREE    10
    INITRANS   100
    MAXTRANS   255
    STORAGE    (
                INITIAL          64K
                NEXT             1M
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                BUFFER_POOL      DEFAULT
               )
  ENABLE VALIDATE);


CREATE INDEX REDBOX.FIN_BETA_INDEX6 ON REDBOX.RBX_P_FIN_BETA_LOG
(SRC_MODULE_ID, LIFE_TIME_ID, TRAN_DATE, REQUEST_REFERENCE)
LOGGING
TABLESPACE REDBOXTBS_INDX
PCTFREE    10
INITRANS   100
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           );

--  There is no statement for index REDBOX.SYS_C0077801.
--  The object is created when the parent object is created.




--============================================
--TABLE 4 REDBOX.RBX_P_GENERIC_TRANSFER_LOG
--============================================

ALTER TABLE REDBOX.RBX_P_GENERIC_TRANSFER_LOG RENAME TO RBX_P_GENERIC_TRANSFER_LOG_05JUL23BKP;
ALTER INDEX REDBOX.PROCESSING_NODE_IP21 RENAME TO PROCESSING_NODE_IP21_05JUL23BKP;
ALTER INDEX REDBOX.REQUEST_TRANID_INDEX3 RENAME TO REQUEST_TRANID_INDEX3_05JUL23BKP;
ALTER INDEX REDBOX.REQUEST_TYPE_INDEX3 RENAME TO REQUEST_TYPE_INDEX3_05JUL23BKP;


CREATE TABLE REDBOX.RBX_P_GENERIC_TRANSFER_LOG
(
  ID                           NUMBER(19)       NOT NULL,
  DATE_CREATED                 DATE,
  FEEDBACK_CODE                VARCHAR2(255 CHAR),
  FEEDBACK_STATUS              VARCHAR2(255 CHAR),
  LIFE_TIME_ID                 VARCHAR2(255 CHAR),
  MODULE_ID                    VARCHAR2(255 CHAR),
  PROCESSING_NODE_IP           VARCHAR2(255 CHAR),
  REQUEST_PAYLOAD              CLOB,
  REQUEST_ID                   VARCHAR2(255 CHAR),
  REQUEST_TYPE                 VARCHAR2(255 CHAR),
  RESPONSE_DESCRIPTION         VARCHAR2(255 CHAR),
  RESPONSE_PAYLOAD             CLOB,
  RESPONSE_TIME                TIMESTAMP(6),
  TIME_CREATED                 TIMESTAMP(6),
  ACTUAL_RESPONSE_DESCRIPTION  CLOB
)
LOB (ACTUAL_RESPONSE_DESCRIPTION) STORE AS SECUREFILE (
  TABLESPACE  REDBOXTBS_DATA
  ENABLE      STORAGE IN ROW
  CHUNK       8192
  RETENTION
  NOCACHE
  LOGGING
  STORAGE    (
              INITIAL          104K
              NEXT             1M
              MINEXTENTS       1
              MAXEXTENTS       UNLIMITED
              PCTINCREASE      0
              BUFFER_POOL      DEFAULT
             ))
LOB (REQUEST_PAYLOAD) STORE AS SECUREFILE (
  TABLESPACE  REDBOXTBS_DATA
  ENABLE      STORAGE IN ROW
  CHUNK       8192
  RETENTION
  NOCACHE
  LOGGING
  STORAGE    (
              INITIAL          104K
              NEXT             1M
              MINEXTENTS       1
              MAXEXTENTS       UNLIMITED
              PCTINCREASE      0
              BUFFER_POOL      DEFAULT
             ))
LOB (RESPONSE_PAYLOAD) STORE AS SECUREFILE (
  TABLESPACE  REDBOXTBS_DATA
  ENABLE      STORAGE IN ROW
  CHUNK       8192
  RETENTION
  NOCACHE
  LOGGING
  STORAGE    (
              INITIAL          104K
              NEXT             1M
              MINEXTENTS       1
              MAXEXTENTS       UNLIMITED
              PCTINCREASE      0
              BUFFER_POOL      DEFAULT
             ))
TABLESPACE REDBOXTBS_DATA
PCTFREE    10
INITRANS   100
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE;


ALTER TABLE REDBOX.RBX_P_GENERIC_TRANSFER_LOG ADD (
  PRIMARY KEY
  (ID)
  USING INDEX
    TABLESPACE REDBOXTBS_INDX
    PCTFREE    10
    INITRANS   100
    MAXTRANS   255
    STORAGE    (
                INITIAL          64K
                NEXT             1M
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                BUFFER_POOL      DEFAULT
               )
  ENABLE VALIDATE);


CREATE INDEX REDBOX.PROCESSING_NODE_IP21 ON REDBOX.RBX_P_GENERIC_TRANSFER_LOG
(PROCESSING_NODE_IP)
LOGGING
TABLESPACE REDBOXTBS_INDX
PCTFREE    10
INITRANS   100
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           );

CREATE INDEX REDBOX.REQUEST_TRANID_INDEX3 ON REDBOX.RBX_P_GENERIC_TRANSFER_LOG
(REQUEST_ID)
LOGGING
TABLESPACE REDBOXTBS_INDX
PCTFREE    10
INITRANS   100
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           );

CREATE INDEX REDBOX.REQUEST_TYPE_INDEX3 ON REDBOX.RBX_P_GENERIC_TRANSFER_LOG
(REQUEST_TYPE)
LOGGING
TABLESPACE REDBOXTBS_INDX
PCTFREE    10
INITRANS   100
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           );

--  There is no statement for index REDBOX.SYS_C0070863.
--  The object is created when the parent object is created.




--==========================================
--TABLE 5 REDBOX.RBX_P_NIPIN_NAMEENQ_LOG
--==========================================
ALTER TABLE REDBOX.RBX_P_NIPIN_NAMEENQ_LOG RENAME TO RBX_P_NIPIN_NAMEENQ_LOG_05JUL23BKP;


CREATE TABLE REDBOX.RBX_P_NIPIN_NAMEENQ_LOG
(
  ID                     NUMBER(19)             NOT NULL,
  CREATE_DATE            DATE                   DEFAULT trunc(SYSDATE),
  CREATE_TIME            TIMESTAMP(6)           DEFAULT SYSTIMESTAMP,
  CONSUMER_REQ_PAYLOAD   CLOB,
  CONSUMER_RESP_PAYLOAD  CLOB,
  FIN_REQ_PAYLOAD        CLOB,
  FIN_RESP_PAYLOAD       CLOB
)
LOB (CONSUMER_REQ_PAYLOAD) STORE AS SECUREFILE (
  TABLESPACE  REDBOXTBS_DATA
  ENABLE      STORAGE IN ROW
  CHUNK       8192
  RETENTION
  NOCACHE
  LOGGING
  STORAGE    (
              INITIAL          104K
              NEXT             1M
              MINEXTENTS       1
              MAXEXTENTS       UNLIMITED
              PCTINCREASE      0
              BUFFER_POOL      DEFAULT
             ))
LOB (CONSUMER_RESP_PAYLOAD) STORE AS SECUREFILE (
  TABLESPACE  REDBOXTBS_DATA
  ENABLE      STORAGE IN ROW
  CHUNK       8192
  RETENTION
  NOCACHE
  LOGGING
  STORAGE    (
              INITIAL          104K
              NEXT             1M
              MINEXTENTS       1
              MAXEXTENTS       UNLIMITED
              PCTINCREASE      0
              BUFFER_POOL      DEFAULT
             ))
LOB (FIN_REQ_PAYLOAD) STORE AS SECUREFILE (
  TABLESPACE  REDBOXTBS_DATA
  ENABLE      STORAGE IN ROW
  CHUNK       8192
  RETENTION
  NOCACHE
  LOGGING
  STORAGE    (
              INITIAL          104K
              NEXT             1M
              MINEXTENTS       1
              MAXEXTENTS       UNLIMITED
              PCTINCREASE      0
              BUFFER_POOL      DEFAULT
             ))
LOB (FIN_RESP_PAYLOAD) STORE AS SECUREFILE (
  TABLESPACE  REDBOXTBS_DATA
  ENABLE      STORAGE IN ROW
  CHUNK       8192
  RETENTION
  NOCACHE
  LOGGING
  STORAGE    (
              INITIAL          104K
              NEXT             1M
              MINEXTENTS       1
              MAXEXTENTS       UNLIMITED
              PCTINCREASE      0
              BUFFER_POOL      DEFAULT
             ))
TABLESPACE REDBOXTBS_DATA
PCTFREE    10
INITRANS   100
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE;


ALTER TABLE REDBOX.RBX_P_NIPIN_NAMEENQ_LOG ADD (
  PRIMARY KEY
  (ID)
  USING INDEX
    TABLESPACE REDBOXTBS_INDX
    PCTFREE    10
    INITRANS   100
    MAXTRANS   255
    STORAGE    (
                INITIAL          64K
                NEXT             1M
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                BUFFER_POOL      DEFAULT
               )
  ENABLE VALIDATE);


--  There is no statement for index REDBOX.SYS_C0077798.
--  The object is created when the parent object is created.

ALTER TABLE REDBOX.RBX_P_NIPIN_NAMEENQ_LOG ADD (
  CONSTRAINT FK_AB71HXGW6IIXG6TP0GMRWM676 
  FOREIGN KEY (ID) 
  REFERENCES REDBOX.RBX_T_NIPIN_NAMEENQ_LOG (ID)
  ENABLE VALIDATE);





--==========================================
--TABLE 6 REDBOX.RBX_P_NIBBS_BVN_VALIDATION
--==========================================
ALTER TABLE REDBOX.RBX_P_NIBBS_BVN_VALIDATION RENAME TO RBX_P_NIBBS_BVN_VALIDATION_04JUL23BKP;

CREATE TABLE REDBOX.RBX_P_NIBBS_BVN_VALIDATION
(
  ID                NUMBER(19)                  NOT NULL,
  BVN_ID            VARCHAR2(255 CHAR),
  MODULE_ID         VARCHAR2(255 CHAR),
  REQUEST           CLOB,
  REQUEST_ID        VARCHAR2(255 CHAR),
  RESPONSE          CLOB,
  RESPONSE_CODE     VARCHAR2(255 CHAR),
  RESPONSE_MESSAGE  VARCHAR2(255 CHAR),
  TXN_DATE          DATE,
  TXN_TIME          TIMESTAMP(6)
)
LOB (REQUEST) STORE AS SECUREFILE (
  TABLESPACE  REDBOXTBS_DATA
  ENABLE      STORAGE IN ROW
  CHUNK       8192
  RETENTION
  NOCACHE
  LOGGING
  STORAGE    (
              INITIAL          104K
              NEXT             1M
              MINEXTENTS       1
              MAXEXTENTS       UNLIMITED
              PCTINCREASE      0
              BUFFER_POOL      DEFAULT
             ))
LOB (RESPONSE) STORE AS SECUREFILE (
  TABLESPACE  REDBOXTBS_DATA
  ENABLE      STORAGE IN ROW
  CHUNK       8192
  RETENTION
  NOCACHE
  LOGGING
  STORAGE    (
              INITIAL          104K
              NEXT             1M
              MINEXTENTS       1
              MAXEXTENTS       UNLIMITED
              PCTINCREASE      0
              BUFFER_POOL      DEFAULT
             ))
TABLESPACE REDBOXTBS_DATA
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE;


ALTER TABLE REDBOX.RBX_P_NIBBS_BVN_VALIDATION ADD (
  PRIMARY KEY
  (ID)
  USING INDEX
    TABLESPACE REDBOXTBS_DATA
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          64K
                NEXT             1M
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                BUFFER_POOL      DEFAULT
               )
  ENABLE VALIDATE);


--  There is no statement for index REDBOX.SYS_C0031823.
--  The object is created when the parent object is created.
