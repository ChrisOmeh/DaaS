step 1 - Confirm the CHARACTERSET
select value from v$nls_parameters where upper(parameter) = 'NLS_NCHAR_CHARACTERSET';


Step 2 - Take the Table data backup of listed.
select distinct c.owner, c.table_name from dba_tab_cols c, dba_objects o
where c.data_type in ('NCHAR','NVARCHAR2', 'NCLOB')
and c.owner=o.owner
and c.table_name = o.object_name
and o.object_type = 'TABLE'
order by c.owner, c.table_name

Step 3 - Truncate Tables. e.g truncate table SYS.RADM_FPTM$; truncate table SYS.RADM_FPTM_LOB$;

Step 4 - $sqlplus / as sysdba
SQL> SHUTDOWN IMMEDIATE
SQL> STARTUP MOUNT
SQL> ALTER SYSTEM ENABLE RESTRICTED SESSION;
SQL> ALTER SYSTEM SET JOB_QUEUE_PROCESSES=0 SCOPE = MEMORY;
SQL> ALTER SYSTEM SET AQ_TM_PROCESSES=0 SCOPE = MEMORY;
SQL> ALTER DATABASE OPEN;
SQL> ALTER DATABASE NATIONAL CHARACTER SET UTF8;
SQL> SHUTDOWN IMMEDIATE
SQL> STARTUP

Step 5 - Restore the Table data backup.


===================================ERROR EXPIRENCED===================

ERROR at line 1:
ORA-12717: Cannot issue ALTER DATABASE NATIONAL CHARACTER SET when NCLOB, NCHAR
or NVARCHAR2 data exists



alert_log entry---------
replication_dependency_tracking turned off (no async multimaster replication found)
AQ Processes can not start in restrict mode
Starting background process CJQ0
2023-06-13T09:26:53.768173+01:00
CJQ0 started with pid=54, OS id=518402
Completed: ALTER DATABASE OPEN
2023-06-13T09:27:07.388229+01:00
ALTER DATABASE NATIONAL CHARACTER SET UTF8
2023-06-13T09:27:07.520153+01:00
 SYS.RADM_FPTM$ (NVARCHARCOL) - NVARCHAR2 populated
ORA-12717 signalled during: ALTER DATABASE NATIONAL CHARACTER SET UTF8...


SYS@DNGTFIN >shutdown immediate;
Database closed.
Database dismounted.
ORACLE instance shut down.
SYS@DNGTFIN >startup
ORACLE instance started.

Total System Global Area 3.2481E+11 bytes
Fixed Size                 37261768 bytes
Variable Size            3.7581E+10 bytes
Database Buffers         2.8669E+11 bytes
Redo Buffers              499605504 bytes
Database mounted.
Database opened.
SYS@DNGTFIN >truncate table SYS.RADM_FPTM$;

Table truncated.

SYS@DNGTFIN >truncate table SYS.RADM_FPTM_LOB$;

Table truncated.

SYS@DNGTFIN >SHUTDOWN IMMEDIATE
Database closed.
Database dismounted.
ORACLE instance shut down.
SYS@DNGTFIN >STARTUP MOUNT
ORACLE instance started.

Total System Global Area 3.2481E+11 bytes
Fixed Size                 37261768 bytes
Variable Size            3.7581E+10 bytes
Database Buffers         2.8669E+11 bytes
Redo Buffers              499605504 bytes
Database mounted.
SYS@DNGTFIN >ALTER SYSTEM ENABLE RESTRICTED SESSION;

System altered.

SYS@DNGTFIN >ALTER SYSTEM SET JOB_QUEUE_PROCESSES=0 SCOPE = MEMORY;

System altered.

SYS@DNGTFIN >ALTER SYSTEM SET AQ_TM_PROCESSES=0 SCOPE = MEMORY;

System altered.

SYS@DNGTFIN >ALTER DATABASE OPEN;

Database altered.

SYS@DNGTFIN >ALTER DATABASE NATIONAL CHARACTER SET UTF8;

Database altered.

SYS@DNGTFIN >SHUTDOWN IMMEDIATE
Database closed.
Database dismounted.
ORACLE instance shut down.
SYS@DNGTFIN >STARTUP
ORACLE instance started.

Total System Global Area 3.2481E+11 bytes
Fixed Size                 37261768 bytes
Variable Size            3.7581E+10 bytes
Database Buffers         2.8669E+11 bytes
Redo Buffers              499605504 bytes
Database mounted.
Database opened.
SYS@DNGTFIN >select value from v$nls_parameters where upper(parameter) = 'NLS_NCHAR_CHARACTERSET';

VALUE
----------------------------------------------------------------
UTF8

SYS@DNGTFIN >SET DEFINE OFF;
Insert into SYS.RADM_FPTM_LOB$
   (CLOBCOL, NCLOBCOL, FPVER)
 Values
   ('[redacted]', '[redacted]', 1);
COMMIT;
SYS@DNGTFIN >  2    3    4
1 row created.

SYS@DNGTFIN >
Commit complete.

SYS@DNGTFIN >SET DEFINE OFF;
Insert into SYS.RADM_FPTM$
   (NUMBERCOL, BINFLOATCOL, BINDOUBLECOL, CHARCOL, VARCHARCOL,
    NCHARCOL, NVARCHARCOL, DATECOL, TS_COL, TSWTZ_COL,
    FPVER)
SYS@DNGTFIN >  2    3   Values
  4    5    6     (0, 0, 0, ' ', ' ',
  7      ' ', ' ', TO_DATE('1/1/2001', 'MM/DD/YYYY'), TO_TIMESTAMP('1/1/2001 1:00:00.000000 AM','fmMMfm/fmDDfm/YYYY fmHH12fm:MI:SS.FF AM'), TO_TIMESTAMP_TZ('1/1/2001 1:00:00.000000 AM +00:00','fmMMfm/fmDDfm/YYYY fmHH12fm:MI:SS.FF AM TZH:TZM'),
  8      1);
COMMIT;
1 row created.