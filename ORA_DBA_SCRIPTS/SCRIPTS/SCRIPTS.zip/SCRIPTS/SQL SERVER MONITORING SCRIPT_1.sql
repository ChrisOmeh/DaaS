--================================== ALL SQL DB OBJECTS
SELECT * FROM sys.all_objects;

--===============================
SELECT * FROM sys.dm_exec_query_memory_grants;

--==========================================
SELECT * FROM sys.database_files;

--=================================
select CAST(create_date as date) as created_date,
database_id,
UPPER(name) as database_name,
compatibility_level,
user_access_desc,
state_desc,
recovery_model_desc,
log_reuse_wait_desc
from sys.databases;

select * from sys.databases;

select * from sys.master_files;

select @@VERSION
--Microsoft SQL Server 2016 (SP1) (KB3182545) - 13.0.4001.0 (X64)   Oct 28 2016 18:17:30   Copyright (c) Microsoft Corporation  
--Enterprise Edition: Core-based Licensing (64-bit) on Windows Server 2012 R2 Standard 6.3 <X64> (Build 9600: ) 

SELECT compatibility_level FROM sys.databases
where compatibility_level >=100;


--========================
select * from sys.sysusers;
select * from sys.sql_logins;
select * from sys.database_principals;
select * from sys.syslogins;
select * from sys.server_principals;
select db_name(database_id) from sys.database_recovery_status;

select * from sys.all_objects 
where name like '%recovery%';
--==============================

SELECT name AS Login_Name, type_desc AS Account_Type
FROM sys.server_principals 
WHERE TYPE IN ('U', 'S', 'G')
and name not like '%##%'
ORDER BY name, type_desc

--===============================
SELECT loginname as LOGIN_NAME,
CAST(createdate as date) as CREATED_DATE
from sys.syslogins;

select * from sys.syslogins;
select * FROM sys.server_principals;

--===================================
SELECT loginname as LOGIN_NAME,
type_desc as LOGIN_TYPE,
CAST(create_date as date) as CREATED_DATE,
case when is_disabled =1
then 'DISABLED'
else
'ENABLED'
END as ACCOUNT_STATUS
FROM sys.server_principals,sys.syslogins
ORDER BY LOGIN_NAME, ACCOUNT_STATUS;

--==============================================
--SQL CONDITIONAL  STATEMENT
DECLARE @MATH INT, @ENG INT, @CHEM INT, @PHY INT
SET @MATH = 80;
SET @ENG = 70;
SET @CHEM = 75;
SET @PHY = 85;

IF @MATH >70
BEGIN
PRINT 'CONGRATULATIONS YOU PASSED MATH'
END
ELSE
BEGIN
PRINT'YOU FAILED MATH'
END

IF @ENG >70
BEGIN
PRINT 'CONGRATULATIONS YOU PASSED MATH'
END
ELSE
BEGIN
PRINT'YOU FAILED MATH'
END

IF @CHEM >70
BEGIN
PRINT 'CONGRATULATIONS YOU PASSED MATH'
END
ELSE
BEGIN
PRINT'YOU FAILED MATH'
END

IF @PHY >70
BEGIN
PRINT 'CONGRATULATIONS YOU PASSED MATH'
END
ELSE
BEGIN
PRINT'YOU FAILED MATH'
END

--=============================================================
DECLARE @MATHS INT, @ENGG INT, @CHEMM INT, @PHYY INT
SET @MATHS = 80;
SET @ENGG = 70;
SET @CHEMM = 75;
SET @PHYY = 85;
IF (@MATHS >=50 AND @ENGG >= 50 AND @CHEMM >=50 AND @PHYY >=50)
BEGIN
	DECLARE @PERCENTAGE FLOAT
	SET @PERCENTAGE = ((@MATHS+@ENGG+@CHEMM+@PHYY)*100) / 300
	PRINT CONCAT('YOUR PERCENTAGE SCORE IS:', @PERCENTAGE)
END
ELSE
BEGIN
	PRINT "YOU DON'T HAVE A PERCENTAGE SCORE"
END


--=============================================
--DISK VOLUME 
SELECT db_name(f.database_id) AS DATABASE NAME], 
f.database_id AS DATABASES ID], 
f.file_id AS FILE ID], 
volume_mount_pointDisk], 
CONVERT(DECIMAL(18,2),total_bytes/1073741824.0) AS TOTAL SPACE SIZE(GB)], 
CONVERT(DECIMAL(18,2),available_bytes/1073741824.0) AS AVAILABLE SPACE SIZE(GB)],
CAST(CAST(available_bytes AS FLOAT)/CAST(total_bytes AS FLOAT) AS DECIMAL(18,2)) *100 AS PCT FREE SPACE(%)]
FROM sys.master_files AS f  
CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.file_id)
ORDER BY PCT FREE SPACE(%)] DESC;


SELECT DISTINCT 
    CONVERT(CHAR(100), SERVERPROPERTY('Servername')) AS Server,
    volume_mount_point [Disk], 
    file_system_type [File System], 
    logical_volume_name as [Logical Drive Name], 
    CONVERT(DECIMAL(18,2),total_bytes/1073741824.0) AS [Total Size in GB], ---1GB = 1073741824 bytes
    CONVERT(DECIMAL(18,2),available_bytes/1073741824.0) AS [Available Size in GB],  
    CAST(CAST(available_bytes AS FLOAT)/ CAST(total_bytes AS FLOAT) AS DECIMAL(18,2)) * 100 AS [Space Free %]
FROM sys.master_files 
CROSS APPLY sys.dm_os_volume_stats(database_id, file_id)
ORDER BY [Space Free %] DESC;

/*To check Disk utilization*/
SELECT DISTINCT vs.volume_mount_point,
vs.file_system_type,
vs.logical_volume_name,
CONVERT(DECIMAL(18,2),vs.total_bytes/1073741824.0) AS Total Size (GB)],
CONVERT(DECIMAL(18,2),vs.available_bytes/1073741824.0) AS Available Size (GB)],
CAST(CAST(vs.available_bytes AS FLOAT)/ CAST(vs.total_bytes AS FLOAT)
AS DECIMAL(18,2)) * 100 AS Space Free %]
FROM sys.master_files AS f WITH (NOLOCK)
CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.[file_id]) AS vs OPTION (RECOMPILE);


--======================================================
--SOLVE REPLICATION ISSUES WHEN SHRINKING LOGS
--=================================================
SELECT * FROM sys.dm_os_sys_info;
select * from sys.dm_os_windows_info;
select * from sys.dm_server_services;


select * from sys.all_objects
where name like '%recovery%';

select * from sys.databases
where database_id not in (1,2,3,4) AND log_reuse_wait_desc = 'LOG_BACKUP'
order by name;


USE YOURDB

EXEC sp_removedbreplication 'YOURDB'

CHECKPOINT

USE MyDB  GO   EXEC sys.sp_cdc_disable_db  GO

--===========================================================
select * from sys.security_predicates;
select * from sys.dm_tran_global_recovery_transactions;

--======================================
SELECT *
FROM sys.inventory.Storage
ORDER BY percent_free_space;

--======================================
--Adventureworks database
USE AdventureWorksSales
select COUNT(*) from dbo].[Product];

declare @col varchar
set @col = 
(select TOP 1 Color
				from dbo].[Product
				where StandardCost = (select MAX([StandardCost]) from dbo].[Product]));
select Name
from dbo].[Product
where Color = @col;


select Name 
from dbo].[Product
where Color = (select TOP 1 Color
				from dbo].[Product
				where StandardCost = (select MAX([StandardCost]) from dbo].[Product]))



select TOP 5 * from dbo].[Product];
select TOP 5 * from dbo].[ProductCategory];

select distinct(year(cast([ModifiedDate as date))) from dbo].[SalesOrder];
select distinct(month(cast([ModifiedDate as date))) from dbo].[SalesOrder];
select distinct(day(cast([ModifiedDate as date))) from dbo].[SalesOrder];


select TOP 5 * FROM dbo].[SalesOrder];

SELECT * FROM sys.traces;


--=======================================================
--FIND DB USERS, LOGINS AND PRIVILEGES
--=======================================================

USE MASTER
(SELECT DISTINCT p.name AS loginname ,
p.type ,
p.type_desc ,
CONVERT(VARCHAR(10),p.create_date ,101) AS created],
CONVERT(VARCHAR(10),p.modify_date , 101) AS update],
case when p.is_disabled = 1 then 'Disabled'
            else 'Enabled' end as status,
case when s.sysadmin = 1 then 'Admin'
            else 'Not Admin' end as Administrative_privilege
FROM sys.server_principals p
JOIN sys.syslogins s ON p.sid = s.sid
JOIN sys.server_permissions sp ON p.principal_id = sp.grantee_principal_id
WHERE p.type_desc IN ('SQL_LOGIN', 'WINDOWS_LOGIN', 'WINDOWS_GROUP')
-- Logins that are not process logins
AND p.name NOT LIKE '##%'
AND p.name NOT LIKE 'NT SERVICE%'
-- Logins that are sysadmins or have GRANT CONTROL SERVER
AND (s.sysadmin = 1)
)
UNION ALL
(SELECT DISTINCT p.name AS loginname ,
p.type ,
p.type_desc ,
CONVERT(VARCHAR(10),p.create_date ,101) AS created],
CONVERT(VARCHAR(10),p.modify_date , 101) AS update],
case when p.is_disabled = 1 then 'Disabled'
            else 'Enabled' end as status,
case when s.sysadmin = 1 then 'Admin'
            else 'Not Admin' end as Administrative_privilege
FROM sys.server_principals p
JOIN sys.syslogins s ON p.sid = s.sid
JOIN sys.server_permissions sp ON p.principal_id = sp.grantee_principal_id
RIGHT JOIN sys.database_principals dp ON p.name COLLATE DATABASE_DEFAULT = dp.name COLLATE DATABASE_DEFAULT
WHERE p.type_desc IN ('SQL_LOGIN', 'WINDOWS_LOGIN', 'WINDOWS_GROUP')
-- Logins that are not process logins
AND p.name NOT LIKE '##%'
-- Logins that are sysadmins or have GRANT CONTROL SERVER
--AND (s.sysadmin = 1 OR sp.permission_name = 'CONTROL SERVER')
)

--===================================
--MASTER COUNT DB OBJECTS
--===================================
SELECT COUNT(*) FROM SYS.all_columns;
SELECT COUNT(*) FROM SYS.all_objects;
SELECT COUNT(*) FROM SYS.all_parameters;
SELECT COUNT(*) FROM SYS.all_views;

--===================================
--ALL DB VIEWS
--==================================
SELECT * FROM SYS.all_views
WHERE name LIKE '%sp%';


--====SQL SERVER CDC=====
USE AdventureWorksSales
SELECT	name AS object_name   
		,SCHEMA_NAME(schema_id) AS schema_name  
		,type_desc  
		,is_ms_shipped  
FROM sys.objects 
WHERE is_ms_shipped= 1 AND SCHEMA_NAME(schema_id) = 'cdc';

select TOP 5 * FROM dbo].[Product];
select TOP 5 * FROM dbo].[ProductCategory];


--========================================
--VERIFYING VALID AND INVALID DB OBJECTS
--========================================

USE AdventureWorksSales
DECLARE @DB_ID INT;
DECLARE @OBJ_ID INT;
SET @DB_ID = DB_ID(N'[AdventureWorksSales]');
SET @OBJ_ID = OBJECT_ID(N'[AdventureWorksSales].[dbo].[Product]');
IF @DB_ID NULL
BEGIN
	PRINT N'INVALID DATABASE'
END;
ELSE IF @OBJ_ID NULL
BEGIN;
	PRINT 'N INVALID DATABASE OBJECT'
END;
ELSE
BEGIN;
	SELECT * FROM SYS.dm_db_index_operational_stats(@DB_ID, @OBJ_ID, NULL, NULL);
END;



 

 --=======================
 SELECT @@VERSION;

SELECT name, database_id, create_date FROM SYS.DATABASES
WHERE database_id NOT IN (1,2,3,4)
ORDER BY create_date DESC;

EXEC sp_who;
EXEC sp_who2;

SELECT spid, DB_NAME(dbid) as database_name, status,
hostname, program_name, hostprocess,
nt_domain, nt_username, loginame
FROM SYS.sysprocesses
where DB_NAME(dbid) not in ('master','msdb', 'tempdb','model');



USE DeviceFinanceWorkerLogs ---[StanbicIBTCChatBot

SELECT log_reuse_wait_desc FROM SYS.DATABASES
WHERE database_id = DB_ID();



--======CHECK DATABASE CONNECTIONS TO A PARTICULAR DB INSTANCE.=======
--Query one
SELECT loginame, DB_NAME(dbid) as DBName,
       COUNT(dbid) as NumberOfConnections      
FROM sys.sysprocesses
WHERE dbid > 0
GROUP BY dbid, loginame;


--Query 2:
select a.dbid,b.name, count(a.dbid) as TotalConnections
from sys.sysprocesses a
inner join sys.databases b on a.dbid = b.database_id
group by a.dbid, b.name

select name, log_reuse_wait_desc from sys.databases
where log_reuse_wait_desc = 'LOG_BACKUP';

--CHECK DATABASE SYS.DATABASES
select 
name, create_date, compatibility_level, user_access_desc,
state_desc,recovery_model_desc, log_reuse_wait_desc
from sys.databases
where database_id not in (1,2,3,4)
order by create_date desc;



--==============================
--BULK INSERT  
--==============================
BULK INSERT TABLE_NAME 
FROM 'FILE_PATH'
WITH (
FIELDTERMINATOR = ',',
ROWTERMINATOR = '\n',
FORMAT = 'csv'
)


--=============================================
--GRANT ACCESS TO USE TO SPECIFIC DDL, DML ETC
--=============================================
USE
RSVRRealtimeFinacleNG
GRANT SELECT ON "dbo"."HTD_JAN_2022" TO "NTNIGE\C854375";
GRANT SELECT ON "dbo"."HTD_JAN_2022" TO "NTNIGE\C854419";


--=======================================================
--SHRINK DATABASE LOG FILE
--=======================================================
SELECT name, database_id, log_reuse_wait, log_reuse_wait_desc FROM sys.databases;

USE UDM];

---- Truncate the log by changing the database recovery model to SIMPLE.
ALTER DATABASE UDM SET RECOVERY SIMPLE;
---- Shrink the truncated log file to 1 MB.
DBCC SHRINKFILE (UDM_log, 1);
ALTER DATABASE UDM SET RECOVERY FULL;




--==========================================
--CHECK SESSION STATUS AND WAIT TYPE IN SQL SERVER
--================================================
SELECT  wt.session_id, 
    ot.task_state, 
    wt.wait_type, 
    wt.wait_duration_ms, 
    wt.blocking_session_id, 
    wt.resource_description, 
    es.[host_name], 
    es.[program_name 
FROM  sys.dm_os_waiting_tasks  wt  
INNER  JOIN sys.dm_os_tasks ot ON ot.task_address = wt.waiting_task_address 
INNER JOIN sys.dm_exec_sessions es ON es.session_id = wt.session_id 
WHERE es.is_user_process =  1;


---===========================================================================
---======================ARCHIVING TABLE IN SQL SERVER========================
---===========================================================================
--====RPA_BOT DB=================
--•	CARD_GL - PSTD_DATE
--•	EFT_Exceptions - ReconDate
--•	FEPARCHIVE -  DATETIME_TRAN_LOCAL
--•	T464_Settlement - SettlementDate

--=====UIPATH DB=====
--•	Logs  - TimeStamp

--Archive should be from 01- January-2021 to 31-October-2022

--==================CARD_GL========================
--TEST SCRIPT
SELECT COUNT(*) FROM CARD_GL
WHERE CAST(PSTD_DATE as date) > '2022-10-31';---2297276

--CARD_GL_10FEB2023 TO BE CREATED
exec sp_rename 'CARD_GL', 'CARD_GL_temp'
exec sp_rename 'CARD_GL_10FEB2023', 'CARD_GL'
exec sp_rename 'CARD_GL_temp', 'CARD_GL_10FEB2023'

USE RPA_BotDB
INSERT INTO CARD_GL SELECT * FROM dbo].[CARD_GL_10FEB2023
WHERE CAST(PSTD_DATE as date) > '2022-10-31'
--==================CARD_GL  DONE========================


--==================EFT_Exceptions========================
SELECT COUNT(*) FROM dbo].[EFT_Exceptions
WHERE CAST(Recon_Date as date) > '2022-10-31';  ---9639426

--EFT_Exceptions_10FEB2023 TO BE CREATED
--exec sp_rename 'EFT_Exceptions', 'EFT_Exceptions_temp'
--exec sp_rename 'EFT_Exceptions_10FEB2023', 'EFT_Exceptions'
--exec sp_rename 'EFT_Exceptions_temp', 'EFT_Exceptions_10FEB2023'

USE RPA_BotDB

INSERT INTO EFT_Exceptions SELECT * FROM EFT_Exceptions_10FEB2023
WHERE CAST(Recon_Date as date) > '2022-10-31';

--==================EFT_Exceptions Done===========================


--==================[dbo].[FEPArchive]========================
SELECT COUNT(*) FROM dbo].[FEPArchive
WHERE CAST(DATETIME_TRAN_LOCAL as date) > '2022-10-31';

--FEPArchive_10FEB2023 TO BE CREATED
--exec sp_rename 'FEPArchive', 'FEPArchive_temp'
--exec sp_rename 'FEPArchive_10FEB2023', 'FEPArchive'
--exec sp_rename 'FEPArchive_temp', 'FEPArchive_10FEB2023'
USE RPA_BotDB

INSERT INTO FEPArchive SELECT * FROM FEPArchive_10FEB2023
WHERE CAST(DATETIME_TRAN_LOCAL as date) > '2022-10-31';

--==================FEPArchive Done===========================



--==================[dbo].[T464_Settlement]========================
SELECT COUNT(*) FROM dbo].[T464_Settlement
WHERE CAST(SettlementDate as date) > '2022-10-31';

--T464_Settlement_10FEB2023 TO BE CREATED
--exec sp_rename 'T464_Settlement', 'T464_Settlement_temp'
--exec sp_rename 'T464_Settlement_10FEB2023', 'T464_Settlement'
--exec sp_rename 'T464_Settlement_temp', 'T464_Settlement_10FEB2023'
USE RPA_BotDB

INSERT INTO T464_Settlement SELECT * FROM T464_Settlement_10FEB2023
WHERE CAST(SettlementDate as date) > '2022-10-31';

DELETE FROM T464_Settlement_10FEB2023
WHERE CAST(SettlementDate as date) > '2022-10-31';

--==================T464_Settlement Done===========================


--==============BATCH SCRIPT TO DO BATCH DELETE OPERATION=============
USE RPA_BotDB

SET NOCOUNT ON;
DECLARE @r INT;
SET @r = 1;
WHILE @r > 0
BEGIN
  BEGIN TRANSACTION;
 
  DELETE TOP(100000) FROM  RPA_BotDB].dbo.FEPArchive WHERE DATETIME_TRAN_LOCAL <= DATEADD(DD, -30, GETDATE());
 
  SET @r = @@ROWCOUNT;
 
  COMMIT TRANSACTION;

  ALTER DATABASE RPA_BotDB SET RECOVERY SIMPLE;
---- Shrink the truncated log file to prevent the growth of transaction log file.
  DBCC SHRINKFILE (N'RPA_BotDB_log' , 0, TRUNCATEONLY);
  ALTER DATABASE RPA_BotDB SET RECOVERY FULL;
  -- CHECKPOINT;    -- if simple
  -- BACKUP LOG ... -- if full

END


DECLARE @BatchSize INT = 50000
WHILE 1 = 1
BEGIN
DELETE TOP (@BatchSize)
FROM RPA_BotDB].dbo.FEPArchive 
WHERE DATETIME_TRAN_LOCAL <= DATEADD(DD, -30, GETDATE());
IF @@ROWCOUNT < @BatchSize BREAK
END


--=====================================
--FIND TABLE SIZES
--=====================================
SELECT 
    t.NAME AS TableName,
    s.Name AS SchemaName,
    p.rows,
    SUM(a.total_pages) * 8 AS TotalSpaceKB, 
    CAST(ROUND(((SUM(a.total_pages) * 8) / 1024.00), 2) AS NUMERIC(36, 2)) AS TotalSpaceMB,
    SUM(a.used_pages) * 8 AS UsedSpaceKB, 
    CAST(ROUND(((SUM(a.used_pages) * 8) / 1024.00), 2) AS NUMERIC(36, 2)) AS UsedSpaceMB, 
    (SUM(a.total_pages) - SUM(a.used_pages)) * 8 AS UnusedSpaceKB,
    CAST(ROUND(((SUM(a.total_pages) - SUM(a.used_pages)) * 8) / 1024.00, 2) AS NUMERIC(36, 2)) AS UnusedSpaceMB
FROM 
    sys.tables t
INNER JOIN      
    sys.indexes i ON t.OBJECT_ID = i.object_id
INNER JOIN 
    sys.partitions p ON i.object_id = p.OBJECT_ID AND i.index_id = p.index_id
INNER JOIN 
    sys.allocation_units a ON p.partition_id = a.container_id
LEFT OUTER JOIN 
    sys.schemas s ON t.schema_id = s.schema_id
WHERE 
    t.NAME NOT LIKE 'dt%' 
    AND t.is_ms_shipped = 0
    AND i.OBJECT_ID > 255 
GROUP BY 
    t.Name, s.Name, p.Rows
ORDER BY 
    TotalSpaceMB DESC, t.Name;
	
	
--================================
--SETUP JOB ON ALWAYSON HA
--================================
if (select
ars.role_desc
from sys.dm_hadr_availability_replica_states ars
inner join sys.availability_groups ag
on ars.group_id = ag.group_id
where ag.name = 'AGRPTDBS'
and ars.is_local = 1) = 'PRIMARY'
begin;
EXEC dbo].[sp_ArchiverUIPATHTables];
end;


--===========================================================
--CHECK VLF COUNT TO SEE IF A DB WILL 
--ENTER RECOVERY MODE IF THE SQL SERVER SERVICE IS RESTARTED
--IF VLF COUNT IS ABOVE 300, DON'T RESTART SQL SERVER SERVICE
--============================================================
SELECT name AS 'Database Name',
COUNT(l.database_id) AS 'VLF Count',
SUM(CAST(vlf_active AS INT)) AS 'Active VLF',
COUNT(l.database_id)-SUM(CAST(vlf_active AS INT)) AS 'Inactive VLF',
SUM(vlf_size_mb) AS 'VLF Size (MB)',
SUM(vlf_active*vlf_size_mb) AS 'Active VLF Size (MB)',
SUM(vlf_size_mb)-SUM(vlf_active*vlf_size_mb) AS 'Inactive VLF Size (MB)'
FROM sys.databases s
CROSS APPLY sys.dm_db_log_info(s.database_id) l
GROUP BY name
ORDER BY COUNT(l.database_id)

--========================================
--CHECK IF SQL SERVER INSTANCE IS Running
--===========================================
SELECT servicename], status_desc], startup_type],
case when s.status_desc = 'Running' then 1
	else 0 end as status_desc_int
FROM sys.dm_server_services s;

--==========================================================================
--#Extract information regarding the state of always on availability group
--==========================================================================
SELECT C.name, CS.replica_server_name, CS.join_state_desc, 
RS.role_desc, RS.operational_state_desc, RS.connected_state_desc, 
RS.synchronization_health_desc
FROM sys.availability_groups_cluster AS C
INNER JOIN sys.dm_hadr_availability_replica_cluster_states AS CS
ON CS.group_id = C.group_id
INNER JOIN sys.dm_hadr_availability_replica_states AS RS
ON RS.replica_id = CS.replica_id;


SELECT
    dc.database_name,
    d.synchronization_health_desc,
    d.synchronization_state_desc,
    d.database_state_desc
FROM
    sys.dm_hadr_database_replica_states d
    JOIN sys.availability_databases_cluster dc ON d.group_database_id = dc.group_database_id
    AND d.is_local = 1


o validate the automatic seeding process , you could use the sys.dm_hadr_automatic_seeding DMV.

SELECT start_time,
    ag.name,
    db.database_name,
    current_state,
    performed_seeding,
    failure_state,
    failure_state_desc
FROM sys.dm_hadr_automatic_seeding autos 
    JOIN sys.availability_databases_cluster db 
        ON autos.ag_db_id = db.group_database_id
    JOIN sys.availability_groups ag 
        ON autos.ag_id = ag.group_id;

--=================================================
--START MS CLUSTER OBJECT WHEN IN QUARANTINE STATE
--================================================

Start-ClusterNode -ClearQuarantine
Start-ClusterNode -FQ
Start-Cluster -Name AGAMLDBS

IF A NODE IN A CLUSTER HAD ISSUE AND REFUSED TO BE JOINED BACK TO THE 
CLUSTER, RUN

Clear-ClusterNode ---
Clear-ClusterNode -Name 

USING POWERSHELL ON PROBLEMATIC NODE.

--==================================
--DISABLE INACTIVE USERS
--==================================
Update Users  set isEnabled=0  where DATEDIFF(day, lastLoginDate, GetDate()) > 30

Update Users  set isEnabled=0  where DATEDIFF(day, dateCreated, GetDate()) > 30 and lastLoginDate is null


SELECT s.session_id, s.login_time, s.host_name, s.program_name,
s.login_name, s.nt_user_name, s.is_user_process,
s.database_id, DB_NAME(s.database_id) AS database], 
s.status,
s.reads, s.writes, s.logical_reads, s.row_count,
c.session_id, c.net_transport, c.protocol_type, 
c.client_net_address, c.client_tcp_port, 
c.num_writes AS DataPacketWrites 
FROM sys.dm_exec_sessions s
INNER JOIN sys.dm_exec_connections c
ON s.session_id = c.session_id 
INNER JOIN sys.dm_exec_requests r 
ON s.session_id = r.session_id;

update sys.server_principals set isEnabled=0  where DATEDIFF(day, lastLoginDate, GetDate()) > 30;



SELECT login_name, max(login_time) as last_logged_in
FROM sys.dm_exec_sessions GROUP BY login_name
sys.dm_exec_sessions;

==========================================
CHECK RUNNING QUERIES IN SQL SERVER
==========================================
SELECT top 5 deqs.last_execution_time AS Time], dest.TEXT AS Query
FROM sys.dm_exec_query_stats AS deqs
CROSS APPLY sys.dm_exec_sql_text(deqs.sql_handle) AS dest
Where dbid = (select database_id from sys.databases Where name = 'TWIGPOSTELLER')
ORDER BY deqs.last_execution_time DESC;

SELECT sqltext.TEXT,
req.session_id,
req.status,
req.command,
req.cpu_time,
req.total_elapsed_time
FROM sys.dm_exec_requests req
CROSS APPLY sys.dm_exec_sql_text(sql_handle) AS sqltext
--where req.command = 'INSERT';


=============================================
VIEW BLOCKING SESSIONS ON SQL SERVER DB
=============================================
SELECT  req.session_id
       ,blocking_session_id
       ,ses.host_name
       ,DB_NAME(req.database_id) AS DB_NAME
       ,ses.login_name
       ,req.status
       ,req.command
       ,req.start_time
       ,req.cpu_time
       ,req.total_elapsed_time / 1000.0 AS total_elapsed_time
       ,req.command
       ,req.wait_type
       ,sqltext.text
FROM    sys.dm_exec_requests req
CROSS APPLY sys.dm_exec_sql_text(sql_handle) AS sqltext
JOIN    sys.dm_exec_sessions ses
        ON ses.session_id = req.session_id
WHERE req.wait_type IS NOT NULL;
--WHERE req.wait_type = '?'


=============================================
CHECK TABLE FRAGMENTATION PERCENT
=============================================
SELECT S.name as 'Schema',
T.name as 'Table',
I.name as 'Index',
DDIPS.avg_fragmentation_in_percent,
DDIPS.page_count
FROM sys.dm_db_index_physical_stats (DB_ID(), NULL, NULL, NULL, NULL) AS DDIPS
INNER JOIN sys.tables T on T.object_id = DDIPS.object_id
INNER JOIN sys.schemas S on T.schema_id = S.schema_id
INNER JOIN sys.indexes I ON I.object_id = DDIPS.object_id
AND DDIPS.index_id = I.index_id
WHERE t.name = 'Table_name_here'
and I.name is not null
AND DDIPS.avg_fragmentation_in_percent > 0
ORDER BY DDIPS.avg_fragmentation_in_percent desc;



============================================
BLOCKING SESSIONS
============================================
SELECT db_name(er.database_id),

er.session_id,

es.original_login_name,

es.client_interface_name,

er.start_time,

er.status,

er.wait_type,

er.wait_resource,

SUBSTRING(st.text, (er.statement_start_offset/2)+1,

((CASE er.statement_end_offset

WHEN -1 THEN DATALENGTH(st.text)

ELSE er.statement_end_offset

END - er.statement_start_offset)/2) + 1) AS statement_text,

er.*

FROM SYS.dm_exec_requests er

join sys.dm_exec_sessions es on (er.session_id = es.session_id)

CROSS APPLY sys.dm_exec_sql_text(er.sql_handle) AS st

where er.session_id in

(SELECT distinct(blocking_session_id) FROM SYS.dm_exec_requests WHERE blocking_session_id > 0)

and blocking_session_id = 0

====================================
MAXIMUM WORKER THREAD
====================================
DECLARE @max INT;
SELECT @max = max_workers_count
FROM sys.dm_os_sys_info;
SELECT GETDATE() AS 'CurrentDate', 
       @max AS 'TotalThreads', 
       SUM(active_Workers_count) AS 'CurrentThreads', 
       @max - SUM(active_Workers_count) AS 'AvailableThreads', 
       SUM(runnable_tasks_count) AS 'WorkersWaitingForCpu', 
       SUM(work_queue_count) AS 'RequestWaitingForThreads', 
       SUM(current_workers_count) AS 'AssociatedWorkers'
FROM sys.dm_os_Schedulers
WHERE STATUS = 'VISIBLE ONLINE';


--===========================================
--CHECK PCT OF RESTORE OR BACKUP JOB
--===========================================
SELECT
session_id as SPID,
command,
a.text AS Query,
start_time,
percent_complete,
CAST(((DATEDIFF(s,start_time,GETDATE()))/3600) AS VARCHAR) + ' hour(s), '
+ CAST((DATEDIFF(s,start_time,GETDATE())%3600)/60 AS VARCHAR) + 'min, '
+ CAST((DATEDIFF(s,start_time,GETDATE())%60) AS VARCHAR) + ' sec' AS running_time,
CAST((estimated_completion_time/3600000) AS VARCHAR) + ' hour(s), '
+ CAST((estimated_completion_time %3600000)/60000 AS VARCHAR) + 'min, '
+ CAST((estimated_completion_time %60000)/1000 as VARCHAR) + ' sec' AS est_time_to_go,
DATEADD(SECOND,estimated_completion_time/1000, GETDATE()) AS estimated_completion_time
FROM sys.dm_exec_requests r
CROSS APPLY sys.dm_exec_sql_text(r.sql_handle) a
WHERE r.command IN ('BACKUP DATABASE','RESTORE DATABASE', 'BACKUP LOG','RESTORE LOG');

==========================================================
CHECKING PROGRESS OF RESTORING AFYER AUTOMATIC SEEDING
=========================================================
SELECT local_database_name

,role_desc

,internal_state_desc

,transfer_rate_bytes_per_second

,transferred_size_bytes

,database_size_bytes

,start_time_utc

,end_time_utc

,estimate_time_complete_utc

,total_disk_io_wait_time_ms

,total_network_wait_time_ms

,is_compression_enabled

FROM sys.dm_hadr_physical_seeding_stats
==========================================
command line to test for if directory exists (which is done from SQL when validating the distribution database target) : if exist c:\windows echo 'exists'

and then apply with the appropriate directory so in your case 

if exist "D:\Program Files\Microsoft SQL Server\MSSQL13.MSSQLSERVER\MSSQL\DATA" echo 'exists'

3:17 PM Cyril Carozzo

select  * from msdb..MSdistpublishers  

3:19 PM Cyril Carozzo

SELECT * FROM msdb.dbo.MSdistpublishers
sp_configure 'show advanced options',1
sp_configure


====SETUP ADMIN CONNECTION TO AN SQL SERVER=====
1:26 PM Cyril Carozzo



DECLARE @command nvarchar2(512)

     DECLARE @retcode int

     DECLARE @filename nvarchar2(260) 

    declare @echo_text nvarchar2(20)

 

    select @echo_text = 'file_exists'

 

     set @filename='D:\Program Files\Microsoft SQL Server\MSSQL13.MSSQLSERVER\MSSQL\DATA'

    select @command = N'if exist "' + sys.fn_escapecmdshellsymbolsremovequotes(@filename) collate database_default + N'" echo ' + @echo_text

      exec @retcode = master.dbo.xp_cmdshell @command

      select @retcode

1:26 PM Cyril Carozzo

admin:10.234.17.49


===============================
CREATE TABLE BACKUP FROM SELECT
==============================
select * into StanbicIBTC.EZCash].[dbo].[Transaction_BCC_Insurance_update
from 
(select C.* from StanbicIBTC.EZCash].[dbo].[Transaction C,
(select distinct(a.AccountNo),max(a.transactiondate)Date FROM StanbicIBTC.EZCash].[dbo].[Transactiona
  left join StanbicIBTC.EZCash].[dbo].[CustomerUPLLimit b
  on a.CIFID = b.CIFID
  where b.customer_type = 'BCC'
  and a.IsSuccessful = '1' and a.TransactionType in ('NEW')
  group by a.AccountNo)D
  where C.TransactionDate = D.Date
  and c.AccountNo = D.AccountNo
  and c.IsSuccessful = '1' and c.TransactionType in ('NEW')
  and c.InsuranceName not like '%BCC%'

union 

select C.* from StanbicIBTC.EZCash].[dbo].[Transaction C,
(select distinct(a.AccountNo),max(a.transactiondate)Date FROM StanbicIBTC.EZCash].[dbo].[Transactiona
  left join StanbicIBTC.EZCash].[dbo].[CustomerUPLLimit b
  on a.CIFID = b.CIFID
  where b.customer_type = 'BCC'
  and a.IsSuccessful = '1' and a.TransactionType in ('TOPUP')
  group by a.AccountNo)D
  where C.TransactionDate = D.Date
  and c.AccountNo = D.AccountNo
  and c.IsSuccessful = '1' and c.TransactionType in ('TOPUP')
  and c.InsuranceName not like '%BCC%')TOTAL
  
  
EVENT VIEWER
1069  FAILURE OF A CLUSTER RESOURCE DUE TO NIC ISSUE
1045 IS CLUSTER IP ADDRESS WARNING FOR NIC
1074 IS SERVER RESTART EVENT ID



==================================
CLEAR SYSTEM VOLUME INFORMATION
==================================

DISABLE DISTRUBTED LINK SHARING CLIENT SERVICE
LAUNCH CMD AS ADMIN
NAVIGATE TO THE DRIVE WITH SYSTEM VOLUME USING DRIVE_NAME(DRIVE ALPHABET):
RUN THE COMMAND rmdir "System Volume Information" /s
ANSWER Y AND IT WILL GO

YOU CAN REPEAT THE STEP AGAIN TO REMOVE MORE FROM SYSTEM VOLUME INFORMATION FOLDER


-- ========================================================================================
-- Create User as DBO template for Azure SQL Database and Azure SQL Data Warehouse Database
-- ========================================================================================
-- For login <login_name, sysname, login_name>, create a user in the database
CREATE USER BluemallV2_admin
	FOR LOGIN BluemallV2_admin
	WITH DEFAULT_SCHEMA = dbo
GO

-- Add user to the database owner role
EXEC sp_addrolemember N'db_owner', N'BluemallV2_admin'
GO

--=================================================
--TEMDB RELATED SCRIPTS
--=================================================

--current TEMPDB SIZE TEMPLATE--
SELECT
DB_NAME(database_id) AS db_name_
,file_id
,name
,physical_name
,size * 8/1024 AS size_MB
,type_desc
,CASE WHEN is_percent_growth = 1 THEN CAST(growth AS varchar(3)) + ' %' ELSE CAST(growth * 8/1024 AS varchar(10)) + ' MB' END AS growth
,max_size * 8/1024 AS max_size_MB
FROM master.sys.master_files
WHERE DB_NAME(database_id)  = 'tempdb'
ORDER BY db_name_, type, file_id


--TEMPDB SPACE USAGE
SELECT (SUM(unallocated_extent_page_count)*1.0/128) AS [Free space(MB)],
(SUM(version_store_reserved_page_count)*1.0/128)  AS [Used Space by VersionStore(MB)],
(SUM(internal_object_reserved_page_count)*1.0/128)  AS [Used Space by InternalObjects(MB)],
(SUM(user_object_reserved_page_count)*1.0/128)  AS [Used Space by UserObjects(MB)]
FROM tempdb.sys.dm_db_file_space_usage;

--current TEMPDB SIZE TEMPLATE--
SELECT
'tempdb' AS db_name_
,file_id
,name
,physical_name
,size * 8/1024 AS size_MB
,type_desc
,CASE WHEN is_percent_growth = 1 THEN CAST(growth AS varchar(3)) + ' %' ELSE CAST(growth * 8/1024 AS varchar(10)) + ' MB' END AS growth
,max_size * 8/1024 AS max_size_MB
FROM tempdb.sys.database_files
ORDER BY type, file_id;



DECLARE @newDriveAndFolder VARCHAR(8000);

SET @newDriveAndFolder = 'E:\Program Files\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\Data';

SELECT [name] AS [Logical Name]
    ,physical_name AS [Current Location]
    ,state_desc AS [Status]
    ,size / 128 AS [Size(MB)] --Number of 8KB pages / 128 = MB
    ,'ALTER DATABASE tempdb MODIFY FILE (NAME = ' + QUOTENAME(f.[name])
    + CHAR(9) /* Tab */
    + ',FILENAME = ''' + @newDriveAndFolder + CHAR(92) /* Backslash */ + f.[name]
    + CASE WHEN f.[type] = 1 /* Log */ THEN '.ldf' ELSE '.mdf' END  + ''''
    + ');'
    AS [Create new TempDB files]
FROM sys.master_files f
WHERE f.database_id = DB_ID(N'tempdb')
ORDER BY f.[type];



ALTER DATABASE tempdb MODIFY FILE (NAME = [tempdev] ,FILENAME = 'E:\Program Files\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\Data\tempdev.mdf');
--ALTER DATABASE tempdb MODIFY FILE (NAME = [templog] ,FILENAME = 'E:\Program Files\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\Data\templog.ldf');


--tempdb


--================================
--MISSING INDEXES IN A DB
--============================
SELECT
migs.avg_total_user_cost * (migs.avg_user_impact / 100.0) * (migs.user_seeks + migs.user_scans) AS improvement_measure,migs.user_seeks, migs.avg_user_impact,
OBJECT_NAME(mid.OBJECT_ID,mid.database_id) AS [TableName],
'CREATE INDEX [_dta_index_' + CONVERT (varchar, mig.index_group_handle) + '_' + CONVERT (varchar, mid.index_handle)
+ '_' + LEFT (PARSENAME(mid.statement, 1), 32) + ']'
+ ' ON ' + mid.statement
+ ' (' + ISNULL (mid.equality_columns,'')
+ CASE WHEN mid.equality_columns IS NOT NULL AND mid.inequality_columns IS NOT NULL THEN ',' ELSE '' END
+ ISNULL (mid.inequality_columns, '')
+ ')'
+ ISNULL (' INCLUDE (' + mid.included_columns + ')', '') AS create_index_statement,
migs.*, mid.database_id, mid.[object_id]
FROM sys.dm_db_missing_index_groups mig
INNER JOIN sys.dm_db_missing_index_group_stats migs ON migs.group_handle = mig.index_group_handle
INNER JOIN sys.dm_db_missing_index_details mid ON mig.index_handle = mid.index_handle
WHERE migs.avg_total_user_cost * (migs.avg_user_impact / 100.0) * (migs.user_seeks + migs.user_scans) > 10
--And mid.statement like '%SalesRssDBPRD%'
and mid.database_id = DB_ID()
And OBJECT_NAME(mid.OBJECT_ID,mid.database_id)  = 'AirtimePurchase'
ORDER BY migs.user_seeks DESC --migs.avg_total_user_cost * migs.avg_user_impact * (migs.user_seeks + migs.user_scans) DESC;