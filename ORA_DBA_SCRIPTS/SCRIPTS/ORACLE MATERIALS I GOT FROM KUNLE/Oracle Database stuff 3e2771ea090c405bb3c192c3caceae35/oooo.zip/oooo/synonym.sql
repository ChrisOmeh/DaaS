select * from dba_objects where owner = 'HR'

select * from dba_sys_privs;

create table test_table(
s_num number(4),
test_col_1 varchar2(30))


begin
  declare
    i number(3);
  for i in 1 .. 20 
    loop
      insert into test_table values (i, 'entry ' || i);
    end loop
  commit;
end;

select * from test_table

create synonym tt for hr.test_table

alter synonym tt compile;

drop public synonym tt

select * from tt
