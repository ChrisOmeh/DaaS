------
/*
Pre requisites.

- db must be open
- user must have create tablesapce privileges.

Tables paces must have either a datafile or a tempfile and this file contains the actual data
-You must specify the initial size
you can include autoextend ON 
- can include smallfile(1022 data or temp files of 4 million blocks each) or bigfile ( 4 billion blocks, just one data or temp file) clause to override default tablespsce type.

-- Default availability is online

-- Extent management (can be either autoallocate or uniform) default is uniform for temporary tablespaces and auto allocate for other tablespaces.

-- Logging clause (nologging or logging) defualt for temporary tablespace is nologging while loggin is default for others.

-- segment mgnt clause (auto or manual) auto is recommended.
-- data segment compression. (disabled by default)
*/

select * from v$version;

select * from v$containers;

select * from dbms_metadata.get_ddl('DATABASE', 'PDBTS') from dual;

select distinct(o.object_type) from dba_objects o 

select * from dba_users;

select * from cdb_roles;


create tablespace t1;

---- make sure 'db_create_file_dest' parameter is set for 'create tablespace t1;' to work 
select * from v$parameter where name like '%db_create_file_dest%'

alter system set db_create_file_dest='/u01/app/oracle/oradata/practiceOrcl/pdbts';

create tablespace t1;

select * from dba_tablespaces;

select dbms_metadata.get_ddl('TABLESPACE', 'T1') from dual;

create tablespace t2;

drop tablespace t2 including contents and datafiles;



------------------------------------alter tablespace and datafiles
select * from v$tablespace;

select * from v$datafile;
select * from dba_data_files;

create tablespace t3;

create user t3user identified by t3user default tablespace t3;
grant create session, create table, unlimited tablespace to t3user;

select * from dba_users where lower(username) = 't3user';

create table t3user.emp( id number, name varchar2(200));

insert into t3user.emp values (1,'ford');
insert into t3user.emp values (2,'sara');
insert into t3user.emp values (3,'ali');
commit;


alter tablespace t3 read only;
select * from dba_tablespaces; -- notice the status column

insert into t3user.emp values (4,'dave'); -- will throw error


alter tablespace t3 read write;
insert into t3user.emp values (4,'dave'); -- will work now



--------resize tablespace and datafile
select * from v$tablespace;
select * from v$datafile;


alter database 
      datafile '/u01/app/oracle/oradata/practiceOrcl/pdbts/PRACTICEORCL/BF51F82DA7892838E053DB00010AEC7C/datafile/o1_mf_t3_j6vgvnj3_.dbf' resize 200M

select * from v$datafile;  -- bytes have changed

alter tablespace t3 add datafile
      '/u01/app/oracle/oradata/practiceOrcl/pdbts/PRACTICEORCL/t3_02.dbf' size 100M
      
select * from v$datafile;  -- new datafile added with the same ts# as tablespace t3

alter database 
      datafile '/u01/app/oracle/oradata/practiceOrcl/pdbts/PRACTICEORCL/t3_02.dbf' resize 5M


      
------------ moving datafiles

create tablespace t4 datafile '/u01/app/oracle/oradata/practiceOrcl/pdbts/t4_01.dbf' size 25M;

-- rename datafile from t4_01 to t4_001
alter database move datafile '/u01/app/oracle/oradata/practiceOrcl/pdbts/t4_01.dbf' to '/u01/app/oracle/oradata/practiceOrcl/pdbts/t4_001.dbf'

select * from dba_data_files;

-- move datafile 
alter database move datafile '/u01/app/oracle/oradata/practiceOrcl/pdbts/t4_001.dbf' to '/u01/app/oracle/oradata/practiceOrcl/pdbts/t4/t4_001.dbf'
