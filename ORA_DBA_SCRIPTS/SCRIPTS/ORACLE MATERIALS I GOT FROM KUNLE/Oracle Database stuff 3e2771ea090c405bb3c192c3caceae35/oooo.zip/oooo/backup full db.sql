run {
allocate channel c1 ;
allocate channel c2 ;
allocate channel c3 ;
allocate channel c4 ;
allocate channel c5 ;
allocate channel c6 ;
allocate channel c7 ;
allocate channel c8 ;
allocate channel c9 ;
allocate channel c10;
allocate channel c11;
allocate channel c12;
allocate channel c13;
allocate channel c14;
allocate channel c15;

BACKUP
    $BACKUP_TYPE
     FILESPERSET 1
    FORMAT 'basis_bk_u%u_s%s_p%p_t%t'
    DATABASE;

BACKUP
    FILESPERSET 30
    FORMAT 'basis_arch_u%u_s%s_p%p_t%t'
    ARCHIVELOG
        ALL
    DELETE INPUT;

BACKUP
 BACKUP
    FORMAT 'basis_ctrl_u%u_s%s_p%p_t%t'
    CURRENT CONTROLFILE;

release channel c1;
release channel c2;
release channel c3;
release channel c4;
release channel c5;
release channel c6;
release channel c7;
release channel c8;
release channel c9;
release channel c10;
release channel c11;
release channel c12;
release channel c13;
release channel c14;
release channel c15;
}