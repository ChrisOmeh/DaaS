
select * from v$version;

select * from v$parameter
order by name
where name like '%block%';

select sysdate from dual;

select * from v$parameter2
where name like '%pfile%'
order by name

select * from v$system_parameter;

select * from v$system_parameter where isdefault <> 'TRUE';

select * from v$parameter v where v.name like '%idle%';

select * from v$system_parameter v where v.name like '%idle%'

alter session set container=pdborcl;



----------------------------------------Profile user
select distinct(profile) from dba_profiles

create user kunledb identified by Dbaguru123$ password expire profile default;
select * from dba_users where UPPER(username) like '%KUN%';
grant create session to kunledb;
grant select any dictionary to kunledb;
---drop user kunledb


----------------------------------------
select * from v$containers;

select * from gv$session;

alter system kill session '64, 6869'

select * from dba_users u where u.username like '%H%'

select * from v$tablespace;

alter pluggable database all open

alter session set container = pdb1

create table demo 
(
id INTEGER GENERATED ALWAYS AS IDENTITY,
name VARCHAR(30),
PRIMARY KEY (id)
);

--drop table demo

select count(*) from demo;

/*
BEGIN
FOR v_LoopCounter IN 1..50 LOOP
    INSERT INTO demo (name)
		VALUES ('Jon Doe');
	END LOOP;
END;
*/

select * from dba_users where username like '%ADMIN%'

select * from dba_sys_privs

alter session set container=pdb1
select * from dba_objects o where o.object_type = 'TABLE' and o.object_name = 'DEMO'


select * from dba_db_links;
