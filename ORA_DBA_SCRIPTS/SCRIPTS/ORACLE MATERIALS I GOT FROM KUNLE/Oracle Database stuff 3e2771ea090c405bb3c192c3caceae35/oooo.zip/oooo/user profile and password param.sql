select * from v$containers;

select * from dba_profiles;

-- Generally, profiles are used to control resource limits and password parameters.

-- to create a common profile you moust connect to ht e container and use the common_user_prefix and add container=all
--- profiles can be assigned either commonly (in the cdb) or locally (in each pdb)



--- Password parameters
/*
can control
1. Account locking -- enables auto  locking of accounts. (failed_login_attempts, password_lock_time, inactive_account_time)
2 Password aging and expiration -- (password_life_time, password_grace_time) (in days)
3. Password history -- (password_reuse_time, password_reuse_max, password_verify_function)
4. Password complexity verification -- it is a pl/sql file/function. the fxn verifies the password (utlpwdmg.sql) (catpvf.sql)

*/

--Resource limits/parameters
-- RESOURCE_LIMIT must be set to TRUE
/*
cpu resources -- (cpu_per_session, cpu_per_call) in seconds eg 3000 = 30 seconds
network and mem resources --
disk i/o resources -- 

*/


--EXAMPLE

----------------------------------Create common profile
select * from dba_profiles;

create profile c##general 
limit 
sessions_per_user 4
idle_time 10
failed_login_attempts 3
password_life_time 180
container = all 

alter profile c##general
limit sessions_per_user 5


----------------------------------Create local profile

alter session set container= pdb1;

select * from v$containers;

select * from dba_profiles;

create profile pdb1profile
limit 
sessions_per_user unlimited
idle_time unlimited
failed_login_attempts 10
password_life_time 180
--inactive_account_time 25

/*
! oerr ora 2376 (run on linux)(replace 2376 with whatever error code you get)
*/


select * from dba_profiles;


-------------------------------------------------password verify fnction
alter session set container = cdb$root;

select * from dba_objects o
where o.object_name like '%VERIFY%'
and o.object_type = 'FUNCTION'

alter session set container = pdb1

select * from dba_objects o
where o.object_name like '%VERIFY%'
and o.object_type = 'FUNCTION'

create profile test_profile
limit
password_verify_function ora12c_strong_verify_function;

select * from dba_profiles;

create user test100 identified by welcome1234#  profile test_profile

grant create session to test100


/*
go to vm
connect using test100/welcome1234#@orclpdb
try to do this
alter user test100 identified by welcome678#
Cause : ORA-28221 error occurs when an user tries to reset his own password 
without specifying the REPLACE keyword, provided the user does not have ALTER USER privilege 
and the user is having a profile with password verify function.
so
it should be
alter user test100 identified by welcome678# replace welcome1234#
*/
