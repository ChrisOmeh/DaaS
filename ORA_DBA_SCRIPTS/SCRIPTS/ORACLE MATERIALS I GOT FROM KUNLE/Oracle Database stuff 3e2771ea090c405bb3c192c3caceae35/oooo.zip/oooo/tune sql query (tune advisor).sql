----------------------------------create tuning task
DECLARE
invisible_blk_tune VARCHAR2(100);
BEGIN
invisible_blk_tune := DBMS_SQLTUNE.create_tuning_task (
sql_id => '87a9w7gx8m5gf',
scope => DBMS_SQLTUNE.scope_comprehensive,
time_limit => 172800,
task_name => '87a9w7gx8m5gf_tuning_task11',
description => 'Tuning task1 for statement 87a9w7gx8m5gf');
DBMS_OUTPUT.put_line('invisible_blk_tune: ' || invisible_blk_tune);
END;

 

-----------------------------execute tuning task
EXEC DBMS_SQLTUNE.execute_tuning_task(task_name => '87a9w7gx8m5gf_tuning_task11'); --- run in command window

 
--------------------------------------- see output
set long 65536
set longchunksize 65536
set linesize 100
select dbms_sqltune.report_tuning_task('87a9w7gx8m5gf_tuning_task11') from dual;