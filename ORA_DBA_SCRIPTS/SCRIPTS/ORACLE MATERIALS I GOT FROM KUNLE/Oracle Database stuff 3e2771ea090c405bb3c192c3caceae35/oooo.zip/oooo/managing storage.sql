------------------------managing storage

select * from v$containers;
select * from dba_tables where lower(owner) like '%t3%';


select * from dba_segments s where s.owner = 'T3USER' --- show segment info

select * from dba_extents e where e.owner = 'T3USER' and e.segment_name='EMP' -- show extent info

begin
  for i in 1..50 
    loop
      insert into T3USER.EMP values (i, 'John Doe '||i);
      end loop;
      commit;
end;

select count(*) from T3USER.EMP

select  *  from T3USER.EMP

delete from T3USER.EMP;
--- delete statement does not reduce the size of the blocks or extents

select * from dba_segments s where s.owner = 'T3USER' --- number of blocks and extents didnt change  although they are reusable.
select * from dba_extents e where e.owner = 'T3USER' and e.segment_name='EMP' 

truncate table T3USER.EMP; -- reduces the size of blocks and extents

select * from dba_segments s where s.owner = 'T3USER' --- number of blocks and extents reduced
select * from dba_extents e where e.owner = 'T3USER' and e.segment_name='EMP' 


-------------reusing free blocks  created from update and delete statements
--coalescing free space is oracles way of joining free blocks together to reduce fragementation

---------------segment type
create unique index T3USER.emp_ind on T3USER.emp(ID);

select * from dba_segments s where s.owner = 'T3USER';


------------------ compression (basic)

create table test_01 
as
select * from dba_objects where rownum < 10000;  

select count(*) from test_01;

select dbms_metadata.get_ddl('TABLE','TEST_01') from dual;  --- notice that table is NOCOMPRESS   

analyze table test_01 compute statistics; -- for the db to gather stats on the table


select t.table_name, t.blocks, t.pct_free, t.compression, t.compress_for  
from user_tables t
where t.table_name = upper('test_01')

-- before compress table has 166 blocks and pct_free is 10 and compression is disabled;

create table test_02 compress basic
as 
select * from dba_objects where rownum < 10000;

analyze table test_02 compute statistics

select t.table_name, t.blocks, t.pct_free, t.compression, t.compress_for  
from user_tables t
where t.table_name = upper('test_02') 

-- after compress table has 43 blocks and pct_free is  0 and compression is enabled;


/*
Normal 'insert' operation into a table wiht basic compression has no effects
*/

--create a table just as dba_objects but empty
create table test_03 compress basic
as
select * from dba_objects where 1 = 2

select * from test_03;

-- 9999 rows from dba_objects
insert into test_03 
select * from dba_objects where rownum < 10000;
commit;

select count(*) from test_03;

select t.table_name, t.blocks, t.pct_free, t.compression, t.compress_for  
from user_tables t
where t.table_name = upper('test_03')
---- blocks are 0

analyze table test_03 compute statistics;
---- blocks are 244 now 

create table test_04
as
select * from dba_objects where 1 = 2

/*
insert with 'append'  --TAKE NOTE

*/
