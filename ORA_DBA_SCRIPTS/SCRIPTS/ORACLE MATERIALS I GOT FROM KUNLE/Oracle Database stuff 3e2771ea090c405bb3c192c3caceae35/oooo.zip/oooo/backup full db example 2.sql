ORACLE_BASE=/u01/app/oracle
ORACLE_HOME=/u01/app/oracle/product/12.2.0/dbhome_1
BACKUP_LOG_PATH=/u02/oracle/backup/vbank

export ORACLE_BASE
export ORACLE_HOME
export ORACLE_SID=vbank
export BACKUP_LOG_PATH

LOG_FILE=${BACKUP_LOG_PATH}/backup_db.log
$ORACLE_HOME/bin/rman msglog=${LOG_FILE} << EOF 
connect target / 
run { 
allocate channel t1 type disk; 
allocate channel t2 type disk; 
allocate channel t3 type disk;
allocate channel t4 type disk;
allocate channel t5 type disk;
allocate channel t6 type disk;

backup database format '/u02/oracle/backup/vbank/database_%d_%u_%s'; 

release channel t1; 
release channel t2; 
release channel t3; 
release channel t4;
release channel t5;
release channel t6;
} 
sql 'alter system archive log current'; 
run { 
allocate channel a1 type disk; 
allocate channel a2 type disk; 
allocate channel a3 type disk; 
allocate channel a4 type disk;
allocate channel a5 type disk;
allocate channel a6 type disk;
backup archivelog all format '/u02/oracle/backup/vbank/arch_%d_%u_%s'; 
release channel a1; 
release channel a2; 
release channel a3;
release channel a4;
release channel a5;
release channel a6; 
} 

run { 
allocate channel c1 type disk; 
backup current controlfile for standby format '/u02/oracle/backup/vbank/Control_%d_%u_%s'; 
release channel c1; 
} 
exit; 
EOF