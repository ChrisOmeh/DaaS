select * from dba_data_files;

alter tablespace sysaux add datafile '+DATA_DW' size 5G;

--------------------------------------------------------------------------------------------------------------------------

alter tablespace TRANSACT_2021 add datafile '+DATA' size 31G;

The '+' is very important in this command to specify that it is an ASM. If the + sign is omitted, the database can crash (depending on the tablespace importance) because the datafile will be created on only one instance
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

For big file tablespaces we increase the datafile size

alter database datafile '+DATAC1/CMOBILE/4FA78B923D2C0A4EE053EB06020A8332/DATAFILE/vanso.1229.949168621' resize 400G;