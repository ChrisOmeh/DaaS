select a.tablespace_name "Tablespace_Name/Archive_Log",round((sum(a.tots/1073741824)),2) "Tot_Size(GB)",
     round((sum(a.sumb/1073741824)),2) "Tot_Free(GB)",
     round((sum(a.sumb)*100/sum(a.tots)),2) Pct_Free
     ---sum(a.largest/1024) Max_Free,sum(a.chunks) Chunks_Free
     from
     (
     select tablespace_name,0 tots,sum(bytes) sumb,
     max(bytes) largest,count(*) chunks
     from dba_free_space a
     group by tablespace_name
     union
     select tablespace_name,sum(bytes) tots,0,0,0 from
      dba_data_files
     group by tablespace_name) a
     group by a.tablespace_name
union
select 'ARCHIVE_LOG_SIZE', (space_limit/(1024*1024*1024)) "TOT_SIZE (GB)",  (space_limit/(1024*1024*1024) - space_used /(1024*1024*1024)) "TOT_FREE (GB)",
(1 - space_used/space_limit) * 100 PCT_FREE
from v$recovery_file_dest
order by pct_free;


--select * from dba_users where username like '%AYO%' order by username;
