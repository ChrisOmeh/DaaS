---------create dblink
/*
user must have 'create database link' or 'create public database link privileges'
*/

alter session set container = dbcapdb;

/*
create database link <db_link_name> 
connect to <user_> identified by <password_> 
using '<connect_string_for_remote_db>';
*/

connect dbcapdbadmin/Password123_@10.1.0.219:1521/dbcapdb

create database link read_from_pdb1 
connect to pdb1admin identified by Password123_ 
using 'pdb1'

drop database link read_from_pdb1

select * from dba_db_links;

select * from demo@read_from_pdb1;
