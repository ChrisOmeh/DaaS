--------------create pdb from pdb$seed

select c.NAME, c.OPEN_MODE, c.CON_ID from v$containers c

alter session set container= cdb$root;

alter session set container= PDB$SEED;

select username, con_id, default_tablespace, common from cdb_users;

select username, default_tablespace, common from dba_users;

select * from v$datafile;

-- mkdir /u01/app/oracle/oradata/practiceOrcl/pdb1

create pluggable database pdb1
       admin user pdb1admin identified by Password123_
       roles = (dba)
       default tablespace users 
               datafile '/u01/app/oracle/oradata/practiceOrcl/pdb1/users01.dbf' size 250M autoextend on
       file_name_convert = ('/u01/app/oracle/oradata/practiceOrcl/pdbseed/',
                           '/u01/app/oracle/oradata/practiceOrcl/pdb1/')
                           
                           
select distinct(status) from gv$session

select * from gv$session

--alter system kill session '64, 12964'


alter session set container = pdb1;
alter pluggable database open;
select username, con_id, default_tablespace, common from cdb_users;
select username, default_tablespace, common from dba_users;
select * from v$datafile;

alter session set container = cdb$root;

create pluggable database pdbtodrop
       admin user pdbtodropadmin identified by Password123_
       roles = (dba)
       default tablespace users
       datafile '/u01/app/oracle/oradata/practiceOrcl/pdbtodrop/users01.dbf' size 200M autoextend on
       file_name_convert = ('/u01/app/oracle/oradata/practiceOrcl/pdbseed/',
                           '/u01/app/oracle/oradata/practiceOrcl/pdbtodrop/')
       --complete this
       
select * from v$containers;

alter pluggable database pdbtodrop close;

alter session set container = pdb1;


---------------drop pdb
--PDB must be closed
drop pluggable database pdbclone2 including datafiles;




---------------- cloning a pluggable database
select * from v$containers;

--------- making a clone from PDBORCL to new pdb (pdbclone)
-- mkdir /u01/app/oracle/oradata/practiceOrcl/pdbclone

-- set pluggable you want to clone to read only

alter pluggable database pdborcl close 

alter pluggable database pdborcl open read only

create pluggable database pdbclone from pdborcl
       file_name_convert = ('/u01/app/oracle/oradata/practiceOrcl/pdborcl/',
                         '/u01/app/oracle/oradata/practiceOrcl/pdbclone/')

---- OR

-- mkdir /u01/app/oracle/oradata/practiceOrcl/pdbclone2

create pluggable database pdbclone2 from pdborcl
       create_file_dest='/u01/app/oracle/oradata/practiceOrcl/pdbclone2/'


------------------------- unplugging a pluggable database.

-- close pdb
-- unplug to xml
-- drop pdb
-- check compatibility
-- plug from xml


-- step 1
alter pluggable database pdbclone close;

-- step 2
alter pluggable database pdbclone unplug into '/u01/app/oracle/oradata/practiceOrcl/pdbclone.xml'

select * from v$containers;
select con_id, open_mode from v$pdbs;


-- step 3
drop pluggable database pdbclone keep datafiles;

-- step 5
create pluggable database pdbfromXML 
using '/u01/app/oracle/oradata/practiceOrcl/pdbclone.xml'
file_name_convert = ('/u01/app/oracle/oradata/practiceOrcl/pdbclone/',
                  '/u01/app/oracle/oradata/practiceOrcl/pdbfromXML/')
                  
--OR--
CREATE PLUGGABLE DATABASE pdbfromXML 
USING '/u01/app/oracle/oradata/practiceOrcl/pdbclone.xml'
NOCOPY TEMPFILE REUSE;


-- open pdb
alter pluggable database pdbfromxml open;
