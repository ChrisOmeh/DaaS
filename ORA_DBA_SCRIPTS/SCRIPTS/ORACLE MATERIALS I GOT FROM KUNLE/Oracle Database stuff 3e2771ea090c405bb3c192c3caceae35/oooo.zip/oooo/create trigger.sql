create or replace trigger trig_dep_aud
before update on hr.departments
for each row
--REFERENCING OLD AS hist

declare
    v_os_user varchar2(30);
    v_ip_address varchar2(30);
    v_mod_date date;
    v_mod_time varchar2(10);
begin 

    v_ip_address := sys_context('USERENV', 'IP_ADDRESS');
    v_os_user := sys_context('USERENV', 'OS_USER');
    v_mod_date := to_date(sysdate, 'DD-MON-YY');
    v_mod_time := TO_CHAR(sysdate, 'hh24:mi:ss');
    
    insert into hr.departments_aud
    values 
    (
    :old.department_id,
    :old.department_name,
    :old.manager_id,
    :old.location_id,
    v_os_user,
    v_ip_address,
    v_mod_date,
    v_mod_time
    );
    
    exception
      when others then
        dbms_output.put_line(sqlcode || '------>' || sqlerrm);
end;
