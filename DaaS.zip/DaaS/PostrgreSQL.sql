https://www.enterprisedb.com/promote/webinar/oracle-migration-webinar-series-part-3?aliId=eyJpIjoiWVdHeVE5Q05oMjg5WUNDNSIsInQiOiJ0N2lRNkJJQ3dGcWVjbUZ4Y1JiMUpBPT0ifQ%253D%253D

https://pgpedia.info/postgresql-versions/postgresql-17.html

https://www.enterprisedb.com/products/plans-comparison#selfmanagedstandardplan

https://www.enterprisedb.com/docs/edb-postgres-ai/cloud-service/references/supported_database_versions/

===========================
EDB POSTGRES DOCUMENTATION
===========================
https://www.enterprisedb.com/docs/pdfs/epas/17/epas_v17_documentation.pdf


EDB Postgres Distributed is for advanced Postgres offering HA, multi-master replication and other advanced features. Fully requires a subscription plan
 
EDB Postgres Extended is extended version of well know open source Postgres. Just that EDB team built additional add ons to make it more robust.
 
 
EDB Advanced Postgres is the main Postgres offering all Oracle based compatibles.
 
Rep manager is not yet licensed by EDB
 
Failover manager is better for configuration of replication in Advanced Postgres

Syncronous Muliti-master Primary site with Asyncronous Warm WAL/Log shipping STANDBY(Streaming Replication).

One-mode Primary with Asyncronous Warm WAL/Log shipping STANDBY.

1. Create TABLESPACE for any database. The owner must be enterprisedb user
2. Create Database using TABLESPACE create above.
3. Create all objects on the database using the tablespace specified during creation.


PGADMIN INSTALLATION: https://www.enterprisedb.com/docs/epas/13/edb_pgadmin_linux_qs/

SELECT pg_database.datname as "database_name", pg_size_pretty(pg_database_size(pg_database.datname)) AS size_in_mb FROM pg_database ORDER by size_in_mb DESC;
select usename,usesuper,valuntil from pg_shadow;
select name,setting from pg_settings where name in ('log_disconnections','log_connections');
SELECT * FROM pg_available_extensions;
select * from pg_hba_file_rules;
select * from pg_tablespace;
select * from dba_profiles;
show log_statement;



https://www.enterprisedb.com/products/plans-comparison#selfmanagedstandardplan
[11/27, 8:30 PM] Chukwuemeka: EDB Postgres Distributed is for advanced Postgres offering HA, multi-master replication and other advanced features. Fully requires a subscription plan
 
EDB Postgres Extended is extended version of well know open source Postgres. Just that EDB team built additional add ons to make it more robust.
 
 
EDB Advanced Postgres is the main Postgres offering all Oracle based compatibles.
 
Rep manager is not yet licensed by EDB
 
Failover manager is better for configuration of replication in Advanced Postgres

https://www.enterprisedb.com/docs/epas/latest/installing/
 
https://yum.postgresql.org/howto/


https://www.enterprisedb.com/docs/epas/latest/installing/linux_x86_64/epas_rhel_9/
https://www.enterprisedb.com/docs/epas/latest/installing/linux_x86_64/epas_rhel_8/
 
 
 
EDB Access repo token: Vix7FvSXYW8xFe7sk57hYt1FtxZMrrBM
https://www.enterprisedb.com/repos#repository-packages

https://www.youtube.com/watch?v=sCNaP_A1AMw&t=159s&ab_channel=DBATrainings


Checking an Existing Cluster for Oracle Compatibility
Use this query at the SQL prompt to verify if the current installation is Oracle-compatible:

edb=# show db_dialect;

db_dialect
------------
Redwood
If the result is “Redwood,” then it’s Oracle-compatible. If not, the query will error out:

ERROR:  unrecognized configuration parameter "db_dialect"
SQL state: 42704
You can also run these queries to determine Oracle-compatibility:

select * from dual; 
or 
select sysdate;

========================================
MIGRATE ORACLE TO POSTGRESQL
========================================
https://www.enterprisedb.com/postgres-tutorials/how-convert-oracle-postgresql-online
https://www.enterprisedb.com/postgres-tutorials/how-run-postgres-oracle-compatibility-mode

===================
REPLICATION SETUP
===================
https://www.enterprisedb.com/postgres-tutorials/postgresql-replication-and-automatic-failover-tutorial#section-18
https://www.youtube.com/watch?v=x0WaijdJEko
https://www.youtube.com/watch?v=cjFWMqQmNKA
https://www.youtube.com/watch?v=x0WaijdJEko

In PROD setup, is better to have 3 nodes setup to avoid having a witness Node. Witness Node is optional. In 3 Nodes(1 Master, 2 standby), there is no 
is no need for a witness server.

Agent helps monitor the health of each Node in the Failover Cluster.
VIP(Virtual IP) is floating IP, Listener IP or Cluster Lever IP for the Nodes in the cluster. The VIP always points to the Primary Node.
The VIP can be used for application connection.
JGROUP: Manages EFM commnucation with each other. It can be regarded as Failover Over manager is SQL sever Alwayson Availability Group. It allows
Clusted Nodes to connect to each other.


/
/I
\I
\i
\l
ALTER ROLE enterprisedb IDENTIFIED BY qwer1234;
SELECT name FROM pg_settings WHERE context = 'postmaster';
show database;
show databases;
logoutexit
\q
/l
\l
/l
\l
use edb;
SELECT pg_database.datname as "database_name", pg_size_pretty(pg_database_size(pg_database.datname)) AS size_in_mb FROM pg_database ORDER by size_in_mb DESC;
SELECT name, setting FROM pg_settings WHERE category = 'File Locations';
SELECT * FROM pg_available_extensions;
select usename,usesuper from pg_user;
select * from dba_profiles;
select * from pg_tablespace;
select * from pg_hba_file_rules;
show log_statement;
select name,setting from pg_settings where name in ('log_disconnections','log_connections');
select usename,usesuper,valuntil from pg_shadow;
show search_path;
\db
\dbt
SELECT * FROM pg_available_extensions;
show search_path;
select usename,usesuper,valuntil from pg_shadow;
select name,setting from pg_settings where name in ('log_disconnections','log_connections');
select usename,usesuper,valuntil from pg_shadow;
SELECT pg_database.datname as "database_name", pg_size_pretty(pg_database_size(pg_database.datname)) AS size_in_mb FROM pg_database ORDER by size_in_mb DESC;
select * from pg_hba_file_rules;
select * from dba_profiles;
show log_statement;
select name,setting from pg_settings where name in ('log_disconnections','log_connections');
\q
show parameter no-redwood-compat;
show parameter no-redwood;
show parameter redwood;
\cls
select name,setting from pg_settings where name in ('log_disconnections','log_connections');
show log_statement;
select * from dba_profiles;
SELECT * FROM pg_available_extensions;
select * from dba_profiles;
select * from pg_hba_file_rules;
select * from pg_hba_file_rules;
\q
show db_dialect;
select * from pg_hba_file_rules;
select * from dba_profiles;
select name,setting from pg_settings where name in ('log_disconnections','log_connections');
\q
select usename,valuntil,usecreatedb from pg_shadow;
select * from dba_profiles;
create user APPUSER with password 'Ch#nge1TN00#';
select usename,valuntil,usecreatedb from pg_shadow;
SELECTr.rolname,ARRAY(SELECT b.rolnameFROM pg_catalog.pg_auth_members mJOIN pg_catalog.pg_roles b ON (m.roleid = b.oid)WHERE m.member = r.oid) as memberofFROM pg_catalog.pg_roles rORDER BY 1;
\h GRANT
select * from pg_tablespace;
\db+
create tablespace appuser_postgres location '/data/edbpostgres';
select * from pg_tablespace;
\db+
alter tablespace appuser_postgres owner to APPUSER;
\db+
select usename,valuntil,usecreatedb from pg_shadow;
select * from dba_profiles;
create profile APP_PROFILE;
select * from dba_profiles;
alter user APPUSER default profile APP_PROFILE;
alter user APPUSER default_profile APP_PROFILE;
/l
\l
CREATE DATABASE "DEVDB"WITH TABLESPACE appuser_postgresOWNER "APPUSER"ENCODING 'UTF8'LC_COLLATE = 'en_US.UTF-8'LC_CTYPE = 'en_US.UTF-8'TEMPLATE template0;
CREATE DATABASE "DEVDB"WITH TABLESPACE appuser_postgresOWNER "appuser"ENCODING 'UTF8'LC_COLLATE = 'en_US.UTF-8'LC_CTYPE = 'en_US.UTF-8'TEMPLATE template0;
select * from pg_database;
/l
\l
alter user APPUSER profile APP_PROFILE;
select * from dba_profiles;


select schemaname,tablename,tableowner,tableowner from pg_tables where tableowner='enterprisedb';
select schemaname,tablename,tableowner,tableowner from pg_tables where tableowner<> 'enterprisedb';


-- Database: DEVDB

-- DROP DATABASE IF EXISTS "DEVDB";

CREATE DATABASE "DEVDB"
    WITH
    OWNER = appuser
    ENCODING = 'UTF8'
    LC_COLLATE = 'en_US.UTF-8'
    LC_CTYPE = 'en_US.UTF-8'
    LOCALE_PROVIDER = 'libc'
    TABLESPACE = appuser_postgres
    CONNECTION LIMIT = -1
    IS_TEMPLATE = False;
	
create user omnichannelusr with password 'Ch#nge1TN00#';

alter user omnichannelusr profile APP_PROFILE;

CREATE SCHEMA AUTHORIZATION omnichannelusr;

-- Tablespace: appuser_postgres

-- DROP TABLESPACE IF EXISTS appuser_postgres;

CREATE TABLESPACE appuser_postgres
  OWNER appuser
  LOCATION /data/edbpostgres;

ALTER TABLESPACE appuser_postgres
  OWNER TO appuser;
  
  -- Tablespace: appuser_postgres

-- DROP TABLESPACE IF EXISTS appuser_postgres;

CREATE TABLESPACE appuser_postgres
  OWNER appuser
  LOCATION /data/edbpostgres;

ALTER TABLESPACE appuser_postgres
  OWNER TO appuser;

COMMENT ON TABLESPACE appuser_postgres
  IS 'appuser tablespace';
  
  

edb=# show data_directory;
  data_directory
-------------------
 /data/edbpostgres
(1 row)

edb=# show ssl;
 ssl
-----
 off
(1 row)

edb=# show shared_buffers;
 shared_buffers
----------------
 128MB
(1 row)

edb=# show maintenance_work_mem;
 maintenance_work_mem
----------------------
 64MB
(1 row)

edb=# show wal_level;
 wal_level
-----------
 replica
(1 row)

edb=# show log_directory;
 log_directory
---------------
 log
(1 row)
