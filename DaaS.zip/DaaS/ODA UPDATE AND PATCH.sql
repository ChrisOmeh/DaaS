========================
ODA UPGRADE/PATCH
========================

Browser user interface(BUI) url.
https://pngoda7:7093/mgmt/index.html
https://pngoda8:7093/mgmt/index.html

user:oda-admin
pwd:SQwer_1234##

DR
18.7-->19.6-->19.10-->19.14-->19.18-->19.20-->19.24

prod
12.2-->18.3-->18.7-->19.6-->19.10-->19.14-->19.18-->19.20-->19.24

DR DPR
18.7-->19.20/19.18-->19.21-->19.24

=====================
ORACLE REPO
=====================
https://yum.oracle.com/repo/OracleLinux/OL6/2/base/x86_64/index.html


====================
PATCH/UPGRADE DOCS
====================
https://docs.oracle.com/en/engineered-systems/oracle-database-appliance/19.18/cmtrn/oda-patches.html#GUID-220DA05B-0F52-4EDA-84C9-BFD15F43802D
https://support.oracle.com/epmos/faces/DocumentDisplay?_afrLoop=21129536517014&id=2757884.1&_afrWindowMode=0&_adf.ctrl-state=nk3s67sqi_4
https://docs.oracle.com/en/engineered-systems/oracle-database-appliance/index.html

Download ODA PATCH and other guides:
https://updates.oracle.com/Orion/PatchDetails/process_form?aru=22625683&patch_password=&no_header=0
https://updates.oracle.com/Orion/PatchDetails/handle_rel_change?release=600000000155760&plat_lang=226P&patch_file=&file_id=&password_required=&password_required_readme=&merged_trans=&aru=23162485&patch_num=30403673&patch_num_id=3584553&default_release=600000000155760&default_plat_lang=226P&default_compatible_with=&patch_password=&orderby=&direction=&no_header=0&sortcolpressed=&tab_number=
https://docs.oracle.com/en/engineered-systems/oracle-database-appliance/19.10/cmtrn/oda-patches.html#GUID-694434A2-4216-43F7-A79A-7AD9DDC92B76
https://blogs.oracle.com/oda/post/oracle-database-19c-support-for-oracle-database-appliance

https://docs.oracle.com/en/engineered-systems/oracle-database-appliance/19.24/cmtxl/upgrading-oracle-database-appliance.html#GUID-4427D77C-C281-4C14-A727-04EE3EF72BAA


=============================================================
Oracle® Database Appliance X7-2 Deployment and User’s Guide
=============================================================
https://docs.oracle.com/en/engineered-systems/oracle-database-appliance/19.20/cmtxl/oracle-database-appliance-x7-2-deployment-and-users-guide.pdf



X7-2HA
https://docs.oracle.com/en/engineered-systems/oracle-database-appliance/19.20/cmtxl/upgrading-oracle-database-appliance.html#GUID-248AC608-06B4-4BCC-A270-36AB2FE9E294

=======================
BASIC COMMAND
=======================
odaadmcli show env_hw
odaadmcli show server
odacli describe-component

Check user Guide above for more.

=========================================================================
Upgrading Oracle Database Appliance Using Data Preserving Reprovisioning
=========================================================================
https://docs.oracle.com/en/engineered-systems/oracle-database-appliance/19.20/cmtxl/upgrading-oracle-database-appliance.html#GUID-FD9E489E-6EAC-4991-B904-40D3B3C89511


