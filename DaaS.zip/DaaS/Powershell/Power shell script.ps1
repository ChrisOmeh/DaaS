﻿Get-Verb
Get-command
Get-Member
Get-help



Get-Command -Name Copy