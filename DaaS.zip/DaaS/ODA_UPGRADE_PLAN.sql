https://pngoda7:7093/mgmt/index.html
https://pngoda8:7093/mgmt/index.html
SQwer_1234##

odacli configure-asr -u asmuseradmin -p welcome1
asruseradmin pngoda5
ipmitool sunoem cli

UP SERVER IN MAINONE DC ==PNGODA6
DOWN SERVER IN MAINONE DC ==PNGODA5
--ORACHK REPORT PATH
/opt/oracle/dcs/oracle.ahf/orachk/SERVER/93ea7609-059d-4d13-a058-8d103edd55d5/orachk_pngoda8_052024_134919/orachk_pngoda8_052024_134919.html

MANUALLY CONVERT TO PHYSICAL STANDBY
https://support.dbagenesis.com/post/convert-physical-standby-into-active-data-guard

odacli-admin set-credential --password SQwer_1234## --username oda-admin
odacli-adm set-credential
odacli-adm set-credential --username oda-admin
odacli update-server-postcheck -v 19.6.0.0.0
odacli create-prepatchreport -s -v 19.6.0.0.0

odacli update-server -c os --local --force -v 19.6.0.0.0
ILOM INFO
/usr/sbin/ipmitool
ipmitool sunoem cli
start /SP/console
ipmitool sunoem cli "start /SP/console"
ipmitool sunoem cli "show /SP/console"
ipmitool sunoem cli "start /SP/console"
ssh -l root 10.234.181.99
ssh -l root 10.234.181.98 passowr =welcome1
set /SP/users/root password
/usr/sbin
ipmitool sunoem cli "show /SP/console"

=====================
IF ILOM IS DOWN
=====================
Log into the ILOM from HOST
cd /SP/network
ls
set state=enabled

reset /SYS or reset /SP
odacli create-dbhome -v 19.20.0.0.230718 -de EE
odacli cleanup-patchrepo -comp GI,DB,OAK,OS -v 19.16.0.0.0
odacli cleanup-patchrepo -comp gi,db,dbvm,server,ALL -v 19.16.0.0.0
odacli cleanup-patchrepo -comp GI,DB -v 18.7.0.0.0
odacli cleanup-patchrepo -comp GI,DB -v 18.3.0.0
odacli cleanup-patchrepo -comp GI,DB,DBVM,SERVER,ALL -v 18.3.0.0


odacli create-dbhome -v 19.24.0.0.240716 -de EE
19.24.0.0.240716


======================
ODA MYSQL DB CONNECT
=====================
systemctl stop initdcsagent

cd /opt/oracle/dcs/mysql/bin/ 
./mysql -u root --socket=/opt/oracle/dcs/mysql/log/mysqldb.sock 
use dcsagentdb;


=====================
ORACLE REPO
=====================
https://yum.oracle.com/repo/OracleLinux/OL6/2/base/x86_64/index.html

Pls note that password reset is cluster level thing. Do it just in one of the nodes.
https://exitas.be/upgrading-a-bare-metal-oda-to-19c/
https://www.dbi-services.com/blog/patching-oda-ha-from-19-8-to-19-10/
https://docs.oracle.com/en/engineered-systems/oracle-database-appliance/19.18/cmtrn/oda-patches.html#GUID-220DA05B-0F52-4EDA-84C9-BFD15F43802D
https://support.oracle.com/epmos/faces/DocumentDisplay?_afrLoop=21129536517014&id=2757884.1&_afrWindowMode=0&_adf.ctrl-state=nk3s67sqi_4
https://docs.oracle.com/en/engineered-systems/oracle-database-appliance/index.html

Download ODA PATCH:
https://updates.oracle.com/Orion/PatchDetails/process_form?aru=22625683&patch_password=&no_header=0
https://updates.oracle.com/Orion/PatchDetails/handle_rel_change?release=600000000155760&plat_lang=226P&patch_file=&file_id=&password_required=&password_required_readme=&merged_trans=&aru=23162485&patch_num=30403673&patch_num_id=3584553&default_release=600000000155760&default_plat_lang=226P&default_compatible_with=&patch_password=&orderby=&direction=&no_header=0&sortcolpressed=&tab_number=
https://docs.oracle.com/en/engineered-systems/oracle-database-appliance/19.10/cmtrn/oda-patches.html#GUID-694434A2-4216-43F7-A79A-7AD9DDC92B76
https://blogs.oracle.com/oda/post/oracle-database-19c-support-for-oracle-database-appliance

https://docs.oracle.com/en/engineered-systems/oracle-database-appliance/19.24/cmtxl/upgrading-oracle-database-appliance.html#GUID-4427D77C-C281-4C14-A727-04EE3EF72BAA
SR FEEDBACK 

/opt/oracle/dcs/bin/restartagent.sh

X7-2HA
https://docs.oracle.com/en/engineered-systems/oracle-database-appliance/19.20/cmtxl/upgrading-oracle-database-appliance.html#GUID-248AC608-06B4-4BCC-A270-36AB2FE9E294
Share output OF
	
Hi

Good day!

Please share below details for review



odaadmcli show env_hw
odaadmcli show server
odacli describe-component

oakcli show env_hw
oakcli show version -detail


--=============================
--ASR INFO
****************************************************************
Warning: ASR Manager should be run as asrmgr for better security.
Doing so will mean changing the default 162 port or configuring
your system to enable asrmgr to access port 162.
****************************************************************



============================
CURRENT VERSIONS
============================
odacli describe-component

System Version
---------------
18.7.0.0.0

System node Name
---------------
pngoda7

Local System Version
---------------
18.7.0.0.0

System node Name
---------------
pngoda8

Local System Version
---------------
18.7.0.0.0

ODA Binary files path:/opt/oracle/dcs/bin

PATCHING DOCUMENTATION
PAGE 54

DR PATCH FLOW
18.7.0.0.0 ==> 18.8.0.0      PATCH ID:30518425  Oracle 19c runs on ODA SW version 19.11 minimum
18.8.0.0   ==> 19.6.0.0
19.6.0.0   ==> 19.10.0.0
19.10.0.0  ==> 19.14.0.0 
19.14.0.0  ==> 19.18.0.0
19.18.0.0  ==> 19.21.0.0
19.21.0.0  ==> 19.22.0.0 RDDMS VERSION LINK:https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=30403662

SRDC - ODA BM/VM Environment: Server / DB Upgrade and Patching (Doc ID 2807061.1)

========================12.1.2.12, 12.2.1.4
PROD PATCH FLOW
https://docs.oracle.com/en/engineered-systems/oracle-database-appliance/18.3/cmtxl/oracle-database-appliance-x7-2-deployment-and-users-guide.pdf
========================
12.2.1.3.0 -> 18.3.0.0   Use CLI approach for this. Then DPR for below 18.3 - 19.20, 19.20 -19.22, 19.22 -> 19.23
18.3.0.0 -> 18.8.0.0
18.8.0.0 -> 19.6.0.0
19.6.0.0 -> 19.10.0.0
19.10.0.0 -> 19.14.0.0
19.14.0.0 -> 19.18.0.0
19.18.0.0 -> 19.22.0.0  RDDMS VERSION LINK:https://updates.oracle.com/Orion/PatchDetails/process_form?patch_num=30403662
19.22.0.0 -> 19.23.0.0

12.2.1.3.0 -> 18.3.0.0 USING PATCHING
18.3 -> 19.20 USING DPR
19.20 -> 19.23 USING PATCHING


--=================
--PATCH STEPS LINKS
--=================

If ODAK Refuses to start, run below command and then try start the oak.
echo non-cluster > /opt/oracle/oak/install/oakdrun
<grid_home>/bin/ocrconfig -showbackup
locate week.ocr
crsctl stop crs -f
./crsctl start crs -excl -nocrs

--DOCUMENTATION LINK: https://docs.oracle.com/en/engineered-systems/oracle-database-appliance/
https://docs.oracle.com/en/engineered-systems/oracle-database-appliance/18.3/cmtxl/patching-oda.html#GUID-60F1D43C-B8CB-4611-B206-0CD1DE5BAD7D

https://blogs.oracle.com/oda/post/oracle-database-19c-support-for-oracle-database-appliance
--PATCH STEP: https://docs.oracle.com/en/engineered-systems/oracle-database-appliance/19.12/cmtxn/patching-oda.html#GUID-0BA1B02A-83AF-4E9F-9568-C9624B32CD8C
https://dbsguru.com/step-by-step-apply-patch-oda-x7-2m-from-18-3-to-18-8/
https://www.dbi-services.com/blog/patching-oda-from-18-3-to-18-8/
https://www.dbi-services.com/blog/patching-oda-from-18-3-to-18-8/
https://dbsguru.com/step-by-step-upgrade-from-18-8-to-19-6-in-oda-x7-2m/
https://www.dbi-services.com/blog/patch-19-14-is-out-for-oda-new-features-and-how-to-apply/
https://www.dbadutra.com/2023/01/how-to-use-data-preserving-reprovisioning-on-oda/

--RESTART DCS AGENT
https://support.oracle.com/epmos/faces/DocumentDisplay?_afrLoop=113626221541965&parent=EXTERNAL_SEARCH&sourceId=HOWTO&id=2447239.1&_afrWindowMode=0&_adf.ctrl-state=18vyf5mcas_4

--CHECK ODA JOBS THAT ARE RUNNING
odacli list-jobs
odacli describe-job -i bbd39bb7-9fb1-49b9-9152-b5dd2d86be00
odacli list-jobs -o '2023-08-10'
odacli list-databases
[root@pngoda7 ~]# odacli list -h
Command usage:
        list:
                list-agentconfig-parameters
                list-auto-logclean-policy
                list-availablepatches
                list-backupconfigs
                list-backupreports
                list-cpucores
                list-databases
                list-dbhomes
                list-dbstorages
                list-dgstorages
                list-featuretracking
                list-jobs
                list-logcleanjobs
                list-logspaceusage
                list-networkinterfaces
                list-networks
                list-nodes
                list-objectstoreswifts
                list-osconfigurations
                list-pendingjobs
                list-prepatchreports
                list-scheduled-executions
                list-scheduledExecutions
                list-schedules


Check ASM CONFIGURATION
/bin/su grid -c ' /opt/oracle/oak/bin/stordiag/asm_script.sh 1 6 ' | /bin/grep -E AFD:.*

ODABR UTILITY
install the utility
/opt/odabr/odabr backup -help
https://support.oracle.com/epmos/faces/DocumentDisplay?_afrLoop=471505341256125&id=2466177.1&_afrWindowMode=0&_adf.ctrl-state=vx83rva0l_4
https://ftp.gnu.org/gnu/libc/


===UNPACK THE BUNDLES==========
/opt/oracle/oak/bin/odaadmcli unpack -package
/opt/oracle/dcs/bin/odacli unpack -package

/opt/oracle/oak/bin/odaadmcli unpack -package p30518425_188000_Linux-x86-64_1of2.zip
/opt/oracle/oak/bin/odacli unpack -package p30518425_188000_Linux-x86-64_1of2.zip

oakcli unpack -package absolute_package_name

===VALIDATE PACKAGE========
18.8.0.0.0	
https://docs.oracle.com/en/engineered-systems/oracle-database-appliance/18.8/cmtxd/patching-oda.html#GUID-DD23722D-2E0D-443A-809D-6FC7DE0EA7CD


https://marcel.vandewaters.nl/oracle/database-appliance/oracle-database-appliance-inventory-and-package-repostitory
	
oakcli update -patch 18.8.0.0.0 --verify
/opt/oracle/oak/bin/odaadmcli update -patch 18.8.0.0.0 --verify
/opt/oracle/dcs/bin/odacli update -patch 18.8.0.0.0 --verify

odacli create-prepatchreport -s -v 18.8.0.0.0	
odacli create-prepatchreport -s -v release_number
/opt/oracle/dcs/bin/odacli create-prepatchreport -s -v 19.7.0.0.0

opatch prereq checkcomponents
odacli create-prepatchreport -s -v 30518425

--============================
ENVIRONMENTAL VARIABLES PATH
--============================
/opt/oracle/oak/pkgrepos/opatch

export PATH=/opt/oracle/oak/onecmd:$PATH
export PATH=/opt/oracle/oak/pkgrepos:$PATH


--======================
--CREATE DATABASE
--======================
odacli create-database -n itms -cl OLTP -dh 93d56e33-e6cd-4164-aa5a-cf1d1a38a4ac -y RAC
odacli create-database -n pngcapp -cl OLTP -dh 93d56e33-e6cd-4164-aa5a-cf1d1a38a4ac -y RAC
odacli delete-database -i 03bab25f-2ad6-4333-9b66-6505cbd4eeb6 -n iconcept

odacli describe-job -i 5be6d59e-0113-4402-abd7-33851dc8a56d --ecr
odacli upgrade-database -i 68198f90-ea95-4533-938e-cf39df855505 -from 42590b55-7845-439b-9b76-589b9e6aaa2f -to 5843b211-4cae-4015-8a49-e8c290574df5

93d56e33-e6cd-4164-aa5a-cf1d1a38a4ac

--================================
--INCREASE LOGICAL VOLUME
--================================
vgs
lvs
lvextend --size +10G /dev/VolGroupSys/LogVolRoot
lvextend --size +10G /dev/mapper/VolGroupSys-LogVolRoot
lvextend --size +8G /dev/mapper/systemvg-tmplv
cat /etc/fstab
xfs_growfs /dev/mapper/systemvg-tmplv
resize2fs /dev/mapper/VolGroupSys-LogVolRoot

--=======================================
--RESOLVING DCSCOMPONENTS UPDATE ISSUE
--=======================================
/opt/oracle/dcs/bin/restartagent.sh
initctl start initdcsagent
/opt/zookeeper/bin/zkServer.sh start
systemctl status initdcsagent

systemctl stop initdcsagent
/opt/zookeeper/bin/zkServer.sh stop

/opt/zookeeper/bin/zkServer.sh start
systemctl start initdcsagent

odaadmcli show ismaster
oakcli restart oak
odaadmcli stop oak

https://community.oracle.com/mosc/discussion/4345498/odacli-update-dcscomponents-v-19-6-0-0-0-hanging-failing
Just a shot in the dark - does "cat /proc/cmdline" show the debug option as being part of the kernel options?

If so, remove the debug option from grub2:

* edit /etc/default/grub and remove "debug" from the GRUB_CMDLINE_LINUX line

* run grub2-mkconfig -o /boot/grub2/grub.cfg (for non-UEFI systems like X5-2/X6-2)

* run grub2-mkconfig -o /boot/efi/EFI/redhat/grub.cfg (for UEFI systems like X7-2/X8-2)

* reboot


odacli create-prepatchreport -v 19.6.0.0.0 -os


Custom RPMs installed. Please check files 
/root/oda-upgrade/rpms-added-from-ThirdParty and /or/root/oda-upgrade/rpms-added-from-Oracle.

/root/odaUpgrade2024-05-17_01-19-04.0927.log


odacli update-server-postcheck -v 19.6.0.0.0

odacli update-dcsadmin -v 19.6.0.0.0


PNGCAPP1_DR_VIP =
  (DESCRIPTION =
    (ADDRESS_LIST =
      (ADDRESS = (PROTOCOL = TCP)(HOST = pngoda78-vip.ng.sbicdirectory.com)(PORT = 1521))
    )
    (CONNECT_DATA =
      (SERVICE_NAME = pngcapp.ng.sbicdirectory.com)
    )
  )



PNGCAPP =
  (DESCRIPTION =
    (ADDRESS_LIST =
      (ADDRESS = (PROTOCOL = TCP)(HOST = pngoda56-vip.ng.sbicdirectory.com)(PORT = 1521))
    )
    (CONNECT_DATA =
      (SERVICE_NAME = pngcapp.ng.sbicdirectory.com)
    )
  )
  
PNGCAPP2_VIP=
   (DESCRIPTION=
      (ADDRESS_LIST=
	    (ADDRESS=(PROTOCOL=TCP)(HOST=pngoda56-vip.ng.sbicdirectory.com)(PORT=1521))
	  )	
		(CONNECT_DATA=
		   (SERVICE_NAME=pngcapp.ng.sbicdirectory.com)(INSTANCE_NAME=pngcapp2)
		)
	)




 (DESCRIPTION=(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST=pngoda56-vip.ng.sbicdirectory.com)(PORT=1521)))(CONNECT_DATA=(SERVICE_NAME=pngcapp.ng.sbicdirectory.com)(INSTANCE_NAME=pngcapp2)(CID=(PROGRAM=oracle)(HOST=pngoda7)(USER=oracle))))



--==========================
--BASIC COMMANDS
--==========================

  860  cp p6880880_122010_Linux-x86-64.zip  /u01/app/12.2.0.1/grid
  861  cd /u01/app/12.2.0.1/grid
  862  ls -lrt
  863  unzip -q p6880880_122010_Linux-x86-64.zip
  864  ls -lrt
  865  chown -R oracle:oinstall OPatch/
  866  cd OPatch
  867  ls -lrt
  868  ./opatch version
  869  chown -R grid:oinstall OPatch/
  870  cd ..
  871  chown -R grid:oinstall OPatch/
  872  ls -lrt
  873  rm -rvf p6880880_122010_Linux-x86-64.zip
  874  cd OPatch
  875  ls -lrt
  876  ./opatch version
  877  cd /flashback/
  878  ls -lrt
  879  chown -R grid:oinstall 35745595/
  880  ls -lrt
  881  cd 35745595
  882  ls
  883  cd ..
  884  clear
  885  ls -lrt
  886  clear
  887  ls
  888  cd 35745595
  889  cd /u01/app/12.2.0.1/grid
  890  ls
  891  exit
  892  cd /u01/app/oracle/product/12.2.0.1/dbhome_2
  893  clear
  894  ls -lrt
  895  chown -R oracle:oinstall OPatch/
  896  ls -lrt
  897  cd OPatch
  898  ls -lrt
  899  ./opatch version
  900  clear
  901  cd /flashback/expdp/
  902  ls -lrt
  903  clear
  904  ls -lrt
  905  cd ..
  906  ls -lrt
  907  cat ~/.ssh/authorized_keys
  908  ssh root@pngoda6
  909  cd /flashback/
  910  ls -trl
  911  cp p35745595_122010_Linux-x86-64.zip /u01/app/oracle/product/12.2.0.1/dbhome_2/OPatch/
  912  df -h
  913  cp p35745595_122010_Linux-x86-64.zip /u01/app/oracle/product/12.2.0.1/dbhome_2/
  914  cd /u01/app/oracle/product/12.2.0.1/dbhome_2/
  915  ls
  916  cd OPatch/
  917  rm p35745595_122010_Linux-x86-64.zip
  918  cd ..
  919  mv OPatch OPatch_backup
  920  pwd
  921  cd /flashback/
  922  ls
  923  cp p6880880_190000_LINUX\ \(1\).zip /u01/app/oracle/product/12.2.0.1/dbhome_2/
  924  cd /u01/app/oracle/product/12.2.0.1/dbhome_2/
  925  ls
  926  rm p35745595_122010_Linux-x86-64.zip
  927  ls ltr
  928  ls
  929  unzip p6880880_190000_LINUX\ \(1\).zip
  930  ls -tlr
  931  pwd
  932  chown R oracle:oinstall OPatch
  933  chown -R oracle:oinstall OPatch
  934  ls -trl
  935  cd OPatch
  936  opatch version
  937  ./opatch version
  938  ./Opatch version
  939  ./Opatch -version
  940  cat /etc//os-release
  941  cd ..
  942  ls
  943  rm p6880880_190000_LINUX\ \(1\).zip
  944  ls -trl
  945  ls
  946  mv OPatch OPatch_notcom
  947  pwd
  948  cd /flashback/
  949  ls
  950  cp p6880880_122010_Linux-x86-64.zip /u01/app/oracle/product/12.2.0.1/dbhome_2/
  951  cd /u01/app/oracle/product/12.2.0.1/dbhome_2
  952  ls -tl
  953  ls
  954  unzip p6880880_122010_Linux-x86-64.zip
  955  ls
  956  cd OPatch
  957  ./Opatch version
  958  ./opatch version
  959  ls -trl
  960  cd /u01/app/grid/
  961  ls
  962  ls -trl
  963  cd admin
  964  ls
  965  cd /flashback/
  966  ls
  967  ls -trl
  968  su - grid
  969  cd /u01/app/oracle/product/12.2.0.1/dbhome_2/OPatch
  970  ./opatchauto apply /flashback/35745595 -oh /u01/app/oracle/product/12.2.0.1/dbhome_2
  971  history
  972  odaadmcli show disk
  973  exit
  974  clear
  975  odaadmcli show disk
  976  clear
  977  odaadmcli manage diagcollect
  978  cd /opt/oracle/oak/onecmd/oakdiag/
  979  ls

  386  odaadmcli show server
  387  odacli -h
  388  odacli list-dbhomes
  389  exit
  390  odaadmcli show disk
  391  exit
  392  odaadmcli show server
  393  odaadmcli restart oak
  394  odaadmcli show server

/opt/asrmanager/util/check_asr_status.sh
https://www.pythian.com/blog/technical-track/oracle-exadata-asr-general-troubleshooting
--=========================================
--STEPS
--=========================================
Step 1: Validate the dcs-agent and all other components are up to date with the latest version.
# odacli describe-component
# odacli list-dbhomes
/opt/asrmanager/bin/asr list_asset

Step 2: If you try to clean the current version DB & GI patch files you will receive the below error.
# odacli cleanup-patchrepo -comp db,gi -v 18.8.0.0.0
odacli cleanup-patchrepo -comp db,gi -v 121.171017


Step 3: Install odabr : odabr is required to roll back failed OS patching, odabr will create an LVM-snapshot of (/ (root) /opt /u01) before begin of OS patch. Follow this metalink document  ODA (Oracle Database Appliance): ODABR a System Backup/Restore Utility (Doc ID 2466177.1). odabr is required for the patching to 19.6. odabr is a tool to backup and recover an ODA.

Step 4: Download patches 30403662 & 31010832 and transfers them to ODA Server using the available option. Click on the below patch id to download patches along with reference images to choose patches for the specific platform.


Step 5: Unzip the patches.
# ls -ltr p*
# ls -ltr oda*


Step 6: Update patch repositories with patch files using odacli update-repository command.
# odacli update-repository -f /kvm_reps/oda-sm-19.6.0.0.0-200420-server1of4.zip,/kvm_reps/oda-sm-19.6.0.0.0-200420-server2of4.zip,/kvm_reps/oda-sm-19.6.0.0.0-200420-server3of4.zip,/kvm_reps/oda-sm-19.6.0.0.0-200420-server4of4.zip



NOTE: command odacli update-repository, the server software is copied to both nodes.

Step 7: Check the status of the job with odacli describe-job and it should be a successful update.
# odacli describe-job -i job_ID


Step 8: Once the update repository job is finished check if 19.6 version is showing as “Available Version”.
# odacli describe-component


Step 9: Update dcsagent. This command updates the DCS agent on both nodes.
# odacli update-dcsagent -v 19.6.0.0.0


Step 10: Check the status of the job, it should be successful.
# odcli describe-job -i <job id>



Step 11: Once the job is finish verify dcsgent is showing 19.6 version.
# odacli describe-component



Step 12: Disable schedule job from ODA Server
# odacli list-schedules
# odacli update-schedule -d -i <schedule ID>
# odacli list-schedules



Step 13: Odabr expect 190 GB of free space in your PV (Physical Volume), If you have less space in your PV then you can create a manual snapshot before starting of OS patch using the below command.
# pvs



# /opt/odabr/odabr backup -snap -osize 40 -resize 20 -usize 80 Here options rsize is root , usize is u01 and osize is opt. So with below command we are creating snapshot of all three required mountpoint.



Step 14: Verify snapshot info.
# /opt/odabr/odabr infosnap



Step 15: Create the prepatch report for the operating system (OS) upgrade. This command will generate a report for both nodes.
# odacli create-prepatchreport -v 19.6.0.0.0 -os



Step 16: Check the status of prepatch report.
# odacli describe-job -i <precheck_job_ID>




As you can see above, we have failures in the prepatch report.

Step 17: Review the status of the prepatch report. Use describe-prepatchreport to identify the reason behind failure, Below error was expected as odabr expect to create snapshots by itself during prepatch steps execution. And we have taken manual snapshot due to less space in PV, except failure related to odabr other checks are successful
# odacli describe-prepatchreport -i <precheck_job_ID>



Step 18: Using putty connect to ILOM IP with root. Once connect to the ILOM and log in as root user.
start /SP/console



Step 19: Start OS upgrade with the below command, Please note I am using –force option because of failure in OS prepatch report.
# odacli update-server -v 19.6.0.0.0 -c os –local –force



Step 20 You can monitor the OS upgrade using file /root/odaUpgrade2020-12-14_17-42-06.0468.log (logfile generated at the time of execution), Server will reboot and start the OS upgrade steps which take approx 30-60 minutes for each node and timing completely depends on the hardware platform. Upon successful upgrade, the node will reboot automatically.
# tail -333f <log_file.log>



If everything went fine you will be able to see the OEL7.7 after login.



Step 21: Execute postcheck after OS upgrade, A you can see in below screen, my Clusterware showing FAILED, Wait some time to let Clusterware process to start all services.
# odacli update-server-postcheck -v 19.6.0.0.0



Step 22: Delete snapshot in-between Clusterware services are being up.
# /opt/odabr/odabr delsnap



Step 23: Validate again postcheck status and now all successful.
# odacli update-server-postcheck -v 19.6.0.0.0



Step 24: Now we are good to go for the next step of Server update.
Update DCS admin:
# odacli update-dcsadmin -v 19.6.0.0.0



Update DCS Components:
# odacli update-dcscomponents -v 19.6.0.0.0



Before proceeding with the server patch generate prepatch report to validate if everything is fine and we are good to go ahead with the server patch.

Step 25: Create the prepatch report for the operating system (OS) upgrade. This command will generate a report for both nodes.
# odacli create-prepatchreport -s -v 19.6.0.0.0



Step 26: Describe jobid to check status. As you can see Failure in Statuscheck is failed.
# odacli describe-job -i <job_id>



Step 27: Describe prepatch report to review cause for failure, Check is failed for ORACHK which can be ignored.
# odacli describe-prepatchreport -i



Step 28: Start the Server patch with the below command.
# odacli update-server -v 19.6.0.0.0



Step 29: You can tail the file dcs-agent log for monitoring of the patch process.
# /opt/oracle/dcs/log/dcs-agent.log



Step 30: Validate server patch update is successful.
# odacli describe-job -i <job_ID>



Step 31: Upon completion of successful Server patch, validate all components
# odacli describe-component



Step 32: Update storage components.
# odacli update-storage -v 19.6.0.0.0



Step 33: Validate storage update is successful.
# odacli describe-job -i <job_ID>



Step 34: Now you can delete files related to components of version 18.8 since it’s successfully upgraded to version 19.6.
# odacli cleanup-patchrepo -comp db,gi -v 18.8.0.0.0



Step 35: Update repository for RDBMS 19c Clone.
# odacli update-repository -f odacli-dcs-19.6.0.0.0-200326-DB-19.6.0.0.0.zip



Step 36: Validate RDBMS update is successful.
# odacli describe-job -i <job_ID>


/opt/oracle/dcs/bin/odacli update-repository -f /tmp/odasm-18.8.0.0.0-200124-server1of2.zip,/tmp/oda-sm-18.8.0.0.0-200124-
server2of2.zip


odacli update-repository -f /flashback/ODA_PATCHES/18.8.0.0/oda-sm-18.8.0.0.0-200209-server1of2.zip,/flashback/ODA_PATCHES/18.8.0.0/oda-sm-18.8.0.0.0-200209-server2of2.zip


odacli describe-job -i 54efe028-2784-4c20-bb51-8b72519fde03


odacli update-dcsagent -v 18.8.0.0.0


odacli update-dcsadmin -v 18.8.0.0.0


odacli update-dcscomponents -v 18.8.0.0.0


odacli describe-job -i job_ID

odacli update-storage -v 18.8.0.0.0 --rolling

0,10,20,30,40,50 * * * * find /u01/app/grid/diag/tnslsnr/pngoda8/listener_scan1/alert/*log_*.xml -exec rm -f {} \;



odacli create-prepatchreport --dbhome --dbhomeid 74854905-87e8-4e2c-bd87-2bb1627d5194 -v 18.8.0.0.0

odacli update-dbhome --dbhomeid 74854905-87e8-4e2c-bd87-2bb1627d5194 -v 18.8.0.0.0

odacli update-repository -f /flashback/ODA_PATCHES/19.6.0.0/oda-sm-19.6.0.0.0-200420-server1of4.zip,/flashback/ODA_PATCHES/19.6.0.0/oda-sm-19.6.0.0.0-200420-server2of4.zip,/flashback/ODA_PATCHES/19.6.0.0/oda-sm-19.6.0.0.0-200420-server3of4.zip,/flashback/ODA_PATCHES/19.6.0.0/oda-sm-19.6.0.0.0-200420-server4of4.zip,/flashback/ODA_PATCHES/19.6.0.0/oda-sm-19.6.0.1.0-200820-server.zip


odacli updaterepository -f /tmp/oda-sm-19.6.0.0.0-200420-server1of4.zip,/tmp/odasm-19.6.0.0.0-200420-server2of4.zip,/tmp/oda-sm-19.6.0.0.0-200420-
server3of4.zip,/tmp/oda-sm-19.6.0.0.0-200420-server4of4.zip,/tmp/
oda-sm-19.6.0.1.0-200820-server.zip


ssh -l root 10.234.181.99
/usr/sbin
ipmitool sunoem cli "show /SP/console"


odabr backup -snap -destination /mnt/nfs

 /opt/odabr/odabr backup -snap -osize 40 -resize 20 -usize 80 -destination /flashback/ODA_PATCHES/LVM

 /opt/odabr/odabr backup -snap -osize 40 -resize 20 -usize 80

odacli updaterepository -f

/root/oda-upgrade/rpms-added-from-ThirdParty and /or/root/oda-upgrade/rpms-added-from-Oracle.

odacli update-server -c os --local
odacli update-server -v 19.6.0.0.0 -c os –local –force
odacli update-server -c os --local --force -v 19.6.0.0.0


odacli update-dcsagent -v 19.6.0.1.0



You have new mail in /var/spool/mail/root
[root@pngoda8 ~]# odacli list-schedules

ID                                       Name                      Description                                        CronExpression                 Disabled
---------------------------------------- ------------------------- -------------------------------------------------- ------------------------------ --------
157688aa-7b05-4b5b-92f4-c9c73f781219     metastore maintenance     internal metastore maintenance                     0 0 0 1/1 * ? *                true
8bdc9c73-98ac-481c-8f2a-60bd6c8de261     AgentState metastore cleanup internal agentstateentry metastore maintenance     0 0 0 1/1 * ? *                false
bcc5fcd0-9933-4899-9128-29b69e5db43d     Big File Upload Cleanup   clean up expired big file uploads.                 0 0 1 ? * SUN *                false
c1d57b8c-6790-460f-b239-63ed13a045fe     bom maintenance           bom reports generation                             0 0 1 ? * SUN *                false
da44449c-e6b7-477d-970e-2309975e7190     feature_tracking_job      Feature tracking job                               0 0 20 ? * WED *               false
80b6983c-4532-4ea0-9524-626908b226a8     Log files Cleanup         Auto log file purge bases on policy                0 0 3 1/1 * ? *                false
[root@pngoda8 ~]#




If you are running KVM (Kernel Virual Machine)and after OS upgrade to OEL 7, VM start command with fail with below error then click here for solution KVM failed to start after ODA upgrade from 18.8 to 19.6.


error: Failed to start domain vm_adhoc
error: Cannot check QEMU binary /usr/libexec/qemu-kvm: No such file or directory


PNGODA8 /ETC/ORATAB
pngrpt2:/u01/app/oracle/product/12.2.0.1/dbhome_1:N
pngrdbox2:/u01/app/oracle/product/12.1.0.2/dbhome_1:N           # line added by Agent
cognosrp2:/u01/app/oracle/product/12.2.0.1/dbhome_1:N
itms2:/u01/app/oracle/product/12.2.0.1/dbhome_1:N
pngcdb2:/u01/app/oracle/product/12.2.0.1/dbhome_1:N
pngcfm2:/u01/app/oracle/product/12.1.0.2/dbhome_1:N             # line added by Agent
pngitms2:/u01/app/oracle/product/12.2.0.1/dbhome_1:N
pngitms:/u01/app/oracle/product/12.2.0.1/dbhome_1:N
pngrdbox:/u01/app/oracle/product/12.1.0.2/dbhome_1:N            # line added by Agent
pngcapp2:/u01/app/oracle/product/12.2.0.1/dbhome_1:N
databrk2:/u01/app/oracle/product/12.1.0.2/dbhome_1:N            # line added by Agent
pngcfrm:/u01/app/oracle/product/12.2.0.1/dbhome_1:N
pngcfrm2:/u01/app/oracle/product/12.2.0.1/dbhome_1:N
databrk:/u01/app/oracle/product/12.1.0.2/dbhome_1:N             # line added by Agent
dummydb:/u01/app/oracle/product/12.1.0.2/dbhome_1:N             # line added by Agent

PNGODA7 /ETC/ORATAB
-MGMTDB:/u01/app/12.2.0.1/grid:N
pngrdbox1:/u01/app/oracle/product/12.1.0.2/dbhome_1:N           # line added by Agent
pngrpt1:/u01/app/oracle/product/12.2.0.1/dbhome_1:N
itms1:/u01/app/oracle/product/12.2.0.1/dbhome_1:N
cognosrp1:/u01/app/oracle/product/12.2.0.1/dbhome_1:N
pngcdb1:/u01/app/oracle/product/12.2.0.1/dbhome_1:N
pngcfm1:/u01/app/oracle/product/12.1.0.2/dbhome_1:N             # line added by Agent
pngitms1:/u01/app/oracle/product/12.2.0.1/dbhome_1:N
pngitms:/u01/app/oracle/product/12.2.0.1/dbhome_1:N
pngrdbox:/u01/app/oracle/product/12.1.0.2/dbhome_1:N            # line added by Agent
pngcog:/u01/app/oracle/product/12.2.0.1/dbhome_1:N
-MGMTDB:/u01/app/18.0.0.0/grid:N
iconcept1:/u01/app/oracle/product/12.2.0.1/dbhome_1:N
dummydb_1:/u01/app/oracle/product/12.1.0.2/dbhome_1:N           # line added by Agent
pngcapp1:/u01/app/oracle/product/12.2.0.1/dbhome_1:N
databrk1:/u01/app/oracle/product/12.1.0.2/dbhome_1:N            # line added by Agent
pngcfrm:/u01/app/oracle/product/12.2.0.1/dbhome_1:N
pngcfrm1:/u01/app/oracle/product/12.2.0.1/dbhome_1:N
ungcfm:/u01/app/oracle/product/12.2.0.1/dbhome_1:N              # line added by Agent
databrk:/u01/app/oracle/product/12.1.0.2/dbhome_1:N             # line added by Agent
dummydb:/u01/app/oracle/product/12.1.0.2/dbhome_1:N             # line added by Agent

--Backup all running databases
itms1








[oracle@pngoda7 ~]$ ps -ef | grep pmon
oracle   38241     1  0 Apr20 ?        00:02:47 ora_pmon_pngcfm1
grid     41165     1  0 Apr20 ?        00:01:55 asm_pmon_+ASM1
grid     47762     1  0 Apr20 ?        00:01:38 apx_pmon_+APX1
oracle   48316     1  0 Apr20 ?        00:01:30 ora_pmon_pngcapp1
oracle   49782 49185  0 19:43 pts/1    00:00:00 grep pmon
oracle   57244     1  0 Apr20 ?        00:01:39 ora_pmon_iconcept1
[oracle@pngoda7 ~]$

[oracle@pngoda7 ~]$ ps -ef | grep tns
root       512     2  0 Apr20 ?        00:00:00 [netns]
grid     47026     1  0 Apr20 ?        00:08:42 /u01/app/18.0.0.0/grid/bin/tnslsnr ASMNET1LSNR_ASM -no_crs_notify -inherit
grid     47327     1  0 Apr20 ?        00:52:01 /u01/app/18.0.0.0/grid/bin/tnslsnr LISTENER -no_crs_notify -inherit
grid     47336     1  0 Apr20 ?        00:00:32 /u01/app/18.0.0.0/grid/bin/tnslsnr MGMTLSNR -no_crs_notify -inherit
grid     47363     1  0 Apr20 ?        00:06:57 /u01/app/18.0.0.0/grid/bin/tnslsnr LISTENER_SCAN3 -no_crs_notify -inherit
grid     47376     1  0 Apr20 ?        00:07:21 /u01/app/18.0.0.0/grid/bin/tnslsnr LISTENER_SCAN2 -no_crs_notify -inherit
oracle   50357 49185  0 19:44 pts/1    00:00:00 grep tns
[oracle@pngoda7 ~]$


[oracle@pngoda7 ~]$ ps -ef | grep d.bin
root     26433     1  0 Apr20 ?        02:50:21 /u01/app/18.0.0.0/grid/bin/ohasd.bin reboot
root     29081     1  0 Apr20 ?        00:51:54 /u01/app/18.0.0.0/grid/bin/orarootagent.bin
grid     31621     1  0 Apr20 ?        01:38:07 /u01/app/18.0.0.0/grid/bin/oraagent.bin
grid     31936     1  0 Apr20 ?        00:21:17 /u01/app/18.0.0.0/grid/bin/mdnsd.bin
grid     31938     1  0 Apr20 ?        01:11:25 /u01/app/18.0.0.0/grid/bin/evmd.bin
grid     32598     1  0 Apr20 ?        00:27:26 /u01/app/18.0.0.0/grid/bin/gpnpd.bin
grid     32662 31938  0 Apr20 ?        00:21:03 /u01/app/18.0.0.0/grid/bin/evmlogger.bin -o /u01/app/18.0.0.0/grid/log/[HOSTNAME]/evmd/evmlogger.info -l /u01/app/18.0.0.0/grid/log/[HOSTNAME]/evmd/evmlogger.log
grid     32742     1  0 Apr20 ?        01:14:48 /u01/app/18.0.0.0/grid/bin/gipcd.bin
root     33287     1  0 Apr20 ?        00:33:38 /u01/app/18.0.0.0/grid/bin/cssdmonitor
root     36430     1  0 Apr20 ?        00:33:38 /u01/app/18.0.0.0/grid/bin/cssdagent
root     36435     1  3 Apr20 ?        20:28:35 /u01/app/18.0.0.0/grid/bin/osysmond.bin
grid     36558     1  1 Apr20 ?        07:18:21 /u01/app/18.0.0.0/grid/bin/ocssd.bin
root     40123     1  0 Apr20 ?        01:19:53 /u01/app/18.0.0.0/grid/bin/octssd.bin reboot
root     40338     1  0 Apr20 ?        03:37:22 /u01/app/18.0.0.0/grid/bin/ologgerd -M
root     42964     1  0 Apr20 ?        05:15:52 /u01/app/18.0.0.0/grid/bin/crsd.bin reboot
grid     46137     1  0 Apr20 ?        03:46:27 /u01/app/18.0.0.0/grid/bin/oraagent.bin
root     46151     1  0 Apr20 ?        04:32:35 /u01/app/18.0.0.0/grid/bin/orarootagent.bin
grid     47026     1  0 Apr20 ?        00:08:42 /u01/app/18.0.0.0/grid/bin/tnslsnr ASMNET1LSNR_ASM -no_crs_notify -inherit
grid     47033     1  0 Apr20 ?        00:28:11 /u01/app/18.0.0.0/grid/bin/scriptagent.bin
grid     47327     1  0 Apr20 ?        00:52:01 /u01/app/18.0.0.0/grid/bin/tnslsnr LISTENER -no_crs_notify -inherit
grid     47336     1  0 Apr20 ?        00:00:32 /u01/app/18.0.0.0/grid/bin/tnslsnr MGMTLSNR -no_crs_notify -inherit
grid     47363     1  0 Apr20 ?        00:06:57 /u01/app/18.0.0.0/grid/bin/tnslsnr LISTENER_SCAN3 -no_crs_notify -inherit
grid     47376     1  0 Apr20 ?        00:07:21 /u01/app/18.0.0.0/grid/bin/tnslsnr LISTENER_SCAN2 -no_crs_notify -inherit
oracle   50967 49185  0 19:44 pts/1    00:00:00 grep d.bin
root     63773 36435  0 Apr20 ?        00:21:56 /u01/app/18.0.0.0/grid/perl/bin/perl /u01/app/18.0.0.0/grid/bin/diagsnap.pl start
[oracle@pngoda7 ~]$



[root@pngoda8 bin]# ipmitool sunoem cli
Connected. Use ^D to exit.
->
->
-> cd /SP/network/
/SP/network

-> ls

 /SP/network
    Targets:
        interconnect
        ipv6
        test

    Properties:
        commitpending = (Cannot show property)
        dhcp_clientid = none
        dhcp_server_ip = none
        ipaddress = 10.234.181.99
        ipdiscovery = static
        ipgateway = 10.234.181.65
        ipnetmask = 255.255.255.192
        link_state = up
        macaddress = 00:10:E0:DD:B2:24
        managementport = MGMT
        outofbandmacaddress = 00:10:E0:DD:B2:24
        pendingipaddress = 10.234.181.99
        pendingipdiscovery = static
        pendingipgateway = 10.234.181.65
        pendingipnetmask = 255.255.255.192
        pendingmanagementport = MGMT
        pendingvlan_id = (none)
        sidebandmacaddress = 00:10:E0:DD:B2:25
        state = enabled
        vlan_id = (none)

    Commands:
        cd
        set
        show

-> cd /SP/users/
/SP/users

-> ls

 /SP/users
    Targets:
        root
        A184759

    Properties:

    Commands:
        cd
        create
        delete
        set
        show

-> cd root
/SP/users/root

-> ls

 /SP/users/root
    Targets:
        ssh

    Properties:
        role = aucro
        password = *****
        locked = false

    Commands:
        cd
        set
        show

-> cd /SP/services/
/SP/services

-> ls

 /SP/services
    Targets:
        device_monitor
        fips
        ipmi
        kvms
        servicetag
        snmp
        ssh
        sso
        web

    Properties:

    Commands:
        cd
        show

-> cd snmp/
/SP/services/snmp

-> ls

 /SP/services/snmp
    Targets:
        mibs
        users

    Properties:
        engineid = pngoda8
        port = 161
        servicestate = enabled
        v3 = enabled

    Commands:
        cd
        set
        show

-> pwd
Current default target: /SP/services/snmp

-> ls

 /SP/services/snmp
    Targets:
        mibs
        users

    Properties:
        engineid = pngoda8
        port = 161
        servicestate = enabled
        v3 = enabled

    Commands:
        cd
        set
        show
ilom root user password:welcome1




====FAIL OVER PLAN======
Stop app services in PROD
Take full backup, spfile,control file etc

Before converting to snapshot standby/switch over

1. Run alter system set cluster_database=FALSE scope=spfile;
2. SHUTDOWN and startup mount;
3. Convert to snapshot manually,
4. Open in upgrade mode
5. Run the upgrade script on snapshot standby
6. Startup
8. Confirm standby redo logs.
9. Convert back to physical standby
10. Convert to snaptshot standby again using broker and viaz visa
11. Run alter system set cluster_database=TRUE scope=spfile;

PNGOEM002V\WintelAssist


ALTER SYSTEM SWITCH LOGFILE;

/u01/app/odaorahome/oracle/product/19.0.0.0/dbhome_1/cfgtoollogs/dngcapp/upgrade20240727013102

@<DB_HOME>/rdbms/admin/utlrp.sql


================TNS AND GRID INFO======================

[oracle@pngoda5 ~]$ ps -ef | grep tns
root       512     2  0  2023 ?        00:00:00 [netns]
grid      5406     1  0 May18 ?        00:21:21 /u01/app/12.2.0.1/grid/bin/tnslsnr LISTENER_SCAN1 -no_crs_notify -inherit
grid     20755     1  0  2023 ?        01:49:07 /u01/app/12.2.0.1/grid/bin/tnslsnr ASMNET2LSNR_ASM -no_crs_notify -inherit
grid     20759     1  0  2023 ?        01:50:16 /u01/app/12.2.0.1/grid/bin/tnslsnr ASMNET1LSNR_ASM -no_crs_notify -inherit
oracle   23052 51836  0 14:23 pts/1    00:00:00 grep tns
grid     36951     1  0 Jul17 ?        00:05:51 /u01/app/12.2.0.1/grid/bin/tnslsnr LISTENER -inherit
grid     83410     1  0  2023 ?        00:22:44 /u01/app/12.2.0.1/grid/bin/tnslsnr LISTENER_SCAN3 -inherit
grid     83932     1  0  2023 ?        00:22:40 /u01/app/12.2.0.1/grid/bin/tnslsnr LISTENER_SCAN2 -inherit
grid     86721     1  0  2023 ?        00:03:26 /u01/app/12.2.0.1/grid/bin/tnslsnr MGMTLSNR -inherit
[oracle@pngoda5 ~]$


[oracle@pngoda5 ~]$ ps -ef | grep d.bin
grid      4852     1  0 May18 ?        01:33:17 /u01/app/12.2.0.1/grid/bin/scriptagent.bin
grid      5406     1  0 May18 ?        00:21:21 /u01/app/12.2.0.1/grid/bin/tnslsnr LISTENER_SCAN1 -no_crs_notify -inherit
root     12557     1  0  2023 ?        17:24:55 /u01/app/12.2.0.1/grid/bin/ohasd.bin reboot
root     14636     1  0  2023 ?        19:16:15 /u01/app/12.2.0.1/grid/bin/orarootagent.bin
grid     14892     1  0  2023 ?        16:27:44 /u01/app/12.2.0.1/grid/bin/oraagent.bin
grid     14913     1  0  2023 ?        04:58:16 /u01/app/12.2.0.1/grid/bin/mdnsd.bin
grid     14916     1  0  2023 ?        1-00:28:08 /u01/app/12.2.0.1/grid/bin/evmd.bin
grid     14949     1  0  2023 ?        06:11:20 /u01/app/12.2.0.1/grid/bin/gpnpd.bin
grid     14995 14916  0  2023 ?        04:48:44 /u01/app/12.2.0.1/grid/bin/evmlogger.bin -o /u01/app/12.2.0.1/grid/log/[HOSTNAME]/evmd/evmlogger.info -l /u01/app/12.2.0.1/grid/log/[HOSTNAME]/evmd/evmlogger.log
grid     15008     1  0  2023 ?        15:56:31 /u01/app/12.2.0.1/grid/bin/gipcd.bin
root     15185     1  0  2023 ?        07:25:45 /u01/app/12.2.0.1/grid/bin/cssdmonitor
root     15651     1  0  2023 ?        07:48:54 /u01/app/12.2.0.1/grid/bin/cssdagent
grid     15666     1  0  2023 ?        1-18:04:54 /u01/app/12.2.0.1/grid/bin/ocssd.bin
oracle   17596     1  0 Feb21 ?        04:56:04 /u01/app/12.2.0.1/grid/bin/oraagent.bin
root     18320     1  0  2023 ?        1-05:13:29 /u01/app/12.2.0.1/grid/bin/octssd.bin reboot
root     19591     1  2  2023 ?        8-01:32:56 /u01/app/12.2.0.1/grid/bin/osysmond.bin
root     19620     1  0  2023 ?        1-08:11:05 /u01/app/12.2.0.1/grid/bin/crsd.bin reboot
root     19902     1  0  2023 ?        2-03:14:52 /u01/app/12.2.0.1/grid/bin/orarootagent.bin
grid     20729     1  0  2023 ?        3-00:36:48 /u01/app/12.2.0.1/grid/bin/oraagent.bin
grid     20755     1  0  2023 ?        01:49:07 /u01/app/12.2.0.1/grid/bin/tnslsnr ASMNET2LSNR_ASM -no_crs_notify -inherit
grid     20759     1  0  2023 ?        01:50:16 /u01/app/12.2.0.1/grid/bin/tnslsnr ASMNET1LSNR_ASM -no_crs_notify -inherit
oracle   25318 51836  0 14:24 pts/1    00:00:00 grep d.bin
root     36600 19591  0  2023 ?        04:17:22 /u01/app/12.2.0.1/grid/perl/bin/perl /u01/app/12.2.0.1/grid/bin/diagsnap.pl start
grid     36951     1  0 Jul17 ?        00:05:51 /u01/app/12.2.0.1/grid/bin/tnslsnr LISTENER -inherit
grid     83410     1  0  2023 ?        00:22:44 /u01/app/12.2.0.1/grid/bin/tnslsnr LISTENER_SCAN3 -inherit
grid     83932     1  0  2023 ?        00:22:40 /u01/app/12.2.0.1/grid/bin/tnslsnr LISTENER_SCAN2 -inherit
grid     86721     1  0  2023 ?        00:03:26 /u01/app/12.2.0.1/grid/bin/tnslsnr MGMTLSNR -inherit




[oracle@pngoda5 ~]$ ps -ef | grep pmon
grid       464     1  0 May18 ?        00:05:16 mdb_pmon_-MGMTDB
grid     25607     1  0  2023 ?        00:25:52 asm_pmon_+ASM1
oracle   27559 51836  0 14:24 pts/1    00:00:00 grep pmon
grid     28966     1  0  2023 ?        00:20:11 apx_pmon_+APX1
oracle   49799     1  0 12:58 ?        00:00:00 ora_pmon_pngcfrm1
oracle   50574     1  0 Mar31 ?        00:08:14 ora_pmon_iconhist1
oracle   53952     1  0 Feb21 ?        00:26:04 ora_pmon_pngrdbox1
oracle   56887     1  0 Mar31 ?        00:09:25 ora_pmon_pngitms1
oracle   63257     1  0 Mar31 ?        00:08:26 ora_pmon_pngsfdm1



================
ERROR 1
================

Check custom filesystems       Failed   DCS-10001:Internal error encountered:  Please check dcs-agent logs
                                        Mount owners not found for filesystem
                                        device: /dev/asm/bkpupacfs-126.

For below error, move the mentioned file /flashback/DPR
DCS-10001:Internal error encountered:  Please check dcs-agent logs Mount owners not found for filesystem device: /dev/asm/bkpupacfs-126.

[root@pngoda5 ~]# ls -lrt /dev/asm/bkpupacfs-126_bkp
brwxrwx--- 1 root asmadmin 250, 64515 Aug 22 21:11 /dev/asm/bkpupacfs-126_bkp
[root@pngoda5 ~]#

[root@pngoda6 asm]# ls -lrt /dev/asm/bkpupacfs-126_bkp
brwxrwx--- 1 root asmadmin 250, 64515 Aug 22 21:11 /dev/asm/bkpupacfs-126_bkp
You have new mail in /var/spool/mail/root
[root@pngoda6 asm]#

[root@pngoda6 ~]# cat /opt/oracle/dcs/log/dcs-agent.log | grep '/dev/asm/bkpupacfs-126'
Volume device: /dev/asm/bkpupacfs-126
Canonical volume device: /dev/asm/bkpupacfs-126
2024-08-22 22:50:02,166 DEBUG [pool-4-dcsrpcworker_thread-1 : JobId=777cd963-879c-4ce8-9277-33e253a0b4c9] [] c.o.d.a.d.u.DetachUtils: Found filesystems: [/dev/asm/acfsclone-126, /dev/asm/bkpupacfs-126, /dev/asm/commonstore-126, /dev/asm/oggacfs-126]
 /dev/asm/bkpupacfs-126]'
 /dev/asm/bkpupacfs-126]'
Volume device: /dev/asm/bkpupacfs-126
Canonical volume device: /dev/asm/bkpupacfs-126
com.oracle.dcs.commons.exception.DcsException: DCS-10001:Internal error encountered: Mount owners not found for filesystem device: /dev/asm/bkpupacfs-126.
com.oracle.dcs.commons.exception.DcsException: DCS-10001:Internal error encountered: Mount owners not found for filesystem device: /dev/asm/bkpupacfs-126.
[root@pngoda6 ~]#



================
ERROR 2
================
Validate Database Home Version Failed   Version '12.1.0.2.180116' for          Please update the databases running
                                        database home 'OraDB12102_home1' is    from this home to the minimum
                                        lower than minimum supported version   supported version or higher and
                                        '12.1.0.2.220719'                      delete this database home using the
                                                                               'odacli delete-dbhome' command

Download RDBMS Patch 23494992, Copy to /flashback/ODA_PATCHES/19.6.0.0/,
unzip it, Update the repository with the unzipped file. If successfully, Update 12.1 DBHOME with it
odacli create-prepatchreport --dbhome --dbhomeid 42590b55-7845-439b-9b76-589b9e6aaa2f -v 19.6.0.0.0

================
ERROR 3
================
Check all configured Databases, Start then and ensure they are running. Then run prepatch again

--BEFORE REIMAGING
[root@pngoda5 ~]# cat /proc/mdstat
Personalities : [raid1]
md1 : active raid1 sdb3[1] sda3[0]
      467694592 blocks super 1.1 [2/2] [UU]
      bitmap: 2/4 pages [8KB], 65536KB chunk

md0 : active raid1 sdb2[1] sda2[0]
      511936 blocks super 1.0 [2/2] [UU]

unused devices: <none>
[root@pngoda5 ~]#

[root@pngoda6 ~]# cat /proc/mdstat
Personalities : [raid1]
md1 : active raid1 sdb3[1] sda3[0]
      467694592 blocks super 1.1 [2/2] [UU]
      bitmap: 3/4 pages [12KB], 65536KB chunk

md0 : active raid1 sdb2[1] sda2[0]
      511936 blocks super 1.0 [2/2] [UU]

unused devices: <none>
[root@pngoda6 ~]#


[root@pngoda5 ~]# ip a
1: lo: <LOOPBACK,UP,LOWER_UP> mtu 16436 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
2: em2: <NO-CARRIER,BROADCAST,MULTICAST,SLAVE,UP> mtu 1500 qdisc mq master btbond1 state DOWN group default qlen 1000
    link/ether 00:10:e0:dd:b5:bd brd ff:ff:ff:ff:ff:ff
3: em3: <BROADCAST,MULTICAST,SLAVE,UP,LOWER_UP> mtu 1500 qdisc mq master btbond1 state UP group default qlen 1000
    link/ether 00:10:e0:dd:b5:bd brd ff:ff:ff:ff:ff:ff
4: p1p1: <BROADCAST,MULTICAST,SLAVE,UP,LOWER_UP> mtu 9000 qdisc mq master icbond0 state UP group default qlen 1000
    link/ether 00:0a:f7:d2:fc:40 brd ff:ff:ff:ff:ff:ff
5: p1p2: <BROADCAST,MULTICAST,SLAVE,UP,LOWER_UP> mtu 9000 qdisc mq master icbond0 state UP group default qlen 1000
    link/ether 00:0a:f7:d2:fc:40 brd ff:ff:ff:ff:ff:ff
6: em1: <NO-CARRIER,BROADCAST,MULTICAST,UP> mtu 1500 qdisc mq state DOWN group default qlen 1000
    link/ether 00:10:e0:dd:b5:bc brd ff:ff:ff:ff:ff:ff
7: bond0: <BROADCAST,MULTICAST,MASTER> mtu 1500 qdisc noop state DOWN group default qlen 1000
    link/ether ea:e8:6c:fc:2c:72 brd ff:ff:ff:ff:ff:ff
8: btbond1: <BROADCAST,MULTICAST,MASTER,UP,LOWER_UP> mtu 1500 qdisc noqueue master pubnet state UP group default qlen 1000
    link/ether 00:10:e0:dd:b5:bd brd ff:ff:ff:ff:ff:ff
9: pubnet: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 00:10:e0:dd:b5:bd brd ff:ff:ff:ff:ff:ff
    inet 10.234.192.91/26 brd 10.234.192.127 scope global pubnet
       valid_lft forever preferred_lft forever
    inet 10.234.192.93/26 brd 10.234.192.127 scope global secondary pubnet:1
       valid_lft forever preferred_lft forever
    inet 10.234.192.97/26 brd 10.234.192.127 scope global secondary pubnet:2
       valid_lft forever preferred_lft forever
    inet 10.234.192.95/26 brd 10.234.192.127 scope global secondary pubnet:3
       valid_lft forever preferred_lft forever
10: icbond0: <BROADCAST,MULTICAST,MASTER,UP,LOWER_UP> mtu 9000 qdisc noqueue state UP group default qlen 1000
    link/ether 00:0a:f7:d2:fc:40 brd ff:ff:ff:ff:ff:ff
    inet 192.168.16.24/24 brd 192.168.16.255 scope global icbond0
       valid_lft forever preferred_lft forever
11: icbond0.100@icbond0: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9000 qdisc noqueue master privasm state UP group default qlen 1000
    link/ether 00:0a:f7:d2:fc:40 brd ff:ff:ff:ff:ff:ff
12: privasm: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9000 qdisc noqueue state UP group default qlen 1000
    link/ether 00:0a:f7:d2:fc:40 brd ff:ff:ff:ff:ff:ff
    inet 192.168.17.2/25 brd 192.168.17.127 scope global privasm
       valid_lft forever preferred_lft forever
13: virbr0: <NO-CARRIER,BROADCAST,MULTICAST,UP> mtu 1500 qdisc noqueue state DOWN group default qlen 1000
    link/ether 52:54:00:25:4c:83 brd ff:ff:ff:ff:ff:ff
    inet 192.168.122.1/24 brd 192.168.122.255 scope global virbr0
       valid_lft forever preferred_lft forever
14: virbr0-nic: <BROADCAST,MULTICAST> mtu 1500 qdisc pfifo_fast master virbr0 state DOWN group default qlen 1000
    link/ether 52:54:00:25:4c:83 brd ff:ff:ff:ff:ff:ff
[root@pngoda5 ~]#




[root@pngoda6 ~]# ip a
1: lo: <LOOPBACK,UP,LOWER_UP> mtu 16436 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
2: em2: <NO-CARRIER,BROADCAST,MULTICAST,SLAVE,UP> mtu 1500 qdisc mq master btbond1 state DOWN group default qlen 1000
    link/ether 00:10:e0:dd:76:87 brd ff:ff:ff:ff:ff:ff
3: em3: <BROADCAST,MULTICAST,SLAVE,UP,LOWER_UP> mtu 1500 qdisc mq master btbond1 state UP group default qlen 1000
    link/ether 00:10:e0:dd:76:87 brd ff:ff:ff:ff:ff:ff
4: p1p1: <BROADCAST,MULTICAST,SLAVE,UP,LOWER_UP> mtu 9000 qdisc mq master icbond0 state UP group default qlen 1000
    link/ether 00:0a:f7:d2:fa:20 brd ff:ff:ff:ff:ff:ff
5: p1p2: <BROADCAST,MULTICAST,SLAVE,UP,LOWER_UP> mtu 9000 qdisc mq master icbond0 state UP group default qlen 1000
    link/ether 00:0a:f7:d2:fa:20 brd ff:ff:ff:ff:ff:ff
6: em1: <NO-CARRIER,BROADCAST,MULTICAST,UP> mtu 1500 qdisc mq state DOWN group default qlen 1000
    link/ether 00:10:e0:dd:76:86 brd ff:ff:ff:ff:ff:ff
7: bond0: <BROADCAST,MULTICAST,MASTER> mtu 1500 qdisc noop state DOWN group default qlen 1000
    link/ether 6a:56:99:bc:bb:dc brd ff:ff:ff:ff:ff:ff
8: btbond1: <BROADCAST,MULTICAST,MASTER,UP,LOWER_UP> mtu 1500 qdisc noqueue master pubnet state UP group default qlen 1000
    link/ether 00:10:e0:dd:76:87 brd ff:ff:ff:ff:ff:ff
9: pubnet: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 00:10:e0:dd:76:87 brd ff:ff:ff:ff:ff:ff
    inet 10.234.192.92/26 brd 10.234.192.127 scope global pubnet
       valid_lft forever preferred_lft forever
    inet 10.234.192.96/26 brd 10.234.192.127 scope global secondary pubnet:1
       valid_lft forever preferred_lft forever
    inet 10.234.192.94/26 brd 10.234.192.127 scope global secondary pubnet:4
       valid_lft forever preferred_lft forever
10: icbond0: <BROADCAST,MULTICAST,MASTER,UP,LOWER_UP> mtu 9000 qdisc noqueue state UP group default qlen 1000
    link/ether 00:0a:f7:d2:fa:20 brd ff:ff:ff:ff:ff:ff
    inet 192.168.16.25/24 brd 192.168.16.255 scope global icbond0
       valid_lft forever preferred_lft forever
11: icbond0.100@icbond0: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9000 qdisc noqueue master privasm state UP group default qlen 1000
    link/ether 00:0a:f7:d2:fa:20 brd ff:ff:ff:ff:ff:ff
12: privasm: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9000 qdisc noqueue state UP group default qlen 1000
    link/ether 00:0a:f7:d2:fa:20 brd ff:ff:ff:ff:ff:ff
    inet 192.168.17.3/25 brd 192.168.17.127 scope global privasm
       valid_lft forever preferred_lft forever
13: virbr0: <NO-CARRIER,BROADCAST,MULTICAST,UP> mtu 1500 qdisc noqueue state DOWN group default qlen 1000
    link/ether 52:54:00:10:09:3b brd ff:ff:ff:ff:ff:ff
    inet 192.168.122.1/24 brd 192.168.122.255 scope global virbr0
       valid_lft forever preferred_lft forever
14: virbr0-nic: <BROADCAST,MULTICAST> mtu 1500 qdisc pfifo_fast master virbr0 state DOWN group default qlen 1000
    link/ether 52:54:00:10:09:3b brd ff:ff:ff:ff:ff:ff
================
ERROR 1
================
For below error, move the mentioned file /flashback/DPR
DCS-10001:Internal error encountered:  Please check dcs-agent logs Mount owners not found for filesystem device: /dev/asm/bkpupacfs-126.

[root@pngoda5 ~]# ls -lrt /dev/asm/bkpupacfs-126_bkp
brwxrwx--- 1 root asmadmin 250, 64515 Aug 22 21:11 /dev/asm/bkpupacfs-126_bkp
[root@pngoda5 ~]#

[root@pngoda6 asm]# ls -lrt /dev/asm/bkpupacfs-126_bkp
brwxrwx--- 1 root asmadmin 250, 64515 Aug 22 21:11 /dev/asm/bkpupacfs-126_bkp
You have new mail in /var/spool/mail/root
[root@pngoda6 asm]#


================
ERROR 2
================
Validate Database Home Version Failed   Version '12.1.0.2.180116' for          Please update the databases running
                                        database home 'OraDB12102_home1' is    from this home to the minimum
                                        lower than minimum supported version   supported version or higher and
                                        '12.1.0.2.220719'                      delete this database home using the
                                                                               'odacli delete-dbhome' command

Download RDBMS Patch 23494992, Copy to /flashback/ODA_PATCHES/19.6.0.0/,
unzip it, Update the repository with the unzipped file. If successfully, Update 12.1 DBHOME with it
odacli create-prepatchreport --dbhome --dbhomeid 42590b55-7845-439b-9b76-589b9e6aaa2f -v 19.6.0.0.0

================
ERROR 3
================
Check all configured Databases, Start then and ensure they are running. Then run prepatch again