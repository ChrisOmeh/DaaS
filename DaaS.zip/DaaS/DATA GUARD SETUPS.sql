DATABRK = 
  (DESCRIPTION = 
    (ADDRESS = (PROTOCOL = TCP)(HOST =  pngoda78-vip.ng.sbicdirectory.com)(PORT = 1521)) 
    (CONNECT_DATA = 
      (SERVER = DEDICATED) 
      (SERVICE_NAME = DATABRK.ng.sbicdirectory.com) 
    ) 
  ) 

 

DATABRK_DR = 

  (DESCRIPTION = 

    (ADDRESS_LIST = 

      (ADDRESS = (PROTOCOL = TCP)(HOST = pngoda1-vip)(PORT = 1521)) 

    ) 

    (CONNECT_DATA = 

      (SERVICE_NAME = DATABRK_DR) 

    ) 

  ) 

 

 

#####this one for transfer of archives from standby to PROD - - used in standby dest_2 

 

DATABRK1_VIP = 

  (DESCRIPTION = 

    (ADDRESS_LIST = 

      (ADDRESS = (PROTOCOL = TCP)(HOST = pngoda7-vip.ng.sbicdirectory.com)(PORT = 1521)) 

    ) 

    (CONNECT_DATA = 

      (SERVICE_NAME = DATABRK.ng.sbicdirectory.com) 

    ) 

  ) 

 

#####this one for transfer of archives from prod to standby - used in prod dest_2 

 

DATABRK1_DR_VIP = 

  (DESCRIPTION = 

    (ADDRESS_LIST = 

      (ADDRESS = (PROTOCOL = TCP)(HOST = pngoda1-vip.ng.sbicdirectory.com)(PORT = 1521)) 

    ) 

    (CONNECT_DATA = 

      (SERVICE_NAME = DATABRK_DR.ng.sbicdirectory.com) 

    ) 

  ) 

 

####these are in case PROD node 1 or DR node 1 is down 

#### we will use them to transfer archivelogs 

 

######from standby to PROD 

 

DATABRK2_VIP = 

  (DESCRIPTION = 

    (ADDRESS_LIST = 

      (ADDRESS = (PROTOCOL = TCP)(HOST = pngoda8-vip.ng.sbicdirectory.com)(PORT = 1521)) 

    ) 

    (CONNECT_DATA = 

      (SERVICE_NAME = DATABRK.ng.sbicdirectory.com) 

    ) 

  ) 

 

 

#####from prod to standby 

 

DATABRK2_DR_VIP = 

  (DESCRIPTION = 

    (ADDRESS_LIST = 

      (ADDRESS = (PROTOCOL = TCP)(HOST = pngoda2-vip.ng.sbicdirectory.com)(PORT = 1521)) 

    ) 

    (CONNECT_DATA = 

      (SERVICE_NAME = DATABRK_DR.ng.sbicdirectory.com) 

    ) 

  ) 

 

ADD STATIC LISTENER ENTRIES TO LISTENER.ORA FILE 

 

ON PNGODA7 

 

SID_LIST_LISTENER = 

  (SID_LIST = 

    (SID_DESC = 

      (GLOBAL_DBNAME = databrk_DGMGRL) 

      (ORACLE_HOME = /u01/app/oracle/product/12.1.0.2/dbhome_1) 

      (SID_NAME = databrk1) 

    ) 

  ). 

 

ON PNGODA8 

 

SID_LIST_LISTENER = 

  (SID_LIST = 

    (SID_DESC = 

      (GLOBAL_DBNAME = databrk_DGMGRL) 

      (ORACLE_HOME = /u01/app/oracle/product/12.1.0.2/dbhome_1) 

      (SID_NAME = databrk2) 

    ) 

  ) 

 

ON PNGODA1 

 

SID_LIST_LISTENER = 

  (SID_LIST = 

    (SID_DESC = 

      (GLOBAL_DBNAME = databrk_dr_DGMGRL) 

      (ORACLE_HOME = /u01/app/oracle/product/12.1.0.2/dbhome_1) 

      (SID_NAME = databrk1) 

    ) 

  ) 

 

 

 

ON PNGODA2 

 

SID_LIST_LISTENER = 

  (SID_LIST = 

    (SID_DESC = 

      (GLOBAL_DBNAME = databrk_dr_DGMGRL) 

      (ORACLE_HOME = /u01/app/oracle/product/12.1.0.2/dbhome_1) 

      (SID_NAME = databrk2) 

    ) 

  ) 



VERSION           
----------------- 
12.2.0.1.0        



VERSION            VERSION_FULL      
-----------------  ----------------- 
19.0.0.0.0         19.20.0.0.0       


VERSION           VERSION_LEGACY    VERSION_FULL
----------------- ----------------- -----------------
19.0.0.0.0        19.0.0.0.0        19.20.0.0.0
alter system set log_archive_dest_3=' ';

alter system set db_unique_name=dconcept scope=spfile;    -- primary db name
alter system set log_archive_config='dg_config=(PNGCFM,DNGCFM)'; --prod
alter system set log_archive_config='dg_config=(DNGCFM,PNGCFM)'; --dr
alter system set log_archive_dest_1='location=USE_DB_RECOVERY_FILE_DEST valid_for=(ALL_LOGFILES,ALL_ROLES)'; --PROD
alter system set log_archive_dest_1='LOCATION=+RECO/ VALID_FOR=(ALL_LOGFILES,ALL_ROLES) DB_UNIQUE_NAME=pngcfm'; --DR
alter system set log_archive_dest_2='service="pngcfm", ASYNC NOAFFIRM db_unique_name="pngcfm" valid_for=(online_logfile,all_roles)';  --PROD ONLY tns alias pointing to the standby db service
alter system set log_archive_dest_state_2=defer;
alter system set fal_server=pngcapp; --in dr  -- where to go if you need to resolve gaps. this is optional.
alter system set db_file_name_convert='berlin','london','BERLIN','LONDON' scope=spfile;
alter system set log_file_name_convert='berlin','london','BERLIN','LONDON' scope=spfile;
alter system set standby_file_management=auto; --BOTH SITE
startup force;  --restart the database for changes to take effect

validate static connect identifier for all;
VALIDATE STATIC CONNECT IDENTIFIER FOR all;
validate network configuration for all;
validate NETWORK CONFIGURATION FOR all;
show database "DNGCFM" InconsistentProperties;
show database "DELL_DG" statusreport

location=USE_DB_RECOVERY_FILE_DEST valid_for=(ALL_LOGFILES,ALL_ROLES)

==============
COMPATIBILITY
==============
https://support.oracle.com/epmos/faces/DocumentDisplay?_afrLoop=414352872064231&parent=DOCUMENT&sourceId=2614156.1&id=834155.1&_afrWindowMode=0&_adf.ctrl-state=1iduymlpf_151
https://support.oracle.com/epmos/faces/DocumentDisplay?_afrLoop=413712931491543&parent=EXTERNAL_SEARCH&sourceId=PROBLEM&id=2988948.1&_afrWindowMode=0&_adf.ctrl-state=1iduymlpf_53

ALTER SYSTEM SET COMPATIBLE='12.2.0.0' SCOPE=SPFILE;

ls -lrt /u01/app/odaorahome/oracle/product/19.0.0.0/dbhome_1/rdbms/admin/catalog.sql
=======================
SOLUTION
=======================
Making the below configuration changes should resolve the "ORA-16055: FAL request rejected" and "FAL archive failed with error 16198".

@Primary:

alter system set LOG_ARCHIVE_DEST_1='LOCATION=USE_DB_RECOVERY_FILE_DEST VALID_FOR=(ALL_LOGFILES,ALL_ROLES) DB_UNIQUE_NAME=primary_db_unique_name' sid='*' scope=both;
alter system set log_archive_dest_2='SERVICE=standby_service_name ASYNC VALID_FOR=(ONLINE_LOGFILES,PRIMARY_ROLE) DB_UNIQUE_NAME=standby_db_unique_name' sid='*' scope=both;

@Standby:

alter system set LOG_ARCHIVE_DEST_1='LOCATION=USE_DB_RECOVERY_FILE_DEST VALID_FOR=(ALL_LOGFILES,ALL_ROLES) DB_UNIQUE_NAME=standby_db_unique_name' sid='*' scope=both;
alter system set log_archive_dest_2='' sid='*' scope = both;

Grand Total Time: 1625s

 LOG FILES: (/u01/app/odaorahome/oracle/product/19.0.0.0/dbhome_1/cfgtoollogs/dngcfrm/upgrade20240719183849/catupgrd*.log)

Upgrade Summary Report Located in:
/u01/app/odaorahome/oracle/product/19.0.0.0/dbhome_1/cfgtoollogs/dngcfrm/upgrade20240719183849/upg_summary.log





Errors in file /u01/app/odaorabase/oracle/diag/rdbms/pngcapp/pngcapp1/trace/pngcapp1_drcx_20477.trc:
ORA-00313: open failed for members of log group 10 of thread 1
ORA-00312: online log 10 thread 1: '+REDO/PNGCAPP/ONLINELOG/stnbylog_10'
ORA-17503: ksfdopn:2 Failed to open file +REDO/PNGCAPP/ONLINELOG/stnbylog_10
ORA-15173: entry 'stnbylog_10' does not exist in directory 'ONLINELOG'
2024-08-29T15:13:17.155775+01:00
Errors in file /u01/app/odaorabase/oracle/diag/rdbms/pngcapp/pngcapp1/trace/pngcapp1_drcx_20477.trc:
ORA-00313: open failed for members of log group 10 of thread 1
ORA-00312: online log 10 thread 1: '+REDO/PNGCAPP/ONLINELOG/stnbylog_10'
ORA-17503: ksfdopn:2 Failed to open file +REDO/PNGCAPP/ONLINELOG/stnbylog_10
ORA-15173: entry 'stnbylog_10' does not exist in directory 'ONLINELOG'
2024-08-29T15:13:17.156770+01:00
Errors in file /u01/app/odaorabase/oracle/diag/rdbms/pngcapp/pngcapp1/trace/pngcapp1_drcx_20477.trc:
ORA-00313: open failed for members of log group 11 of thread 1
ORA-00312: online log 11 thread 1: '+REDO/PNGCAPP/ONLINELOG/stnbylog_11'
ORA-17503: ksfdopn:2 Failed to open file +REDO/PNGCAPP/ONLINELOG/stnbylog_11
ORA-15173: entry 'stnbylog_11' does not exist in directory 'ONLINELOG'
2024-08-29T15:13:17.157071+01:00
Errors in file /u01/app/odaorabase/oracle/diag/rdbms/pngcapp/pngcapp1/trace/pngcapp1_drcx_20477.trc:
ORA-00313: open failed for members of log group 11 of thread 1
ORA-00312: online log 11 thread 1: '+REDO/PNGCAPP/ONLINELOG/stnbylog_11'
ORA-17503: ksfdopn:2 Failed to open file +REDO/PNGCAPP/ONLINELOG/stnbylog_11
ORA-15173: entry 'stnbylog_11' does not exist in directory 'ONLINELOG'
2024-08-29T15:13:17.158049+01:00
Errors in file /u01/app/odaorabase/oracle/diag/rdbms/pngcapp/pngcapp1/trace/pngcapp1_drcx_20477.trc:
ORA-00313: open failed for members of log group 12 of thread 1
ORA-00312: online log 12 thread 1: '+REDO/PNGCAPP/ONLINELOG/stnbylog_12'
ORA-17503: ksfdopn:2 Failed to open file +REDO/PNGCAPP/ONLINELOG/stnbylog_12
ORA-15173: entry 'stnbylog_12' does not exist in directory 'ONLINELOG'
2024-08-29T15:13:17.158316+01:00
Errors in file /u01/app/odaorabase/oracle/diag/rdbms/pngcapp/pngcapp1/trace/pngcapp1_drcx_20477.trc:
ORA-00313: open failed for members of log group 12 of thread 1
ORA-00312: online log 12 thread 1: '+REDO/PNGCAPP/ONLINELOG/stnbylog_12'
ORA-17503: ksfdopn:2 Failed to open file +REDO/PNGCAPP/ONLINELOG/stnbylog_12
ORA-15173: entry 'stnbylog_12' does not exist in directory 'ONLINELOG'
2024-08-29T15:13:17.159220+01:00
Errors in file /u01/app/odaorabase/oracle/diag/rdbms/pngcapp/pngcapp1/trace/pngcapp1_drcx_20477.trc:
ORA-00313: open failed for members of log group 13 of thread 2
ORA-00312: online log 13 thread 2: '+REDO/PNGCAPP/ONLINELOG/stnbylog_13'
ORA-17503: ksfdopn:2 Failed to open file +REDO/PNGCAPP/ONLINELOG/stnbylog_13
ORA-15173: entry 'stnbylog_13' does not exist in directory 'ONLINELOG'
2024-08-29T15:13:17.159486+01:00
Errors in file /u01/app/odaorabase/oracle/diag/rdbms/pngcapp/pngcapp1/trace/pngcapp1_drcx_20477.trc:
ORA-00313: open failed for members of log group 13 of thread 2
ORA-00312: online log 13 thread 2: '+REDO/PNGCAPP/ONLINELOG/stnbylog_13'
ORA-17503: ksfdopn:2 Failed to open file +REDO/PNGCAPP/ONLINELOG/stnbylog_13
ORA-15173: entry 'stnbylog_13' does not exist in directory 'ONLINELOG'
2024-08-29T15:13:17.160364+01:00
Errors in file /u01/app/odaorabase/oracle/diag/rdbms/pngcapp/pngcapp1/trace/pngcapp1_drcx_20477.trc:
ORA-00313: open failed for members of log group 14 of thread 2
ORA-00312: online log 14 thread 2: '+REDO/PNGCAPP/ONLINELOG/stnbylog_14'
ORA-17503: ksfdopn:2 Failed to open file +REDO/PNGCAPP/ONLINELOG/stnbylog_14
ORA-15173: entry 'stnbylog_14' does not exist in directory 'ONLINELOG'
2024-08-29T15:13:17.160695+01:00
Errors in file /u01/app/odaorabase/oracle/diag/rdbms/pngcapp/pngcapp1/trace/pngcapp1_drcx_20477.trc:
ORA-00313: open failed for members of log group 14 of thread 2
ORA-00312: online log 14 thread 2: '+REDO/PNGCAPP/ONLINELOG/stnbylog_14'
ORA-17503: ksfdopn:2 Failed to open file +REDO/PNGCAPP/ONLINELOG/stnbylog_14
ORA-15173: entry 'stnbylog_14' does not exist in directory 'ONLINELOG'
2024-08-29T15:13:17.161547+01:00
Errors in file /u01/app/odaorabase/oracle/diag/rdbms/pngcapp/pngcapp1/trace/pngcapp1_drcx_20477.trc:
ORA-00313: open failed for members of log group 15 of thread 2
ORA-00312: online log 15 thread 2: '+REDO/PNGCAPP/ONLINELOG/stnbylog_15'
ORA-17503: ksfdopn:2 Failed to open file +REDO/PNGCAPP/ONLINELOG/stnbylog_15
ORA-15173: entry 'stnbylog_15' does not exist in directory 'ONLINELOG'
2024-08-29T15:13:17.161830+01:00
Errors in file /u01/app/odaorabase/oracle/diag/rdbms/pngcapp/pngcapp1/trace/pngcapp1_drcx_20477.trc:
ORA-00313: open failed for members of log group 15 of thread 2
ORA-00312: online log 15 thread 2: '+REDO/PNGCAPP/ONLINELOG/stnbylog_15'
ORA-17503: ksfdopn:2 Failed to open file +REDO/PNGCAPP/ONLINELOG/stnbylog_15
ORA-15173: entry 'stnbylog_15' does not exist in directory 'ONLINELOG'

alter database add standby logfile thread 1 group 10 '+REDO/PNGCAPP/ONLINELOG/stnbylog_10' size 5021M;
alter database add standby logfile thread 1 group 11 '+REDO/PNGCAPP/ONLINELOG/stnbylog_11' size 5021M;
alter database add standby logfile thread 1 group 12 '+REDO/PNGCAPP/ONLINELOG/stnbylog_12' size 5021M;
alter database add standby logfile thread 2 group 13 '+REDO/PNGCAPP/ONLINELOG/stnbylog_13' size 5021M;
alter database add standby logfile thread 2 group 14 '+REDO/PNGCAPP/ONLINELOG/stnbylog_14' size 5021M;
alter database add standby logfile thread 2 group 15 '+REDO/PNGCAPP/ONLINELOG/stnbylog_15' size 5021M;
alter database add standby logfile thread 2 group 16 '+REDO/PNGCAPP/ONLINELOG/stnbylog_16' size 5021M;
alter database add standby logfile thread 1 group 17 '+REDO/PNGCAPP/ONLINELOG/stnbylog_17' size 5021M;

ALTER DATABASE ADD LOGFILE thread 1 GROUP 1 ( '+REDO/PNGCAPP/ONLINELOG/group_1.log') SIZE 5021M;
ALTER DATABASE ADD LOGFILE thread 2 GROUP 2 ( '+REDO/PNGCAPP/ONLINELOG/group_2.log') SIZE 5021M;
ALTER DATABASE ADD LOGFILE thread 1 GROUP 3 ( '+REDO/PNGCAPP/ONLINELOG/group_3.log') SIZE 5021M;
ALTER DATABASE ADD LOGFILE thread 2 GROUP 4 ( '+REDO/PNGCAPP/ONLINELOG/group_4.log') SIZE 5021M;


Validating static connect identifier for the primary database dngcapp...
Unable to connect to database using (DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=10.234.181.91)(PORT=1521))(CONNECT_DATA=(SERVICE_NAME=dngcapp_DGMGRL.ng.sbicdirectory.com)(INSTANCE_NAME=pngcapp1)(SERVER=DEDICATED)(STATIC_SERVICE=TRUE)))
ORA-12514: TNS:listener does not currently know of service requested in connect descriptor

edit database pngcapp set property StaticConnectIdentifier='(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=10.234.181.91)(PORT=1521))(CONNECT_DATA=(SERVICE_NAME=dngcapp_DGMGRL.ng.sbicdirectory.com)(INSTANCE_NAME=pngcapp1)(SERVER=DEDICATED)(STATIC_SERVICE=TRUE)))';
alter system set remote_listener='pngoda56-vip.ng.sbicdirectory.com:1521' scope=both sid='*';

alter system set local_listener='(ADDRESS=(PROTOCOL=TCP)(HOST=Pngoda5-vip.ng.sbicdirectory.com)(PORT=1521))' scope=both sid='*';
(ADDRESS=(PROTOCOL=TCP)(HOST=Pngoda5-vip.ng.sbicdirectory.com)(PORT=1521))

Failed.
    Warning: Ensure primary database's StaticConnectIdentifier property
    is configured properly so that the primary database can be restarted
    by DGMGRL after switchover


srvctl modify database -d pngcfm -pwfile +DATA/PNGCFM/PASSWORD/pwdpngcfm.1151.1169718301
select open_mode,database_role,database_type from v$database,v$instance;

nohup rman target / @/flashback/rmanbkp/daily/pngcapp/pngcapp_restore.full log=/flashback/expdp//pngcapp.fullbkp28AUG2024.ful.log &

pwcopy --dbuniquename PNGCAPP /home/grid/pwdpngcapp.4561178105615 +DATA/PNGCAPP/PASSWORD/pwdpngcapp.10261178291399 -f

pwcopy '/home/grid/pwdpngcapp.4561178105615' '+DATA/PNGCAPP/PASSWORD/pwdpngcapp.10261178291399'

pwcopy /home/grid/pwdpngcapp.4561178105615 +DATA/PNGCAPP/PASSWORD/pwdpngcapp.10261178291399

+DATA/PNGCFM/PASSWORD/pwdpngcfm.1151.1169718301

orapwd file=+DATA/PNGCFM/PASSWORD/pwdpngcfm.1151.1169718301 -dbuniquename PNGCFM
orapwd file=+DATA/DNGCFM/PASSWORD/pwdpngcfm.1151.1169718301 force=y dbuniquename=DNGCFM
pwcreate --dbuniquename DNGCFM +DATA/PNGCFM/PASSWORD/pwdpngcfm.1151.1169718301 SQwer_1234#

+DATA/PNGCAPP/PASSWORD/pwdpngcapp.1026.1178291399

orapwd file='+DATA/PNGCAPP/PASSWORD/pwdpngcapp.10261178291399' password=SQwer_1234# force=y format=12 dbuniquename=pngcapp

ASMCMD> pwcreate --asm +DATA/PNGCFM/PASSWORD/pwdpngcfm.456117810561 SQwer_1234# 


ASMCMD> pwget --asm 
+disk_group_name/orapwasm

drop table redbox.RBX_P_REQ_MGR_D_LOG110624 purge




[oracle@pngoda7 dbs]$ strings /u01/app/odaorahome/oracle/product/19.0.0.0/dbhome_1/dbs/orapwpngcfm1
]\[Z
ORACLE Remote Password file
2F2554720562532B
SYSDG
SYSBACKUP
SYSKM
VYxp
 haCn
^a`A



[grid@pngoda6 ~]$ cd ODA_UPGRADE_FILES/pngcfm/
[grid@pngoda6 pngcfm]$ ls
Current.307.1031695805  initpngcfm.ora  pwdpngcfm.1319.1031695675  spfile.1382.1031695973
[grid@pngoda6 pngcfm]$ strings pwdpngcfm.1319.1031695675
]\[Z
ORACLE Remote Password file
2F2554720562532B
SYSDG
6C6198D0644CF9B4
z[;7
SYSBACKUP
23AA48ACB42ADCF9
SYSKM
F2DCB573DBFEDD9E
Q=Zp
[grid@pngoda6 pngcfm]$


[grid@pngoda5 ~]$ strings pwdpngcfm.456.1178105615
]\[Z
ORACLE Remote Password file
2F2554720562532B
[grid@pngoda5 ~]$


/u01/app/odaorahome/oracle/product/19.0.0.0/dbhome_1/dbs/spfilepngcfm1.ora
/u01/app/odaorahome/oracle/product/19.0.0.0/dbhome_1/dbs/spfilepngcfm1.ora


+DATA/DCONCEPT/PARAMETERFILE/spfileiconcept.ora

+DATA/iconcept/PARAMETERFILE/spfileiconcept.ora
+DATA/PNGCFM/PARAMETERFILE/spfilepngcfm.ora

/u01/app/odaorahome/oracle/product/19.0.0.0/dbhome_1/dbs/spfilepngcapp1.ora

+DATA/DNGCAPP/PARAMETERFILE/spfilepngcapp.ora

srvctl modify database -d dngcfm -p +DATA/DNGCFM/PARAMETERFILE/spfilepngcfm.ora
