Alter database datafile '+DATA/PNGFIB/DATAFILE/undotbs1.1005.1049289575' resize 31G;

Alter database datafile '+DATA/PNGABANK/DATAFILE/agencydb_indx.3653.1068216737' resize 31G;

Alter database datafile '+DATA/PNGFIN/DATAFILE/part_tab_hth_q4_tblspc.2732.1090754861' resize 31G;	
Alter database datafile '+DATA/PNGFIN/DATAFILE/part_tab_hth_q4_tblspc.2733.1090754775' resize 31G;	
Alter database datafile '+DATA/PNGFIN/DATAFILE/pngfin_1053419757_sbvcjq7d_569.dbf' resize 31G;



ALTER TABLE custom.ussd_charges_daily ADD PARTITION TAB_HTD_PART49 VALUES LESS THAN (TO_DATE(' 2024-04-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN'))
    LOGGING
    NOCOMPRESS 
    TABLESPACE PART_TAB_HTD_Q1_TBLSPC
    PCTUSED    40
    PCTFREE    10
    INITRANS   50
    MAXTRANS   255
    STORAGE    (
                INITIAL          1000M
                NEXT             500M
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                FREELISTS        64
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
               );  
ALTER TABLE custom.ussd_charges_daily ADD PARTITION TAB_HTD_PART50 VALUES LESS THAN (TO_DATE(' 2024-07-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN'))
    LOGGING
    NOCOMPRESS 
    TABLESPACE PART_TAB_HTD_Q2_TBLSPC
    PCTUSED    40
    PCTFREE    10
    INITRANS   50
    MAXTRANS   255
    STORAGE    (
                INITIAL          1000M
                NEXT             500M
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                FREELISTS        64
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
               ); 
ALTER TABLE custom.ussd_charges_daily ADD PARTITION TAB_HTD_PART51 VALUES LESS THAN (TO_DATE(' 2024-10-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN'))
    LOGGING
    NOCOMPRESS 
    TABLESPACE CUSTOM_TBLS
    PCTUSED    40
    PCTFREE    10
    INITRANS   50
    MAXTRANS   255
    STORAGE    (
                INITIAL          1000M
                NEXT             500M
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                FREELISTS        64
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
               );
ALTER TABLE custom.ussd_charges_daily ADD PARTITION TAB_HTD_PART52 VALUES LESS THAN (TO_DATE(' 2025-01-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN'))
    LOGGING
    NOCOMPRESS 
    TABLESPACE PART_TAB_HTD_Q4_TBLSPC
    PCTUSED    40
    PCTFREE    10
    INITRANS   50
    MAXTRANS   255
    STORAGE    (
                INITIAL          1000M
                NEXT             500M
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                FREELISTS        64
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
               );
ALTER TABLE custom.ussd_charges_daily ADD PARTITION TAB_HTD_PART53 VALUES LESS THAN (TO_DATE(' 2025-04-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN'))
    LOGGING
    NOCOMPRESS 
    TABLESPACE PART_TAB_HTD_Q1_TBLSPC
    PCTUSED    40
    PCTFREE    10
    INITRANS   50
    MAXTRANS   255
    STORAGE    (
                INITIAL          1000M
                NEXT             500M
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                FREELISTS        64
                FREELIST GROUPS  1
                BUFFER_POOL      DEFAULT
);

alter index TBAADM.IDX_HIST_TRAN_DTL_TABLE rename PARTITION TAB_HTD_PART49  to IDXL1_HTD_PART49;
alter index TBAADM.IDX_HIST_TRAN_DTL_TABLE rename PARTITION TAB_HTD_PART50  to IDXL1_HTD_PART50;
alter index TBAADM.IDX_HIST_TRAN_DTL_TABLE rename PARTITION TAB_HTD_PART51  to IDXL1_HTD_PART51;
alter index TBAADM.IDX_HIST_TRAN_DTL_TABLE rename PARTITION TAB_HTD_PART52  to IDXL1_HTD_PART52;
alter index TBAADM.IDX_HIST_TRAN_DTL_TABLE rename PARTITION TAB_HTD_PART53  to IDXL1_HTD_PART53;



ALTER TABLE custom.ussd_charges_daily ADD PARTITION TAB_HTH_PART49 VALUES LESS THAN (TO_DATE(' 2024-04-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN'))
    LOGGING
    NOCOMPRESS 
    TABLESPACE PART_TAB_HTH_Q1_TBLSPC
    PCTFREE    10
    INITRANS   50
    MAXTRANS   255
    STORAGE    (
                INITIAL          1000M
                NEXT             500M
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                BUFFER_POOL      DEFAULT
               );  
ALTER TABLE custom.ussd_charges_daily ADD PARTITION TAB_HTH_PART50 VALUES LESS THAN (TO_DATE(' 2024-07-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN'))
    LOGGING
    NOCOMPRESS 
    TABLESPACE PART_TAB_HTH_Q2_TBLSPC
    PCTFREE    10
    INITRANS   50
    MAXTRANS   255
    STORAGE    (
                INITIAL          1000M
                NEXT             500M
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                BUFFER_POOL      DEFAULT
               ); 
ALTER TABLE custom.ussd_charges_daily ADD PARTITION TAB_HTH_PART51 VALUES LESS THAN (TO_DATE(' 2024-10-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN'))
    LOGGING
    NOCOMPRESS 
    TABLESPACE PART_TAB_HTH_Q3_TBLSPC
    PCTFREE    10
    INITRANS   50
    MAXTRANS   255
    STORAGE    (
                INITIAL          1000M
                NEXT             500M
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                BUFFER_POOL      DEFAULT
               );  
ALTER TABLE custom.ussd_charges_daily ADD PARTITION TAB_HTH_PART52 VALUES LESS THAN (TO_DATE(' 2025-01-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN'))
    LOGGING
    NOCOMPRESS 
    TABLESPACE PART_TAB_HTH_Q4_TBLSPC
    PCTFREE    10
    INITRANS   50
    MAXTRANS   255
    STORAGE    (
                INITIAL          1000M
                NEXT             500M
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                BUFFER_POOL      DEFAULT
               );
ALTER TABLE custom.ussd_charges_daily ADD PARTITION TAB_HTH_PART53 VALUES LESS THAN (TO_DATE(' 2025-04-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN'))
    LOGGING
    NOCOMPRESS 
    TABLESPACE PART_TAB_HTH_Q1_TBLSPC
    PCTFREE    10
    INITRANS   50
    MAXTRANS   255
    STORAGE    (
                INITIAL          1000M
                NEXT             500M
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                BUFFER_POOL      DEFAULT
               );
               


alter index TBAADM.IDX_HIST_TRAN_HEADER_TABLE rename PARTITION TAB_HTH_PART49  to IDXL1_HTH_PART49;
alter index TBAADM.IDX_HIST_TRAN_HEADER_TABLE rename PARTITION TAB_HTH_PART50  to IDXL1_HTH_PART50;
alter index TBAADM.IDX_HIST_TRAN_HEADER_TABLE rename PARTITION TAB_HTH_PART51  to IDXL1_HTH_PART51;
alter index TBAADM.IDX_HIST_TRAN_HEADER_TABLE rename PARTITION TAB_HTH_PART52  to IDXL1_HTH_PART52;
alter index TBAADM.IDX_HIST_TRAN_HEADER_TABLE rename PARTITION TAB_HTH_PART53  to IDXL1_HTH_PART53;

