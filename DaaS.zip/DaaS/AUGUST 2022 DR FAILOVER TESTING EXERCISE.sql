OBJECTIVE: 
=The objective of this exercise is to test the failover from Primary node to secondary as part disaster recovery mechanism.
=To ascertain possible RTO and RPO of the bank


Applications/ Systems Tested during this Exercise
Finacle, -----------------------------------Done
2FA, ---------------------------------------
Redbox, ------------------------------------Done
Postilion,---------------------------------- 
Internet Banking, --------------------------Done
Mobile Banking, ----------------------------
E-Banking Admin, ---------------------------
Infoware Core/Web, -------------------------Done
Omniflow, ----------------------------------Done
Ibranch, -----------------------------------Done
User Access Management (UAM) Portal, -------Done
Cleric – Reconciliation, -------------------Done
Cheque Personalizer System (CPS), ----------Done
Address Verification Portal, ---------------Done
BVN Management Portal, ---------------------Done
Gori - Outward Cheques, --------------------Done
Smart Ascent (Qucoon), ---------------------Done
ITMS (Finnaxia/BIB),------------------------Done
EZ Cash Admin, -----------------------------Done
Single Sign On (SSO), ----------------------
3S Banking, --------------------------------
Deal Tracker, ------------------------------Done
Callover Standalone, -----------------------Done
Deposit Advice, ----------------------------Done
Legal Search, ------------------------------Done
Cash Management Portal, --------------------Done
Intellinx (Online/Mobile Banking Module)----Done
and Finacle Collection Module (FCM)---------Done


=====GETTING AND DROPPING DBLINK================
SELECT DBMS_METADATA.GET_DDL('DB_LINK',a.db_link,a.owner) 
FROM dba_db_links a;

======RESTORE DB IN SQL SERVER=============
RESTORE DATABASE [DB_NAME] WITH RECOVERY


======ORACLE SCRIPT TO FIND RUNNING SESSIONS===================
select * from gv$process where addr In (select creator_addr from gv$session where sid=5806 and serial#=29171);

=KILLING THE SESSIONS
kill session_name

YET TO BE PUT BACK TO REPLICATION
ITMS
REDBOX

deal tracker and infoware,IWGI

ibranch amd mobile banking needs 2FA from redbox to be up.

itoken and infoware done at same time.


Finacle DB: ST: 7:04am ET7:06am
Redbox DB: ST: 7:06am ET7:08am

Internet Banking DB: ST: 7:08am ET7:10am



infoware: ST8:35am ET 8:37am

===============================IT FOR IT  DR EXERCISE=================================
20/05/2023
Finacle, 
Finacle Collection Module (FCM), 
2FA, 
Redbox, 
E-Banking Admin, 
Postilion (ATM), 
Internet Banking, Mobile Banking, 
Single Sign On (SSO), 
3S-Banking, 
Intellinx (Online/Mobile Banking Module), 
Infoware Core/Web, 
Omniflow, 
Ibranch, 
User Access Management (UAM) Portal, 
Cleric – Reconciliation, 
Cheque Personalizer System (CPS), 
Cheque Truncation System (CTS), 
Address Verification Portal, 
BVN Management Portal, 
Smart Ascent (Qucoon), 
ITMS (Finnaxia/BIB), 
EZ Cash Admin,  done
Deal Tracker, 
Callover Standalone, 
Deposit Advice, 
Legal Search, 
Cash Management Portal, 
Electronic Document Library (EDL), 
Credit Risk Management System (CRMS), 
Nominee Detachment Portal, 
CBN FX Account Opening and CAPS


RED_LINK DB LINK that is required to be recreated. It is on Redbox

CREATE PUBLIC DATABASE LINK RED_LINK
 CONNECT TO ARCHIVAL
 IDENTIFIED BY <password>
 USING '(DESCRIPTION =
    (ADDRESS = (PROTOCOL = TCP)(HOST = yngrhev01.ng.sbicdirectory.com)(PORT = 1521))
    (CONNECT_DATA =
    (SERVER = DEDICATED)
    (SERVICE_NAME = dngfin)
        )
  )';

dgmgrl sys/qwer1234@pngfin
dgmgrl sys/qwer1234@pngrdbox
dgmgrl sys/qwer1234@pngfib
dgmgrl sys/qwer1234@pngabank
dgmgrl sys/qwer1234@pngaud
dgmgrl sys/qwer1234@pngcog
dgmgrl sys/qwer1234@pngitms
dgmgrl sys/qwer1234@pngpas
dgmgrl sys/qwer1234@pngctm
dgmgrl sys/qwer1234@pngcem
dgmgrl sys/qwer1234@pngdtr
dgmgrl sys/qwer1234@pngesb
ODA
dgmgrl sys/SQwer_1234#@pngcapp

===================================
CONVERT DR TO SNAPSHOT STANDBY
===================================
convert database dngfin to snapshot standby;
convert database dngrdbox to snapshot standby;
convert database dngfib to snapshot standby; 
convert database dngcfm to snapshot standby;
convert database dngtfin to snapshot standby;

convert database dconcept to snapshot standby;

===================================
CONVERT DR BACK TO PHYSICAL STANDBY
===================================
convert database dngfin to physical standby;
convert database dngrdbox to physical standby;
convert database dngfib to physical standby;
convert database dngtfin to physical standby;

===============================================
STOP/START REPLICATION --Any of below can serve
===============================================

edit database iconcept set state=TRANSPORT-OFF;
edit database dngfin set state=APPLY-OFF;

edit database iconcept set state=TRANSPORT-ON;
edit database dconcept set state=APPLY-ON;

edit database pngcfm set state=TRANSPORT-OFF;
edit database dngcfm set state=APPLY-OFF;

edit database pngcfm set state=TRANSPORT-ON;
edit database dngcfm set state=APPLY-ON;

edit database dngcfm set state=TRANSPORT-OFF;
edit database pngcfm set state=APPLY-OFF;

edit database pngcapp set state=TRANSPORT-OFF;
edit database dngcapp set state=APPLY-OFF;

edit database dngcapp set state=TRANSPORT-ON;
edit database pngcapp set state=APPLY-OFF;

edit database dconcept set state=TRANSPORT-OFF;
edit database iconcept set state=APPLY-OFF;

edit database iconcept set state=TRANSPORT-ON;
edit database dconcept set state=APPLY-ON;


edit database dngfin set state=APPLY-OFF;
edit database pngfin set state=TRANSPORT-OFF;
edit database dngfin set state=APPLY-ON;
edit database pngfin set state=TRANSPORT-ON;

=====================================
DATAGUARD BASIC COMMANDS
====================================
show database dngfib recvqentries;
show database dngfib topwaitevents;
show database dngfib InconsistentProperties;
show database pngcapp InconsistentProperties;




CPS), Cheque Truncation System (CTS)
clirec
infoware, Eash Cash

\\10.234.18.30\f$\
edit database iconcept set state=TRANSPORT-OFF;

edit database pngrdbox set state=TRANSPORT-OFF;

edit database dngitms set state=APPLY-ON;

- Host/IP : 10.171.174.6

- Database name: GCMS

- Userid: gcms

- password: CHLC9Jqf5s9FRARLF6t8yeogdKIxGB0ImrNnjV1AHjc=

edit database dngfin set state=APPLY-OFF;