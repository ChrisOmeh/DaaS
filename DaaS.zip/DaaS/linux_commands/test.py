import json
js = {
    "_id": 1,
    "name": { "first" : "John", "last" : "Backus" },
    "contribs": [ "Fortran", "ALGOL", "Backus-Naur Form", "FP" ],
    "awards": [
      {
        "award": "W.W. McDowell Award",
        "year": 1967,
        "by": "IEEE Computer Society"
      }, {
        "award": "Draper Prize",
        "year": 1993,
        "by": "National Academy of Engineering"
      }
    ]
  }

print(js["contribs"][0])

with open("json_file.json", 'w') as file:
  json.dump(js, file, indent=4)

with open("json_file.json", 'r') as bson_file:
  bs = json.load(bson_file)
print(type(bs))
print(bs)
