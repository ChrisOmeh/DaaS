
fibonacci_cache = {}
def fibonacci_memo(input_value):
    if input_value in fibonacci_cache:
        return fibonacci_cache[input_value]
    if input_value == 1:
            value = 1
    elif input_value == 2:
            value = 1
    elif input_value > 2:           
            value =  fibonacci_memo(input_value -1) + fibonacci_memo(input_value -2)
    fibonacci_cache[input_value] = value
    return value

# USING FUNCTOOLS MODULE
from functools import lru_cache

@lru_cache(maxsize = 1000)
def fibonacci(input_value):
    if input_value == 1:
        return 1
    elif input_value == 2:
        return 1
    elif input_value > 2:
        value = fibonacci(input_value-1) + fibonacci(input_value-2)
        return value

if __name__ == "__main__":
    for i in range(1,101):
        #print(f"The fibonacci of {i} is: {fibonacci_memo(i)}") #Uncomment to use this method
        print(f"The fibonacci of {i} is: {fibonacci(i)}")


