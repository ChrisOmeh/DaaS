from pymongo import MongoClient

# Requires the PyMongo package.
# https://api.mongodb.com/python/current

try:
    client = MongoClient('mongodb+srv://m001-student:m001-mongodb-basics@sandbox.dptwmxc.mongodb.net/Sandbox')
    filter={
        'relationships.0.person.first_name': 'Mark', 
        'relationships.0.title': {
            '$regex': 'CEO'
        }
    }
    project={
        'name': 1
    }

    result = client['sample_training']['companies'].find(
    filter=filter,
    projection=project
    )
except client.error as e:
    print(f"The following error was encountered {e}")
    