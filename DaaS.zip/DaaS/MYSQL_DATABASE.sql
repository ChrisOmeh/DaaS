show databases;
show slave status;
SELECT User FROM mysql.user;

show slave status;
select @@max_allowed_packet;
show master status;  pos:40,765,564,327,058,678
SHOW REPLICA STATUS\G;
show slave status\G;
start slave;
SLAVE STOP;
SLAVE START;
stop slave;

SELECT variable_value
FROM information_schema.global_status
WHERE variable_name='SLAVE_RUNNING';

SHOW SLAVE STATUS '\G';
SELECT @@server_id;
\! clear
/*
DR CONFIG FILE
--[mysqld]
datadir=/u01/mysql
socket=/var/lib/mysql/mysql.sock
log-error=/u02/logs/mysqld.log
pid-file=/run/mysqld/mysqld.pid
server-id=200
relay-log=/u02/logs/yngmysql01-relay.log
log_bin=/u02/logs/mysql-bin.log
gtid_mode=ON
enforce-gtid-consistency=ON
log-replica-updates=ON
skip-replica-start=ON
/*

select user from mysql.user were user='A247589';
use stanbic_cms
go
select * from wp_ahm_assets;
ALTER USER 'user_name'@'host' ACCOUNT LOCK;
ALTER USER 'user_name'@'host' ACCOUNT UNLOCK;
ALTER USER 'A236247'@'%' ACCOUNT LOCK;
ALTER USER 'EA247589T1'@'%' ACCOUNT LOCK PASSWORD EXPIRE;
SELECT Host,User,account_locked,password_expired,password_last_changed FROM mysql.user WHERE USER='A246458';

SELECT Host,User,account_locked,password_expired,password_last_changed FROM mysql.user WHERE USER in ('sysdba',
'A236247',
'A247589',
'A247593',
'A251988');


/*
--===================
--MYSQL DATABASE
--===================
10.234.203.217

user - mysql 

password - qwer1234

mysql -u root -p

STanbic_1234#

create user 'sysdba'@'%' identified by 'SYSdba1234#';

create user 'A246458'@'%' identified by 'SYSdba1234#';
GRANT all ON *.* TO 'A246458'@'%';
GRANT ALL PRIVILEGES ON *.* TO 'A246458'@'%';
GRANT USAGE ON *.* TO 'A246458'@'%';

ALTER USER 'A246458'@'%' IDENTIFIED BY 'SYSdba1234#';

GRANT all ON *.* TO 'sysdba'@'%';
GRANT ALL PRIVILEGES ON *.* TO 'sysdba'@'%';

 SELECT User FROM mysql.user;
GRANT USAGE ON *.* TO 'POWERBIMIS'@'%';
GRANT SELECT ON activity.* TO 'POWERBIMIS'@'%';
GRANT SELECT ON auth.* TO 'POWERBIMIS'@'%';
GRANT SELECT ON notification.* TO 'POWERBIMIS'@'%';
GRANT SELECT ON mortgage_application.* TO 'POWERBIMIS'@'%';
GRANT SELECT ON mortgage_calculator.* TO 'POWERBIMIS'@'%';
create user 'POWERBIMIS'@'%' identified by 'STanbic_1234#';

GRANT SELECT ON *.* TO 'POWERBIMIS'@'%';

 SELECT User FROM mysql.user;
 
 SHOW GRANTS FOR 'MobileandInternet_User'@'%';
  SHOW GRANTS FOR 'POWERBIMIS'@'%';
  SHOW GRANTS FOR 'root'@'localhost';
 SHOW GRANTS FOR 'sysdba'@'%';
 SHOW GRANTS FOR 'MobileandInternet_User'@'%';
 
 grant alter,create,delete,drop,index,insert,select,update,trigger,alter routine,
create routine, execute, create temporary tables ON *.* TO 'MobileandInternet_User'@'%';

# PATH TO CONFIG FILE
/etc/my.cnf.d
client.cnf  mysql-default-authentication-plugin.cnf  mysql-server.cnf
 
 show variables like 'expire_logs_days';
 show variables like 'binlog_expire_logs_auto_purge';
 show binlog events in 'mysql-bin.000002';
  select @@super_read_only,@@read_only;
  https://www.percona.com/blog/mysql-replication-how-to-deal-with-the-got-fatal-error-1236-or-my-013114-error/
  
  show binary logs;
 
 */
 
 /* ERROR ON MYSQL
 I have setup GTID replication between two mysql 8 databases
they are for a Powerdns Setup

When i make changes on the master
I can only get one transaction to replicate then i am presented this error.

Coordinator stopped because there were error(s) in the worker(s). The most recent failure being: Worker 1 failed executing transaction ‘0b5041c0-8e71-11ec-a064-00155d14ef09:5’ at master log binlog.000001, end_log_pos 2500. See error log and/or performance_schema.replication_applier_status_by_worker table for more details about this failure or others, if any.

If i run these commands

On master database:

mysql> reset master;

On slave database:

mysql> stop slave;

mysql> reset slave;

mysql> reset master;

mysql> start slave;

This clears the error and i am able to sync one more entry then i get presented with the above error again.
I used this guide to set it up
maybe i missed something in the setup.

mysql> stop slave;
mysql> set sql_log_bin = off;
mysql> set gtid_next='bebd7b80-9904-11ec-99e9-525400adb547:116979494';
mysql> begin;commit;
mysql> set gtid_next='automatic';
mysql> set sql_log_bin = on;
mysql> start slave;


====================
backup and restore
====================
mysqldump -u sysdba -p activity api_log --verbose=FALSE > aapi_log.sql --set-gtid-purged=OFF
mysql -u sysdba -p -D activity < aapi_log.sql
*/
 