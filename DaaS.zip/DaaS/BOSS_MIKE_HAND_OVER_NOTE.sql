10.234.17.93  -- p7Tz@t6Wx(7b

10.234.178.82 -- =U6/-}'NF7bgS(~


u|BR42dc == 10.234.19.118



L'fe2iaY == 10.234.179.142


chmod u=rwx,g=rx,o=rx libclntsh.so.19.1  


chmod u=rwx,g=rx,o=rx libclntshcore.so.19.1

13578970059367

SQL> recover database using backup controlfile until cancel;
ORA-00279: change 13578970059367 generated at 11/01/2022 04:39:34 needed for
thread 1
ORA-00289: suggestion : +FRA
ORA-00280: change 13578970059367 for thread 1 is in sequence #85190


DBCC CHECKDB ('database_name');
GO
ALTER DATABASE database_name SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
GO
DBCC CHECKDB ('database_name', REPAIR_REBUILD);
GO
ALTER DATABASE database_name SET MULTI_USER;
GO

X6hV0*p%

ctma -- 
10.234.203.10 -- c:9JKa:V
10.234.203.11 -- LZrW1P.a


Quick Services -- AA-491571  --  AA-491571 -- AA-491578

1l


alter system set pga_aggregate_target=16G scope=both sid='*';


alter system set pga_aggregate_limit=96G scope=both sid='*';

98304M

pga_aggregate_limit  

CAUTION: To avoid delays in resolution, please make sure you upload AWR report (1hour interval) of the ISSUE time or preferably TFA collection, option with "-srdc dbperf" covering the performance problem time on the next page.

REMINDER --- SHRINK OMNIFLOW DATABASE ON 18.29/30

/u01/app/19.0.0/grid/OPatch/opatchauto apply /u01/app/33509923

justification for SQL Server 
Db_owner
Ensure 'CHECK_POLICY' Option is set to 'ON' for All SQL Authenticated Logins
Sysadmin / serveradmin

TRUNCATE TABLE ODS_DBA.STG_ODS_INTEREST_DETAILS;


A169189

----------------------EPO Database ------------------------

https://kc.mcafee.com/corporate/index?page=content&id=KB68961
https://kc.mcafee.com/corporate/index?page=content&id=KB76720

DELETE FROM OrionSchedulerTaskLogDetail WHERE (MessageDate < GETDATE() - 60)

-----------------------------------------------------------------------------------


[0:12 am, 29/12/2021] Damilare Stanbic: edM1ypv-GHz
[0:12 am, 29/12/2021] Damilare Stanbic: ea226150

EA204778 -- ^s3fC)5Q

INSERT INTO target_table (col1, col2, col3)
SELECT col1,
       col2,
       col3
FROM source_table
WHERE condition;
--------------------------------------------------------------------------------
SQL TUNING ADVISOR FOR SOL CONTEXT CHANGE (ADT)
 execute dbms_sqltune.accept_sql_profile(task_name => 'staName28221',
            task_owner => 'A204778', replace => TRUE);
			
Index Finding (see explain plans section below)
--------------------------------------------------
  The execution plan of this statement can be improved by creating one or more
  indices.

  Recommendation (estimated benefit: 93.94%)
  ------------------------------------------
  - Consider running the Access Advisor to improve the physical schema design
    or creating the recommended index.
    create index TBAADM.IDX$$_C4D870001 on
    TBAADM.AUDIT_TABLE("AUTH_ID","AUDIT_SOL_ID","TABLE_NAME");

  Rationale
  ---------
    Creating the recommended indices significantly improves the execution plan
    of this statement. However, it might be preferable to run "Access Advisor"
    using a representative SQL workload as opposed to a single statement. This
    will allow to get comprehensive index recommendations which takes into
    account index maintenance overhead and additional space consumption.

------------------------------------------------------------------------------




----------------------------------------------------------------------------
1[+3}!$z,P

Mongodb log rotate

db.adminCommand( { logRotate : 1 } )

attributes volume clear hidden

q@[O7DhTp<NTaoW
[[

10.234.18.76 -- RflYilPq/@Xu8Yo

10.234.178.82 -- NWv-0Svk
SQLSVRCONS - b!>yjVrMH8-:

b!>yjVrMH8-:

STanbic__1234#

http://browserscript/default.pac

2082616593


SELECT 'GRANT SELECT ON "' + TABLE_SCHEMA + '"."' + TABLE_NAME + '" TO "SBICZA01\SA35483252"' FROM information_schema.tables



realtime.dbo.term and realtime.dbo.atm_config


GRANT SELECT ON "dbo"."term" TO "SA35483252"

GRANT SELECT ON "dbo"."atm_config" TO "SA35483252"


CREATE USER A242749
  IDENTIFIED BY STanbic__1234#
  DEFAULT TABLESPACE STANBICUSERS_TBLSPC
  TEMPORARY TABLESPACE TEMP
  PROFILE STAFF_PROFILE
  ACCOUNT UNLOCK;
  -- 2 System Privileges for A242749 
  GRANT CREATE SESSION TO A242749;
  GRANT SELECT ANY TABLE TO A242749;
  GRANT SELECT ANY DICTIONARY TO A242749;


https://stanbic.na1.echosign.com/public/login
USERNAME : ITInfrastructure-Echosign@stanbicibtc.com
PASSWORD : @St@nbic12345@
vw|~jLu5K4S+$Fc
mongodbb

use admin
db.createUser(
   {
     user: "A226547",
     pwd: "STanbic_1234#",
      roles: [
    { role: "read", db: "stanbic" } ]
   }
)


A210006

use admin
db.createUser(
   {
     user: "bluemalluser",
     pwd: "STanbic_1234#",
      roles: [
    { role: "readWrite", db: "bluemall" } ]
   }
)


use admin
db.createUser(
   {
     user: "appdynamicsuser",
     pwd: "STanbic_1234#",
      roles: [
    { role: "clusterMonitor", db: "admin"}, {role: "readAnyDatabase", db: "admin"} ]
   }
)

A236273


use admin
db.dropUser("A177909")


use admin
db.dropUser("A224435")


use stanbic
db.createRole(
   {
     role: "CreateViewSupport",
     privileges: [
       { resource: { db: "stanbic", collection: ""}, actions: [ "createCollection" ] }
     ],
     roles: []
   }
)

use stanbic
db.grantRolesToUser(
  "support",
  [
    { role: "CreateViewSupport", db: "stanbic" }
  ]
)

use stanbic
db.grantPrivilegesToRole(
    "CreateViewSupport",
    [
        { resource: { db: "stanbic", collection: "UniqueTransactedUsersandDeviceID" }, actions: [ "update", ] }
    ]
)

use stanbic
db.grantPrivilegesToRole(
    "CreateViewSupport",
    [
        { resource: { db: "stanbic", collection: "UniqueTransactedUsersandDeviceID" }, actions: [ "collMod","find" ] }
    ]
)

db.createRole(
   {
     role: "foobarRole",
     privileges: [
       { resource: { db: "exampleDb", collection: "bar" }, actions: [ "createCollection", "createIndex", "find", "insert", "update" ] }
     ],
     roles: []
   }
)

db.changeUserPassword("A224435", "Stanbic_123#")

restore archivelog from TIME 'SYSDATE-40';

restore archivelog all;

LIST BACKUP OF ARCHIVELOG ALL;


RUN {
ALLOCATE CHANNEL CH00 TYPE 'SBT_TAPE' PARMS 'SBT_LIBRARY=/usr/openv/netbackup/bin/libobk.so64';
SEND 'NB_ORA_SERV=PNGNTBKUP01, NB_ORA_CLIENT=pngoda5';
restore archivelog all;
RELEASE CHANNEL ch0;
}

using chmod 755 libobk.so64

ALLOCATE CHANNEL CH00 TYPE 'SBT_TAPE' PARMS 'SBT_LIBRARY=/usr/openv/netbackup/bin/libobk.so64.1';


edit database pngfin set state=TRANSPORT-ON;
edit database pngaud set state=TRANSPORT-ON;
edit database pngcog set state=TRANSPORT-ON;
edit database pngcem set state=TRANSPORT-ON;
edit database pngctm set state=TRANSPORT-ON;
edit database pngdtr set state=TRANSPORT-ON;
edit database pngesb set state=TRANSPORT-ON;
edit database pngitms set state=TRANSPORT-ON;
edit database pngabank set state=TRANSPORT-ON;
edit database pngrdbox set state=TRANSPORT-ON;
edit database pngfib set state=TRANSPORT-ON;
edit database pngpas set state=TRANSPORT-ON;
edit database iconcept set state=TRANSPORT-ON;
edit database pngcapp set state=TRANSPORT-ON;
edit database iconcept set state=TRANSPORT-ON;

edit database dngfin set state=APPLY-ON;
edit database dngrdbox set state=APPLY-ON;
edit database dngfib set state=APPLY-ON;
edit database dngabank set state=APPLY-ON;
edit database dngaud set state=APPLY-ON;
edit database dngcem set state=APPLY-ON;
edit database dngcog set state=APPLY-ON;
edit database dngctm set state=APPLY-ON;
edit database dconcept set state=APPLY-ON;
edit database dngdtr set state=APPLY-ON;
edit database dngesb set state=APPLY-ON;
edit database dngitms set state=APPLY-ON;
edit database dngpas set state=APPLY-ON;
edit database dngcfm set state=APPLY-ON;
edit database dngcapp set state=APPLY-ON;


dgmgrl sys@pngfin


dgmgrl sys/qwer1234@pngfib

dgmgrl sys/qwer1234@pngpas

dgmgrl sys/qwer1234@pngesb

dgmgrl sys/qwer1234@pngrdbox

dgmgrl sys/qwer1234@pngfin

dgmgrl sys/qwer1234@pngitms

dgmgrl sys/qwer1234@pngaud

dgmgrl sys/qwer1234@pngcem

dgmgrl sys/qwer1234@pngcog

dgmgrl sys/qwer1234@pngctm

dgmgrl sys/qwer1234@pngdtr

dgmgrl sys/qwer1234@pngabank

dgmgrl sys/SQwer_1234#@pngcfm

dgmgrl sys/SQwer_1234#@iconcept

dgmgrl sys/SQwer_1234#@pngcapp

dgmgrl sys/qwer1234@pngfib

convert database dngitms to physical standby;

convert database dngdtr to physical standby;

convert database dngfib to physical standby;

convert database dngrdbox to physical standby;

convert database dngcapp to physical standby;

convert database dngfin to physical standby;

convert database dngcfm to physical standby;
-----------------------------------------------------

convert database dngcfm to snapshot standby;

convert database dngdtr to snapshot standby;

convert database dngfin to snapshot standby;

convert database dngrdbox to snapshot standby;

convert database dngfib to snapshot standby;

convert database dngitms to snapshot standby;

convert database dngcapp to snapshot standby;

10.234.203.141 : uZdf$4>v<BGFS.L

db.notificationgroup.copyTo("notificationgroup2backup")

mongodump  --host 10.234.18.143 --port 27017 -u sysdba --authenticationDatabase admin --db stanbic --collection notificationgroup --out "/home/mongodbbackup"

mongo -u sysdba --authenticationDatabase admin

notificationgroup


    db.notificationgroup.drop()


APRil__2021

|QP,4rU#E*!iS+l

[8:53 AM] Mohammed, Surajudeen
    

(cNvd*>8E~4MiL/

EA169325

bg3!sfotyCh

insert into SB_INTEGRATION_REQ SELECT *
  FROM [sbprodcab].[dbo].[SB_INTEGRATION_REQ_BKP_290621] where REQ_DATE='27-jun-2021'


delete [sbprodcab].[dbo].[SB_INTEGRATION_REQ_BKP_290621] where REQ_DATE='27-jun-2021'


	
From the incident trace file, the following is seen

**************** Dumping Resource Limits(s/h) *****************
data seg size UNLIMITED/UNLIMITED
max locked memory 64 KB/64 KB ========================>>
max memory size UNLIMITED/UNLIMITED
virtual memory UNLIMITED/UNLIMITED


System parameters with non-default values:
processes = 6144 ====================>>>
sessions = 9248
cpu_count = 16
cpu_min_count = "16"
sga_max_size = 192G
nls_language = "AMERICAN"
nls_territory = "AMERICA"
sga_target = 192G
control_files = "+DATA/PNGRDBOX/CONTROLFILE/current.987.1049283295"


Minimally for the value of processes it is 6144 * 3MB (or 5MB if RAC) . Meaning pga_aggregate_target should be set to at least that value which is 18432MB and 30720MB respectively

However your pga_aggregate_target=17179869184


1) Either reduce the process parameter OR increase pga_aggregate_target

2) set max locked memory to unlimited

winrs –r:PNGDATASTORE02.ng.sbicdirectory.com cmd.exe

Enter-PSSession PNGDATASTORE02.ng.sbicdirectory.com 

winrs -r:PNGDATASTORE02.ng.sbicdirectory.com -u:wintelassist -p:(cNvd*>8E~4MiL/ cmd.exe

winrs /r:PNGDATASTORE02.ng.sbicdirectory.com /u:ntnige\datastoredsx /p:Stanbic1234 cmd.exe

winrs –r:10.234.17.15 cmd.exe

[5/21 3:07 PM] Oduba, Ernest
    
	
	use databasname
	go
	select log_reuse_wait_desc
	from sys.databases where 
	database_id = DB_ID()

1. Enterprise Manager Cloud Control URL: https://pngoraemcc01v.ng.sbicdirectory.com:7803/em
2. Admin Server URL: https://pngoraemcc01v.ng.sbicdirectory.com:7102/console


[3:58 PM] Oduba, Ernest
    Username:ITInfrastructure-Echosign@stanbicibtc.com
Password:@St@nbic12345



10.234.171.102 -- t+6k:MD(

10.234.18.182  -- 

SETSPN -L NTNIGE\SQLSVRCONS

EA204778 : Qcafrwhi3\d


LOG_ARCHIVE_DEST_2=
 'SERVICE=chicago ASYNC
  VALID_FOR=(ONLINE_LOGFILES,PRIMARY_ROLE) 
  DB_UNIQUE_NAME=chicago'
}
insert into SB_INTEGRATION_REQ select * from SB_INTEGRATION_REQ_BKP_290621 where REQ_DATE >='08-jun-2021'

odacli-adm set-credential --password SQwer_1234# --username oda-admin


Remedy
select last_copied_file, last_restored_file, last_copied_date, last_restored_date, last_restored_latency
from msdb.dbo.log_shipping_monitor_secondary where secondary_database='ARSystem_rep'


ORA-00132: syntax error or unresolved network name ' yngcordb-scan:1521'

RD0KoK@5O7

cmta 10.234.203.10 - uW_gd5xR
cmta 10.234.203.11 - uX-y7pZ[

./em13500_linux64.bin


srvctl start asm -node pngrhev01

srvctl status asm -node pngrhev01

dism /online /cleanup-image /checkhealth


dism /online /cleanup-image /restorehealth

sfc /scannow

expdp attach=SYS_IMPORT_SCHEMA_01

impdp attach=SYS_IMPORT_SCHEMA_01

"SYS"."SYS_IMPORT_SCHEMA_01":
Netbackup Master DR  wintelassist - +DXJIqf9rSysiI:

bplist -S PNGNIBKUP02v -C yngrhev01.ng.sbicdirectory.com -t 4 -l -redbox.R /

Set DBID=3998855182

/usr/openv/netbackup/bin/bplist -S PNGNIBKUP02v -C 10.234.204.10 -t 4 -l -redbox.R /

/usr/openv/netbackup/bin/bplist -S PNGNIBKUP02v -C yngrhev01.ng.sbicdirectory.com -t 4 -l -redbox.R /

/usr/openv/netbackup/bin/bplist -S PNGNIBKUP02v -C pngrhev01.ng.sbicdirectory.com -t 4 -l -redbox.R /

/usr/openv/netbackup/bin/bplist -S PNGNIBKUP02v -C pngrhev02.ng.sbicdirectory.com -t 4 -l -redbox.R /

yngrhev01.ng.sbicdirectory.com


kernel.sem = 1024       70000   1024    256
kernel.sem_next_id = -1

sysctl -w kernel.sem="1024 70000 1024 256"

/ctrl_dPNGFIN_ufovr8shf_s9720_p1_t1068790319


/ctrl_dPNGFIN_ut10aha67_s2977_p1_t1084795079


/ctrl_dPNGFIN_u5a0d0dtr_s4266_p1_t1087387579

RUN {
	ALLOCATE CHANNEL t1 TYPE sbt;
	SEND 'NB_ORA_CLIENT=10.234.204.10';
	RESTORE SPFILE FROM 'handle_of_spfile_backup';
	RELEASE CHANNEL t1;
}

run {
allocate channel c1 type 'sbt_tape';
send 'NB_ORA_SERV=10.234.17.202, NB_ORA_CLIENT=pngoda5';
restore archivelog from sequence 758 thread=2;
release channel c1;
}


run {
allocate channel c1 type 'sbt_tape';
send 'NB_ORA_SERV=10.234.17.202, NB_ORA_CLIENT=pngoda5';
restore archivelog from sequence 10435 thread=1;
release channel c1;
}
10435


run {
allocate channel c1 type 'sbt_tape';
send 'NB_ORA_SERV=PNGNIBKUP02v, NB_ORA_CLIENT=yngrhev01.ng.sbicdirectory.com';
restore controlfile to '/tmp/cntrl.bak' from 'cntrl_624_1_770006541';
release channel c1;
}

run {
allocate channel c1 type 'sbt_tape';
send 'NB_ORA_SERV=PNGNIBKUP02v, NB_ORA_CLIENT=yngrhev01.ng.sbicdirectory.com';
restore primary controlfile from '/ctrl_dPNGFIN_ucu00ir3v_s15774_p1_t1074359423';
release channel c1;
}

---------------restore Finacle 25th October 2021 ----
run {
allocate channel c1 type 'sbt_tape';
send 'NB_ORA_SERV=PNGNIBKUP02v, NB_ORA_CLIENT=pngrhev02.ng.sbicdirectory.com';
restore controlfile from '/ctrl_dPNGFIN_ut10aha67_s2977_p1_t1084795079';
release channel c1;
}

after restoring control file, mount database

edit the restore database file restoreuatpngfin.full
the run the command below 

nohup rman target / @/flashback/expdp/restoreuatpngfin.full log=/flashback/expdp//restoreuatpngfin250ct2021.ful.log &

------------------restore 25th October 2021 -----------------------------------------------------


------------------------restore finacle oct 31 2021 ------------------------------------------
/ctrl_dPNGFIN_u5a0d0dtr_s4266_p1_t1087387579

/ctrl_dPNGFIN_u5a0d0dtr_s4266_p1_t1087387579

run {
allocate channel c1 type 'sbt_tape';
send 'NB_ORA_SERV=PNGNIBKUP02v, NB_ORA_CLIENT=pngrhev02.ng.sbicdirectory.com';
restore controlfile from '/ctrl_dPNGFIN_u5a0d0dtr_s4266_p1_t1087387579';
release channel c1;
}

after restoring control file, mount database

edit the restore database file restoreuatpngfin.full
the run the command below 

nohup rman target / @/flashback/expdp/restoreuatpngfin.full log=/flashback/expdp//restoreuatpngfinEOM0ct2021.ful.log &

switch database to copy;

nohup rman target / @/flashback/expdp/recoverpngfinuat.full log=/flashback/expdp//recoveruatpngfinOCT2021EOM.ful.log &

nohup rman target / @/flashback/expdp/recoverungpngfinseq.full log=/flashback/expdp//recoveruatpngfinseqOCT2021EOM.ful.log &

-----------------------------------------------------------------------------------------------------------------

-------------------------restore Finacle NOV 1 2021 ----------------------------------------------
/ctrl_dPNGFIN_u6e0d2vop_s4302_p1_t1087471385

run {
allocate channel c1 type 'sbt_tape';
send 'NB_ORA_SERV=PNGNIBKUP02v, NB_ORA_CLIENT=pngrhev02.ng.sbicdirectory.com';
restore controlfile from '/ctrl_dPNGFIN_u6e0d2vop_s4302_p1_t1087471385';
release channel c1;
}

after restoring control file, mount database

edit the restore database file restoreuatpngfin.full
the run the command below 

nohup rman target / @/flashback/expdp/restoreuatpngfin.full log=/flashback/expdp//restoreuatpngfinBODNOV2021.ful.log &

switch database to copy;

nohup rman target / @/flashback/expdp/restoreallarchivelogungpngfin.full log=/flashback/expdp//restoreallarchivelogungpngfin24NOV2021.ful.log &

nohup rman target / @/flashback/expdp/recoverpngfinuat.full log=/flashback/expdp//recoveruatpngfinNOV2021BOD2.ful.log &

nohup rman target / @/flashback/expdp/recoverungpngfinseq.full log=/flashback/expdp//recoveruatpngfinseqNOV2021BOD.ful.log &
recoverungpngfinseq.full


RUN {
    SET NEWNAME FOR DATAFILE 3 to NEW;
    RESTORE DATAFILE 3;
    SWITCH DATAFILE 3;
    RECOVER DATAFILE 3;
}

bk_dPNGFIN_ua40cu746_s3396_p1_t1087315078.


run {
allocate channel c1 type 'sbt_tape';
send 'NB_ORA_SERV=PNGNIBKUP02v, NB_ORA_CLIENT=pngrhev02.ng.sbicdirectory.com';
SET NEWNAME FOR DATAFILE 1 to NEW;
restore datafile 1;
SWITCH DATAFILE 1;
RECOVER DATAFILE 1;
release channel c1;
}

-----------------------------bacnkup FInacle EOM FEB 2022 -----------------------------------------------------

finaclebackup.full

nohup rman target / @/flashback/rmanbkp/daily/pngfin/finaclebackup.full log=/flashback/expdp//backupFINACLEFUllDB01MAR2022.ful.log &

-----------------------------------------------------------------------------------------------------------------


----------------------------------backup Redbox EOM Feb 2022 ------------------------------------------------------

nohup rman target / @/flashback/rmanbkp/daily/pngrdbox/redboxdbbackup.full log=/flashback/expdp//backupREDBOXFUllDB05MAR2022.ful.log &

--------------------------------------------------------------------------------------------------------------------

-----------------------------bacnkup FInacle EOM MAR 2022 -----------------------------------------------------

finaclebackup.full

nohup rman target / @/flashback/rmanbkp/daily/pngfin/finaclebackup.full log=/flashback/expdp//backupFINACLEFUllDB31MAR2022.ful.log &

Incremental BACKUP

nohup rman target / @/flashback/rmanbkp/daily/pngfin/finaclebackup.incrmt log=/flashback/expdp//backupFINACLEINCRMTDB01APR2022.ful.log &
-----------------------------------------------------------------------------------------------------------------

-----------------------------bacnkup FInacle EOM APR 2022 -----------------------------------------------------

finaclebackup.full

nohup rman target / @/flashback/rmanbkp/daily/pngfin/finaclebackup.full log=/flashback/expdp//backupFINACLEFUllDB01MAY2022.ful.log &

-----------------------------------------------------------------------------------------------------------------

-----------------------------bacnkup FInacle EOM MAY 2022 -----------------------------------------------------

finaclebackup.full

nohup rman target / @/flashback/rmanbkp/daily/pngfin/finaclebackup.full log=/flashback/expdp//backupFINACLEFUllDB31MAY2022.ful.log &

Incremental BACKUP

nohup rman target / @/flashback/rmanbkp/daily/pngfin/finaclebackup.incrmt log=/flashback/expdp//backupFINACLEINCRMTDB01JUN2022.ful.log &

-----------------------------------------------------------------------------------------------------------------


-----------------------------backup FInacle EOM JUNE 2022 -----------------------------------------------------

finaclebackup.full

nohup rman target / @/flashback/rmanbkp/daily/pngfin/finaclebackup.full log=/flashback/expdp//backupFINACLEFUllDB30JUN2022.ful.log &

Incremental BACKUP

nohup rman target / @/flashback/rmanbkp/daily/pngfin/finaclebackup.incrmt log=/flashback/expdp//backupFINACLEINCRMTDB01JUL2022.ful.log &

-----------------------------------------------------------------------------------------------------------------


-----------------------------backup FInacle EOM JULY 2022 -----------------------------------------------------

finaclebackup.full

nohup rman target / @/flashback/rmanbkp/daily/pngfin/finaclebackup.full log=/flashback/expdp//backupFINACLEFUllDB31JUL2022.ful.log &

Incremental BACKUP

nohup rman target / @/flashback/rmanbkp/daily/pngfin/finaclebackup.incrmt log=/flashback/expdp//backupFINACLEINCRMTDB01AUG2022.ful.log &

-----------------------------------------------------------------------------------------------------------------


-----------------------------backup FInacle EOM AUG 2022 -----------------------------------------------------

finaclebackup.full

nohup rman target / @/flashback/rmanbkp/daily/pngfin/finaclebackup.full log=/flashback/expdp//backupFINACLEFUllDB01SEP2022.ful.log &

Incremental BACKUP

nohup rman target / @/flashback/rmanbkp/daily/pngfin/finaclebackup.incrmt log=/flashback/expdp//backupFINACLEINCRMTDB01SEP2022.ful.log &

-----------------------------------------------------------------------------------------------------------------

-----------------------------backup FInacle EOM NOV 2022 -----------------------------------------------------

finaclebackup.full

nohup rman target / @/flashback/rmanbkp/daily/pngfin/finaclebackup.full log=/flashback/expdp//backupFINACLEFUllDB30SEP2022.ful.log &

Incremental BACKUP

nohup rman target / @/flashback/rmanbkp/daily/pngfin/finaclebackup.incrmt log=/flashback/expdp//backupFINACLEINCRMTDB01OCT2022.ful.log &

-----------------------------------------------------------------------------------------------------------------


-----------------------------backup FInacle EOM OCT 2022 -----------------------------------------------------

finaclebackup.full

nohup rman target / @/flashback/rmanbkp/daily/pngfin/finaclebackup.full log=/flashback/expdp//backupFINACLEFUllDB31OCT2022.ful.log &

Incremental BACKUP

nohup rman target / @/flashback/rmanbkp/daily/pngfin/finaclebackup.incrmt log=/flashback/expdp//backupFINACLEINCRMTDB01NOV2022.ful.log &

-----------------------------------------------------------------------------------------------------------------

-----------------------------backup FInacle EOM NOV 2022 -----------------------------------------------------

finaclebackup.full

nohup rman target / @/flashback/rmanbkp/daily/pngfin/finaclebackup.full log=/flashback/expdp//backupFINACLEFUllDB30NOVT2022.ful.log &

Incremental BACKUP

nohup rman target / @/flashback/rmanbkp/daily/pngfin/finaclebackup.incrmt log=/flashback/expdp//backupFINACLEINCRMTDB01DEC2022.ful.log &

-----------------------------------------------------------------------------------------------------------------

-----------------------------backup FInacle EOY DEC 2022 -----------------------------------------------------

finaclebackup.full

nohup rman target / @/flashback/rmanbkp/daily/pngfin/finaclebackup.full log=/flashback/expdp//backupFINACLEFUllDB31DEC2022.ful.log &

Incremental BACKUP

nohup rman target / @/flashback/rmanbkp/daily/pngfin/finaclebackup.incrmt log=/flashback/expdp//backupFINACLEINCRMTDB01JAN2023.ful.log &

-----------------------------------------------------------------------------------------------------------------

-----------------------------backup FInacle EOM JAN 2023 -----------------------------------------------------

finaclebackup.full

nohup rman target / @/flashback/rmanbkp/daily/pngfin/finaclebackup.full log=/flashback/expdp//backupFINACLEFUllDB31JAN2023.ful.log &

Incremental BACKUP

nohup rman target / @/flashback/rmanbkp/daily/pngfin/finaclebackup.incrmt log=/flashback/expdp//backupFINACLEINCRMTDB01FEB2023.ful.log &

-----------------------------------------------------------------------------------------------------------------


-----------------------------backup FInacle EOM FEB 2023 -----------------------------------------------------

finaclebackup.full

nohup rman target / @/flashback/rmanbkp/daily/pngfin/finaclebackup.full log=/flashback/expdp//backupFINACLEFUllDB28FEB2023.ful.log &

Incremental BACKUP

nohup rman target / @/flashback/rmanbkp/daily/pngfin/finaclebackup.incrmt log=/flashback/expdp//backupFINACLEINCRMTDB01MAR2023.ful.log &

-----------------------------------------------------------------------------------------------------------------


----------------------------------backup Redbox EOM Mar 2022 ------------------------------------------------------

nohup rman target / @/flashback/rmanbkp/daily/pngrdbox/redboxdbbackup.full log=/flashback/expdp//backupREDBOXFUllDB04APR2022.ful.log &

--------------------------------------------------------------------------------------------------------------------

----------------------------------backup Redbox EOM APR 2022 ------------------------------------------------------

nohup rman target / @/flashback/rmanbkp/daily/pngrdbox/redboxdbbackup.full log=/flashback/expdp//backupREDBOXFUllDB02MAY2022.ful.log &

--------------------------------------------------------------------------------------------------------------------

----------------------------------backup Redbox EOM JUN 2022 ------------------------------------------------------

nohup rman target / @/flashback/rmanbkp/daily/pngrdbox/redboxdbbackup.full log=/flashback/expdp//backupREDBOXFUllDB05JUL2022.ful.log &

--------------------------------------------------------------------------------------------------------------------

----------------------------------backup Redbox EOM JUL 2022 ------------------------------------------------------

nohup rman target / @/flashback/rmanbkp/daily/pngrdbox/redboxdbbackup.full log=/flashback/expdp//backupREDBOXFUllDB17AUG2022.ful.log &

--------------------------------------------------------------------------------------------------------------------

----------------------------------backup Redbox EOM August 2022 ------------------------------------------------------

nohup rman target / @/flashback/rmanbkp/daily/pngrdbox/redboxdbbackup.full log=/flashback/expdp//backupREDBOXFUllDB06SEP2022.ful.log &

--------------------------------------------------------------------------------------------------------------------

----------------------------------backup Redbox Backup after maintenance August 2022 ------------------------------------------------------

nohup rman target / @/flashback/rmanbkp/daily/pngrdbox/redboxdbbackup.full log=/flashback/expdp//backupREDBOXFUllDB14SEP2022.ful.log &

--------------------------------------------------------------------------------------------------------------------

----------------------------------backup Redbox EOM August 2022 ------------------------------------------------------

nohup rman target / @/flashback/rmanbkp/daily/pngrdbox/redboxdbbackup.full log=/flashback/expdp//backupREDBOXFUllDB04OCT2022.ful.log &

--------------------------------------------------------------------------------------------------------------------


----------------------------------backup Redbox EOM OCTOBER 2022 ------------------------------------------------------

nohup rman target / @/flashback/rmanbkp/daily/pngrdbox/redboxdbbackup.full log=/flashback/expdp//backupREDBOXFUllDB04NOV2022.ful.log &

--------------------------------------------------------------------------------------------------------------------


----------------------------------backup Redbox EOM NOVEMBER 2022 ------------------------------------------------------

nohup rman target / @/flashback/rmanbkp/daily/pngrdbox/redboxdbbackup.full log=/flashback/expdp//backupREDBOXFUllDB09DEC2022.ful.log &

--------------------------------------------------------------------------------------------------------------------


----------------------------------backup Redbox EOY DEC 2022 ------------------------------------------------------

nohup rman target / @/flashback/rmanbkp/daily/pngrdbox/redboxdbbackup.full log=/flashback/expdp//backupREDBOXFUllDB04JAN2023.ful.log &

--------------------------------------------------------------------------------------------------------------------


----------------------------------backup Redbox EOM JAN 2023 ------------------------------------------------------

nohup rman target / @/flashback/rmanbkp/daily/pngrdbox/redboxdbbackup.full log=/flashback/expdp//backupREDBOXFUllDB07FEB2023.ful.log &

--------------------------------------------------------------------------------------------------------------------

----------------------------------backup Redbox After Purge Feb 2023 ------------------------------------------------------

nohup rman target / @/flashback/rmanbkp/daily/pngrdbox/redboxdbbackup.full log=/flashback/expdp//backupREDBOXFUllDB14FEB2023.ful.log &

--------------------------------------------------------------------------------------------------------------------


----------------------------------backup Redbox FEB EOM 2023 ------------------------------------------------------

nohup rman target / @/flashback/rmanbkp/daily/pngrdbox/redboxdbbackup.full log=/flashback/expdp//backupREDBOXFUllDB08MAR2023.ful.log &

--------------------------------------------------------------------------------------------------------------------


----------------------------------backup PNGFIB EOM Mar 2022 ------------------------------------------------------

nohup rman target / @/flashback/rmanbkp/daily/pngfib/pngfibdbbackup.full log=/flashback/expdp//backupPNGFIBFUllDB05APR2022.ful.log &

--------------------------------------------------------------------------------------------------------------------

----------------------------------backup PNGFIB EOM JUN 2022 ------------------------------------------------------

nohup rman target / @/flashback/rmanbkp/daily/pngfib/pngfibdbbackup.full log=/flashback/expdp//backupPNGFIBFUllDB04JUL2022.ful.log &

--------------------------------------------------------------------------------------------------------------------

----------------------------------backup PNGFIB EOM JUL 2022 ------------------------------------------------------

nohup rman target / @/flashback/rmanbkp/daily/pngfib/pngfibdbbackup.full log=/flashback/expdp//backupPNGFIBFUllDB18AUG2022.ful.log &

--------------------------------------------------------------------------------------------------------------------

----------------------------------backup PNGFIB EOM AUG 2022 ------------------------------------------------------

nohup rman target / @/flashback/rmanbkp/daily/pngfib/pngfibdbbackup.full log=/flashback/expdp//backupPNGFIBFUllDB05SEP2022.ful.log &

--------------------------------------------------------------------------------------------------------------------

----------------------------------backup PNGFIB EOM NOV 2022 ------------------------------------------------------

nohup rman target / @/flashback/rmanbkp/daily/pngfib/pngfibdbbackup.full log=/flashback/expdp//backupPNGFIBFUllDB03OCT2022.ful.log &

--------------------------------------------------------------------------------------------------------------------

----------------------------------backup PNGFIB EOM OCT 2022 ------------------------------------------------------

nohup rman target / @/flashback/rmanbkp/daily/pngfib/pngfibdbbackup.full log=/flashback/expdp//backupPNGFIBFUllDB05NOV2022.ful.log &

--------------------------------------------------------------------------------------------------------------------

----------------------------------backup PNGFIB EOM NOV 2022 ------------------------------------------------------

nohup rman target / @/flashback/rmanbkp/daily/pngfib/pngfibdbbackup.full log=/flashback/expdp//backupPNGFIBFUllDB07DEC2022.ful.log &

--------------------------------------------------------------------------------------------------------------------

----------------------------------backup PNGFIB 24 DEC 2022 AFTER TABLE MAINTENANCE  ------------------------------------------------------

nohup rman target / @/flashback/rmanbkp/daily/pngfib/pngfibdbbackup.full log=/flashback/expdp//backupPNGFIBFUllDB24DEC2022.ful.log &

--------------------------------------------------------------------------------------------------------------------

----------------------------------backup PNGFIB 03 JAN 2023 AFTER TABLE MAINTENANCE  ------------------------------------------------------

nohup rman target / @/flashback/rmanbkp/daily/pngfib/pngfibdbbackup.full log=/flashback/expdp//backupPNGFIBFUllDB03JAN2023.ful.log &

--------------------------------------------------------------------------------------------------------------------

----------------------------------backup PNGFIB 08 MAR 2023  ------------------------------------------------------

nohup rman target / @/flashback/rmanbkp/daily/pngfib/pngfibdbbackup.full log=/flashback/expdp//backupPNGFIBFUllDB08MAR2023.ful.log &

--------------------------------------------------------------------------------------------------------------------



----------------------------backup itms  and restore pngitms----------------------------------------------------

nohup rman target / @/flashback/rmanbkp/daily/pngitms/itmsbackup.full log=/flashback/expdp//backupITMSFUllDB27JAN2022.ful.log &

nohup rman target / @/flashback/rmanbkp/daily/pngitms/itmsbackup.full log=/flashback/expdp//backupITMSFUllDB11feb2022.ful.log &


run {
	restore controlfile from '/flashback/rmanbkp/daily/pngitms/27JAN2022/pngitms_ctrl_file_bi0kb4q0_1_1.bkp';
}

nohup rman target / @/flashback/expdp/restoreuatpngitmsfilepath.full log=/flashback/expdp//restoreuatpngitmsfilepath27JAN2022.ful.log &

nohup rman target / @/flashback/expdp/recoverpngitmsfilepath.full log=/flashback/expdp//recoverpngitmsfilepath27JAN2022.ful.log &

recover database until sequence 11369 thread 1;

restoreuatpngitmsfilepath.full

recoverpngitmsfilepath.full
--------------------------------------------------------------------------------------------------

--------------------------------------backup finacle ------------------------------------
nohup rman target / @/flashback/rmanbkp/daily/pngfin/backupfinacle.full log=/flashback/expdp//backupFInacleFUllDB24NOV2021.ful.log &

nohup scp -r pngfin_today 10.234.206.141:$PWD > nohup.out 2>&1

backuparchivelogfinacle.full

nohup rman target / @/flashback/rmanbkp/daily/pngfin/backuparchivelogfinacle.full log=/flashback/expdp//backuparchivelogfinacle.full.log &

nohup rman target / @/flashback/rmanbkp/daily/pngfin/backuparchivelogfinaclep2.full log=/flashback/expdp//backuparchivelogfinaclep2.full.log &
backuparchivelogfinaclep2.full

-----------------------------------------------------------------------------------

------------------------------------backup redbox database ----------------------------------------
nohup rman target / @/flashback/rmanbkp/daily/pngrdbox/backupredbox.full log=/flashback/expdp//backupRedboxFUllDB21DEC2021.ful.log &

nohup rman target / @/flashback/rmanbkp/daily/pngrdbox/backupredboxarchivelogcontrol.full log=/flashback/expdp//backupRedboxFUllDB22DEC2021.ful.log &

--------------------------------- backup internet banking database -------------------------------------
nohup rman target / @/flashback/rmanbkp/daily/pngfib/backupfib.full log=/flashback/expdp//backupFIBFUllDB22DEC2021.ful.log &

backupfib.full
--------------------------------------------------------------------------------------------------------
backupredbox.full

---------------------------------------------------------------------------------------------------

------------------------------ RESTORE FINACLE FROM FILE PATH 12 MAR 2022 -----------------------------------

run {
restore primary controlfile from '/flashback/rmanbkp/daily/pngfin/1MAR2022/pngfin_ctrl_file_td0nb61t_27565_1_1.bkp';
}

nohup rman target / @/flashback/expdp/restoreuatpngfinfilepath.full log=/flashback/expdp//restoreuatpngfinfilepath15MAR2022.ful.log &

switch database to copy;

nohup rman target / @/flashback/expdp/recoverpngfinuatfilepath.full log=/flashback/expdp//recoverpngfinuatfilepath16MAR2022.ful.log &

nohup rman target / @/flashback/expdp/recoverungpngfinseqfilepath.full log=/flashback/expdp//recoverungpngfinseqfilepath16mar2022.log &


recoverungpngfinseqfilepath.full


----------------------------------------------------------RESTORE FINACLE FROM FILE PATH 11 APR 2022-----------------------------------------------------------------------------------

run {
restore primary controlfile from '/flashback/rmanbkp/daily/pngfin/01APR2022/pngfin_ctrl_file_vt0pr114_27645_1_1.bkp';
}

nohup rman target / @/flashback/expdp/restoreuatpngfinfilepath.full log=/flashback/expdp//restoreuatpngfinfilepath11APR2022.ful.log &

switch database to copy;

nohup rman target / @/flashback/expdp/recoverpngfinuatfilepath.full log=/flashback/expdp//recoverpngfinuatfilepath12APR2022.ful.log &

nohup rman target / @/flashback/expdp/recoverungpngfinseqfilepath.full log=/flashback/expdp//recoverungpngfinseqfilepath14APR2022a.log &

catalog start with '/flashback/rmanbkp/daily/pngfin/01NOV2022/' noprompt;

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------

----------------------------------------------------------RESTORE FINACLE FROM FILE PATH 8 NOVEMBER 2022-----------------------------------------------------------------------------------

run {
restore primary controlfile from '/flashback/rmanbkp/daily/pngfin/01NOV2022/pngfin_ctrl_file_je1bndus_28270_1_1.bkp';
}
-------------
run {
restore primary controlfile from '/flashback/rmanbkp/daily/pngfin/31OCT2022/pngfin_ctrl_file_i41bn82a_28228_1_1.bkp';
}


nohup rman target / @/flashback/expdp/restoreuatpngfinfilepath.full log=/flashback/expdp//restoreuatpngfinfilepath12NOV2022.ful.log &

switch database to copy;

nohup rman target / @/flashback/expdp/recoverpngfinuatfilepath.full log=/flashback/expdp//recoverpngfinuatfilepath13NOV2022.ful.log &

nohup rman target / @/flashback/expdp/recoverungpngfinseqfilepath.full log=/flashback/expdp//recoverungpngfinseqfilepath14NOV2022.log &

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------

----------------------------------------------------------RESTORE FINACLE FROM FILE PATH 8 DECEMBER 2022 ------------------------------------

run {
restore primary controlfile from '/flashback/rmanbkp/daily/pngfin/31OCT2022/pngfin_ctrl_file_i41bn82a_28228_1_1.bkp';
}

nohup rman target / @/flashback/expdp/restoreuatpngfinfilepath.full log=/flashback/expdp//restoreuatpngfinfilepath8DEC2022.ful.log &

switch database to copy;

nohup rman target / @/flashback/expdp/recoverpngfinuatfilepath.full log=/flashback/expdp//recoverpngfinuatfilepath9DEC2022.ful.log &

nohup rman target / @/flashback/expdp/recoverungpngfinseqfilepath.full log=/flashback/expdp//recoverungpngfinseqfilepath10DEC2022.log &

----------------------------------------------------------------------------------------------------------------------------------------------


------------------------------- restore finacle from file path -------------------------------------------------

pngfin_controlfile_q70f1s1e_27463_1_1.bkp

run {
restore primary controlfile from '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_controlfile_q70f1s1e_27463_1_1.bkp';
}

catalog start with '/flashback/rmanbkp/daily/pngfin/pngfin_today/*';

catalog start with '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_archivelogfile48722_q90fckbe_27465_1_1.bkp';


run{
catalog start with '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_archivelogfile_qb0fcnd4_27467_1_1.bkp';
catalog start with '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_archivelogfile_qd0fcql5_27469_1_1.bkp';
catalog start with '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_archivelogfile_qe0fcql5_27470_1_1.bkp';
catalog start with '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_archivelogfile_qf0fcql5_27471_1_1.bkp';
catalog start with '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_archivelogfile_qg0fcql5_27472_1_1.bkp';
catalog start with '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_archivelogfile_qh0fcql6_27473_1_1.bkp';
catalog start with '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_archivelogfile_qi0fcql6_27474_1_1.bkp';
catalog start with '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_archivelogfile_qj0fcql6_27475_1_1.bkp';
catalog start with '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_archivelogfile_qk0fcql7_27476_1_1.bkp';
catalog start with '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_archivelogfile_ql0fcql7_27477_1_1.bkp';
catalog start with '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_archivelogfile_qm0fcql7_27478_1_1.bkp';
catalog start with '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_archivelogfile_qn0fcqu9_27479_1_1.bkp';
catalog start with '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_archivelogfile_qo0fcqua_27480_1_1.bkp';
catalog start with '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_archivelogfile_qp0fcqua_27481_1_1.bkp';
catalog start with '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_archivelogfile_qq0fcqua_27482_1_1.bkp';
catalog start with '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_archivelogfile_qr0fcqua_27483_1_1.bkp';
catalog start with '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_archivelogfile_qs0fcqub_27484_1_1.bkp';
catalog start with '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_archivelogfile_qt0fcqub_27485_1_1.bkp';
catalog start with '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_archivelogfile_qu0fcqub_27486_1_1.bkp';
catalog start with '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_archivelogfile_r00fcquc_27488_1_1.bkp';
catalog start with '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_archivelogfile_qv0fcquc_27487_1_1.bkp';
catalog start with '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_archivelogfile_r20fd70r_27490_1_1.bkp';
catalog start with '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_archivelogfile_r30fd70s_27491_1_1.bkp';
catalog start with '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_archivelogfile_r40fd70s_27492_1_1.bkp';
catalog start with '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_archivelogfile_r50fd70s_27493_1_1.bkp';
catalog start with '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_archivelogfile_r70fd70s_27495_1_1.bkp';
catalog start with '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_archivelogfile_r60fd70s_27494_1_1.bkp';
catalog start with '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_archivelogfile_r80fd70t_27496_1_1.bkp';
catalog start with '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_archivelogfile_r90fd70t_27497_1_1.bkp';
catalog start with '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_archivelogfile_rb0fd70t_27499_1_1.bkp';
catalog start with '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_archivelogfile_ra0fd70t_27498_1_1.bkp';
catalog start with '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_archivelogfile_rc0fd74a_27500_1_1.bkp';
catalog start with '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_archivelogfile_rd0fd74a_27501_1_1.bkp';
catalog start with '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_archivelogfile_re0fd74b_27502_1_1.bkp';
catalog start with '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_archivelogfile_rf0fd74b_27503_1_1.bkp';
catalog start with '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_archivelogfile_rg0fd74b_27504_1_1.bkp';
catalog start with '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_archivelogfile_rh0fd74b_27505_1_1.bkp';
catalog start with '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_archivelogfile_rj0fd74c_27507_1_1.bkp';
catalog start with '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_archivelogfile_ri0fd74c_27506_1_1.bkp';
catalog start with '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_archivelogfile_rk0fd74c_27508_1_1.bkp';
catalog start with '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_archivelogfile_rl0fd74c_27509_1_1.bkp';
}


pngfin_archivelogfile

restoreuatpngfinfilepath.full

nohup rman target / @/flashback/expdp/restoreuatpngfinfilepath.full log=/flashback/expdp//restoreuatpngfinfilepath19DEC2021.ful.log &

switch database to copy;

recoverpngfinuatfilepath.full

nohup rman target / @/flashback/expdp/recoverpngfinuatfilepath.full log=/flashback/expdp//recoverpngfinuatfilepath20DEC2021.ful.log &

nohup rman target / @/flashback/expdp/recoverungpngfinseqfilepath.full log=/flashback/expdp//recoverpngfinuatseqfilepath.ful.log &

recoverungpngfinseqfilepath.full



------------------------------------------------------------------------------------------------------------------

RUN {
ALLOCATE CHANNEL ch0 TYPE 'SBT_TAPE';
SEND 'NB_ORA_SERV=PNGNIBKUP02v, NB_ORA_CLIENT=pngrhev02.ng.sbicdirectory.com';
restore archivelog scn between  13491692826380 and 13491705001882;
RELEASE CHANNEL ch0;
}

RUN {
ALLOCATE CHANNEL ch0 TYPE 'SBT_TAPE';
SEND 'NB_ORA_SERV=PNGNIBKUP02v, NB_ORA_CLIENT=pngrhev02.ng.sbicdirectory.com';
DELETE EXPIRED ARCHIVELOG ALL;
RELEASE CHANNEL ch0;
}

RUN {
ALLOCATE CHANNEL ch0 TYPE 'SBT_TAPE';
SEND 'NB_ORA_SERV=PNGNIBKUP02v, NB_ORA_CLIENT=pngrhev02.ng.sbicdirectory.com';
restore archivelog all;
RELEASE CHANNEL ch0;
}
RELEASE CHANNEL CH01;
RELEASE CHANNEL CH02;
RELEASE CHANNEL CH03;
RELEASE CHANNEL CH04;
RELEASE CHANNEL CH05;
RELEASE CHANNEL CH06;
RELEASE CHANNEL CH07;
RELEASE CHANNEL CH08;
RELEASE CHANNEL CH09;
RELEASE CHANNEL CH10;
RELEASE CHANNEL CH11;
RELEASE CHANNEL CH12;
RELEASE CHANNEL CH13;

/ctrl_dPNGFIN_ucu00ir3v_s15774_p1_t1074359423



run
{
	allocate channel c1 DEVICE TYPE DISK FORMAT '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_%U.bkp';
	allocate channel c2 DEVICE TYPE DISK FORMAT '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_%U.bkp';
    allocate channel c3 DEVICE TYPE DISK FORMAT '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_%U.bkp';
    allocate channel c4 DEVICE TYPE DISK FORMAT '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_%U.bkp';
	allocate channel c5 DEVICE TYPE DISK FORMAT '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_%U.bkp';
	allocate channel c6 DEVICE TYPE DISK FORMAT '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_%U.bkp';
    allocate channel c7 DEVICE TYPE DISK FORMAT '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_%U.bkp';
    allocate channel c8 DEVICE TYPE DISK FORMAT '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_%U.bkp';
	allocate channel c9 DEVICE TYPE DISK FORMAT '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_%U.bkp';
	allocate channel c10 DEVICE TYPE DISK FORMAT '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_%U.bkp';
    allocate channel c11 DEVICE TYPE DISK FORMAT '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_%U.bkp';
    allocate channel c12 DEVICE TYPE DISK FORMAT '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_%U.bkp';
	allocate channel c13 DEVICE TYPE DISK FORMAT '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_%U.bkp';
	allocate channel c14 DEVICE TYPE DISK FORMAT '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_%U.bkp';
	BACKUP AS COMPRESSED BACKUPSET  DATABASE PLUS ARCHIVELOG;
	release channel c1;
	release channel c2;
	release channel c3;
	release channel c4;
	release channel c5;
	release channel c6;
	release channel c7;
	release channel c8;
	release channel c9;
	release channel c10;
	release channel c11;
	release channel c12;
	release channel c13;
	release channel c14;
}

run
{
	allocate channel c1 DEVICE TYPE DISK FORMAT '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_controlfile_%U.bkp';
	backup current controlfile;
	release channel c1;
}

run
{
	allocate channel c1 DEVICE TYPE DISK FORMAT '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_controlfile_%U.bkp';
	backup current controlfile;
	release channel c1;
}

run
{
	allocate channel c1 DEVICE TYPE DISK FORMAT '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_archivelogfile48722_%U.bkp';
	backup archivelog sequence 48722 thread 1;
	release channel c1;
}

run
{
	allocate channel c1 DEVICE TYPE DISK FORMAT '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_archivelogfile_%U.bkp';
	backup archivelog sequence 48499 thread 2;
	release channel c1;
}

run
{
	allocate channel c1 DEVICE TYPE DISK FORMAT '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_archivelogfile_%U.bkp';
	allocate channel c2 DEVICE TYPE DISK FORMAT '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_archivelogfile_%U.bkp';
	allocate channel c3 DEVICE TYPE DISK FORMAT '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_archivelogfile_%U.bkp';
	allocate channel c4 DEVICE TYPE DISK FORMAT '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_archivelogfile_%U.bkp';
	allocate channel c5 DEVICE TYPE DISK FORMAT '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_archivelogfile_%U.bkp';
	allocate channel c6 DEVICE TYPE DISK FORMAT '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_archivelogfile_%U.bkp';
	allocate channel c7 DEVICE TYPE DISK FORMAT '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_archivelogfile_%U.bkp';
	allocate channel c8 DEVICE TYPE DISK FORMAT '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_archivelogfile_%U.bkp';
	allocate channel c9 DEVICE TYPE DISK FORMAT '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_archivelogfile_%U.bkp';
	allocate channel c10 DEVICE TYPE DISK FORMAT '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_archivelogfile_%U.bkp';
	backup archivelog from sequence 48723 thread 1 until sequence 48764 thread 1;
	backup archivelog from sequence 48500 thread 2 until sequence 48541 thread 2;
}


run
{
	allocate channel c1 DEVICE TYPE DISK FORMAT '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_archivelogfile_%U.bkp';
	allocate channel c2 DEVICE TYPE DISK FORMAT '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_archivelogfile_%U.bkp';
	allocate channel c3 DEVICE TYPE DISK FORMAT '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_archivelogfile_%U.bkp';
	allocate channel c4 DEVICE TYPE DISK FORMAT '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_archivelogfile_%U.bkp';
	allocate channel c5 DEVICE TYPE DISK FORMAT '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_archivelogfile_%U.bkp';
	allocate channel c6 DEVICE TYPE DISK FORMAT '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_archivelogfile_%U.bkp';
	allocate channel c7 DEVICE TYPE DISK FORMAT '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_archivelogfile_%U.bkp';
	allocate channel c8 DEVICE TYPE DISK FORMAT '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_archivelogfile_%U.bkp';
	allocate channel c9 DEVICE TYPE DISK FORMAT '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_archivelogfile_%U.bkp';
	allocate channel c10 DEVICE TYPE DISK FORMAT '/flashback/rmanbkp/daily/pngfin/pngfin_today/pngfin_archivelogfile_%U.bkp';
	backup archivelog from sequence 48765 until sequence 48792 thread 1;
	backup archivelog from sequence 48542 until sequence 48569 thread 2;
}

backup archivelog sequence 48722 thread 1;

set echo on;
run {
	 ALLOCATE CHANNEL CH00 TYPE 'SBT_TAPE';
	 ALLOCATE CHANNEL CH01 TYPE 'SBT_TAPE';
	 ALLOCATE CHANNEL CH02 TYPE 'SBT_TAPE';
	 ALLOCATE CHANNEL CH03 TYPE 'SBT_TAPE';
	 ALLOCATE CHANNEL CH04 TYPE 'SBT_TAPE';
	 ALLOCATE CHANNEL CH05 TYPE 'SBT_TAPE';
	 ALLOCATE CHANNEL CH06 TYPE 'SBT_TAPE';
	 ALLOCATE CHANNEL CH07 TYPE 'SBT_TAPE';
	 ALLOCATE CHANNEL CH08 TYPE 'SBT_TAPE';
	 ALLOCATE CHANNEL CH09 TYPE 'SBT_TAPE';
	 ALLOCATE CHANNEL CH10 TYPE 'SBT_TAPE';
	 ALLOCATE CHANNEL CH11 TYPE 'SBT_TAPE';
	 ALLOCATE CHANNEL CH12 TYPE 'SBT_TAPE';
	 SEND 'NB_ORA_SERV=PNGNIBKUP02v, NB_ORA_CLIENT=yngrhev01.ng.sbicdirectory.com';
	 set newname for database to "+PDATA/TNGFIN/DATAFILE/%b";
	 restore database;
	 recover database;
}

nohup rman target / @/flashback/expdp/restoreungfin.full log=/flashback/expdp//restoreungfin.ful.log &

nohup rman target / @/flashback/expdp/restoreuatpngfin.full log=/flashback/expdp//restoreuatpngfin.ful.log &

nohup rman target / @/flashback/expdp/recovertngfin.full log=/flashback/expdp//rescovertngfin.ful.log &

nohup rman target / @/flashback/expdp/recovertngfinseq.full log=/flashback/expdp//rescovertngfinseq.ful.log &

nohup rman target / @/flashback/expdp/recoverpngfinuat.full log=/flashback/expdp//rescoverpngfinuat.ful.log &

nohup rman target / @/flashback/expdp/recoverpngfinsequat.full log=/flashback/expdp//recoverpngfinsequat.ful.log &

nohup rman target / @/flashback/expdp/recoverungfin.full log=/flashback/expdp//recoverungfin.full.log &

nohup rman target / @/flashback/expdp/recoverungfinseq.full log=/flashback/expdp//recoverungfinseq.ful.log &

recoverungfinseq.full

recoverungfin.full

recoverpngfinsequat.full

recoverpngfinuat.full

recovertngfinseq.full


+DATA/PNGFIN/DATAFILE/pngfin_1053441674_17vckfka_232.dbf

catalog start with '+DATA/PNGFIN/DATAFILE/*';

catalog start with '+PDATA/PNGFIN/DATAFILE/';

CATALOG START WITH '+DATA/pngfinm/datafile/'; 


catalog datafilecopy '+DATA/PNGFIN/DATAFILE/pngfin_1053441674_17vckfka_232.dbf';

catalog datafilecopy '+DATA/PNGFIN/DATAFILE/pngfin_1053441640_c9vckfj8_229.dbf';

switch database to copy;

spool datafile_names.txt
set lines 200
col name format a60
select file#, name from v$datafile order by file# ;
spool off

spool static_datafile_names.txt
set lines 200
select 'catalog datafilecopy '||''''||name||''''||';' from v$datafile where name not like '%.%.%';
spool off

run {
	 ALLOCATE CHANNEL CH00 TYPE 'SBT_TAPE';
	 ALLOCATE CHANNEL CH01 TYPE 'SBT_TAPE';
	 ALLOCATE CHANNEL CH02 TYPE 'SBT_TAPE';
	 ALLOCATE CHANNEL CH03 TYPE 'SBT_TAPE';
	 ALLOCATE CHANNEL CH04 TYPE 'SBT_TAPE';
	 ALLOCATE CHANNEL CH05 TYPE 'SBT_TAPE';
	 ALLOCATE CHANNEL CH06 TYPE 'SBT_TAPE';
	 ALLOCATE CHANNEL CH07 TYPE 'SBT_TAPE';
	 ALLOCATE CHANNEL CH08 TYPE 'SBT_TAPE';
	 ALLOCATE CHANNEL CH09 TYPE 'SBT_TAPE';
	 ALLOCATE CHANNEL CH10 TYPE 'SBT_TAPE';
	 ALLOCATE CHANNEL CH11 TYPE 'SBT_TAPE';
	 ALLOCATE CHANNEL CH12 TYPE 'SBT_TAPE';
	 SEND 'NB_ORA_SERV=PNGNIBKUP02v, NB_ORA_CLIENT=yngrhev01.ng.sbicdirectory.com';
	 recover database;
}




run {
	 ALLOCATE CHANNEL CH00 TYPE 'SBT_TAPE';
	 ALLOCATE CHANNEL CH01 TYPE 'SBT_TAPE';
	 ALLOCATE CHANNEL CH02 TYPE 'SBT_TAPE';
	 ALLOCATE CHANNEL CH03 TYPE 'SBT_TAPE';
	 ALLOCATE CHANNEL CH04 TYPE 'SBT_TAPE';
	 ALLOCATE CHANNEL CH05 TYPE 'SBT_TAPE';
	 ALLOCATE CHANNEL CH06 TYPE 'SBT_TAPE';
	 ALLOCATE CHANNEL CH07 TYPE 'SBT_TAPE';
	 ALLOCATE CHANNEL CH08 TYPE 'SBT_TAPE';
	 ALLOCATE CHANNEL CH09 TYPE 'SBT_TAPE';
	 ALLOCATE CHANNEL CH10 TYPE 'SBT_TAPE';
	 ALLOCATE CHANNEL CH11 TYPE 'SBT_TAPE';
	 ALLOCATE CHANNEL CH12 TYPE 'SBT_TAPE';
	 SEND 'NB_ORA_SERV=PNGNIBKUP02v, NB_ORA_CLIENT=yngrhev01.ng.sbicdirectory.com';
	 recover database until sequence 29986 thread 1;
}

 1 with sequence 29986

run {
	 ALLOCATE CHANNEL CH00 TYPE 'SBT_TAPE';
	 ALLOCATE CHANNEL CH01 TYPE 'SBT_TAPE';
	 ALLOCATE CHANNEL CH02 TYPE 'SBT_TAPE';
	 ALLOCATE CHANNEL CH03 TYPE 'SBT_TAPE';
	 ALLOCATE CHANNEL CH04 TYPE 'SBT_TAPE';
	 ALLOCATE CHANNEL CH05 TYPE 'SBT_TAPE';
	 ALLOCATE CHANNEL CH06 TYPE 'SBT_TAPE';
	 ALLOCATE CHANNEL CH07 TYPE 'SBT_TAPE';
	 ALLOCATE CHANNEL CH08 TYPE 'SBT_TAPE';
	 ALLOCATE CHANNEL CH09 TYPE 'SBT_TAPE';
	 ALLOCATE CHANNEL CH10 TYPE 'SBT_TAPE';
	 ALLOCATE CHANNEL CH11 TYPE 'SBT_TAPE';
	 ALLOCATE CHANNEL CH12 TYPE 'SBT_TAPE';
	 backup archivelog all;
}
backup archivelog


run {
	ALLOCATE CHANNEL CH00 TYPE 'SBT_TAPE';
	 ALLOCATE CHANNEL CH01 TYPE 'SBT_TAPE';
	 ALLOCATE CHANNEL CH02 TYPE 'SBT_TAPE';
	 ALLOCATE CHANNEL CH03 TYPE 'SBT_TAPE';
	 ALLOCATE CHANNEL CH04 TYPE 'SBT_TAPE';
	 ALLOCATE CHANNEL CH05 TYPE 'SBT_TAPE';
	 ALLOCATE CHANNEL CH06 TYPE 'SBT_TAPE';
	 ALLOCATE CHANNEL CH07 TYPE 'SBT_TAPE';
	 ALLOCATE CHANNEL CH08 TYPE 'SBT_TAPE';
	 ALLOCATE CHANNEL CH09 TYPE 'SBT_TAPE';
	 ALLOCATE CHANNEL CH10 TYPE 'SBT_TAPE';
	 ALLOCATE CHANNEL CH11 TYPE 'SBT_TAPE';
	 ALLOCATE CHANNEL CH12 TYPE 'SBT_TAPE';
	SEND 'NB_ORA_SERV=PNGNIBKUP02v.ng.sbicdirectory.com, NB_ORA_CLIENT=yngrhev01.ng.sbicdirectory.com, NB_ORA_POLICY=oracle_DRDBs_archivelog_backup';
	backup archivelog until time 'sysdate';
}



ORA-39126: Worker unexpected fatal error in KUPW$WORKER.FETCH_XML_OBJECTS [SEQUENCE:


DROP SEQUENCE U_IC4INDEP.SEQ_USER_BRANCHES;

CREATE SEQUENCE U_IC4INDEP.SEQ_USER_BRANCHES
  START WITH 2199
  MAXVALUE 999999999999999999999999999
  MINVALUE 1
  NOCYCLE
  CACHE 20
  NOORDER;




A239739

A225523

A235730


A238008

A239765

A241355


srvctl status inst -d dngfin -i pngfin1


srvctl add instance -d dngfin -i pngfin1 -n yngrhev01

srvctl add instance -d dngfin -i pngfin2 -n yngrhev02



srvctl add database -d dngfin -o /u01/app/oracle/product/19.0.0/db_1 -p +DATA/DNGFIN/PARAMETERFILE/spfile.1975.1079867057

srvctl add database -d dngrdbox -o /u01/app/oracle/product/19.0.0/db_1 -p +DATA/DNGRDBOX/PARAMETERFILE/spfile.4446.1079861863

srvctl add database -d dngfib -o /u01/app/oracle/product/19.0.0/db_1 -p +DATA/DNGFIB/PARAMETERFILE/spfile.4305.1079523429

srvctl add database -d dngitms -o /u01/app/oracle/product/19.0.0/db_1 -p +DATA/DNGITMS/PARAMETERFILE/spfile.4303.1079259615

srvctl add database -d dngabank -o /u01/app/oracle/product/19.0.0/db_1 -p +DATA/DNGABANK/PARAMETERFILE/spfile.4304.1079259903

srvctl add database -d dngesb -o /u01/app/oracle/product/19.0.0/db_1 -p +DATA/DNGESB/PARAMETERFILE/spfile.4302.1079188193

srvctl add database -d dngcog -o /u01/app/oracle/product/19.0.0/db_1 -p +DATA/DNGCOG/PARAMETERFILE/spfile.4301.1079186103

srvctl add database -d dngdtr -o /u01/app/oracle/product/19.0.0/db_1 -p  +DATA/DNGDTR/PARAMETERFILE/spfile.4297.1079177571

srvctl add database -d dngpas -o /u01/app/oracle/product/19.0.0/db_1 -p  +DATA/DNGPAS/PARAMETERFILE/spfile.4296.1079097351

srvctl add database -d dngctm -o /u01/app/oracle/product/19.0.0/db_1 -p  +DATA/DNGCTM/PARAMETERFILE/spfile.4298.1079181003
 
srvctl add database -d dngcem -o /u01/app/oracle/product/19.0.0/db_1 -p  +DATA/DNGCEM/PARAMETERFILE/spfile.4299.1079182711

srvctl add database -d dngaud -o /u01/app/oracle/product/19.0.0/db_1 -p  +DATA/DNGAUD/PARAMETERFILE/spfile.4300.1079184031

nohup rman target / @/flashback/rmanbkp/daily/iconcept/iconcept_incremental_bkp.incrmt log=/flashback/expdp//backupICONCEPTINCRDB07NOV2023.ful.log & 

=============================ICONCEPT BACKUP AND RESTORE==================================
run 
{
allocate channel c1 type disk format '/flashback/rmanbkp/daily/pngdtr/incr/rman_bkup%U.rmb';
backup incremental from scn 326502199 database;
BACKUP CURRENT CONTROLFILE FORMAT '//flashback/rmanbkp/daily/pngdtr/incr/pngdtr_ctrl_file_%U.bkp';
}

RMAN>  run {
allocate channel c1 type disk format '/flashback/expdp/recogap/rman_bkup%U.rmb';
backup incremental from scn 1345960938 database;
}
 
 


nohup rman target / @/flashback/rmanbkp/daily/iconcept/iconcept_incremental_bkp.incrmt log=/flashback/expdp//backupICONCEPTINCRDB07NOV2023.ful.log &
nohup rman target / @/flashback/rmanbkp/daily/pngdtr/pngdtr_incr_bkp.incrmt log=/flashback/expdp//backupPngdtrDec112023.ful.log & 

58836765858

select file#, name, checkpoint_change#, last_change#, status, enabled from v$datafile
where name = '+DATA/iconcept/DATAFILE/iconcept_c42asne8_1_1.bkp';
iconcept_c42asne8_1_1.bkp


======================ITMS DATABASE BACKUP AND RESTORE ============================
edit database pngdtr set state=TRANSPORT-OFF;
edit database dngdtr set state=APPLY-OFF;


run
{
        allocate channel c1 DEVICE TYPE DISK;
        allocate channel c2 DEVICE TYPE DISK;
        allocate channel c3 DEVICE TYPE DISK;
        allocate channel c4 DEVICE TYPE DISK;
        allocate channel c5 DEVICE TYPE DISK;
        allocate channel c6 DEVICE TYPE DISK;
        allocate channel c7 DEVICE TYPE DISK;
        allocate channel c8 DEVICE TYPE DISK;
        allocate channel c9 DEVICE TYPE DISK;
        allocate channel c10 DEVICE TYPE DISK;
        allocate channel c11 DEVICE TYPE DISK;
        allocate channel c12 DEVICE TYPE DISK;
        allocate channel c13 DEVICE TYPE DISK;
        allocate channel c14 DEVICE TYPE DISK;
        BACKUP AS COMPRESSED BACKUPSET DATABASE FORMAT '/flashback/expdp/itmsbackup/itms_%U.bkp';
        BACKUP AS COMPRESSED BACKUPSET ARCHIVELOG ALL FORMAT '/flashback/expdp/itmsbackup/itms_archive_%U.bkp';
        BACKUP CURRENT CONTROLFILE FORMAT '/flashback/expdp/itmsbackup/itms_ctrl_file_%U.bkp';
        release channel c1;
        release channel c2;
        release channel c3;
        release channel c4;
        release channel c5;
        release channel c6;
        release channel c7;
        release channel c8;
        release channel c9;
        release channel c10;
        release channel c11;
        release channel c12;
        release channel c13;
        release channel c14;
}

nohup rman target / @/flashback/expdp/itmsbackup/itmsSTBbackup.full log=/flashback/expdp//itmsSTBbackup.ful.log &

cd /flashback/expdp/itmsbackup/
scp - r incr oracle@10.234.204.10:/flashback/rmanbkp/daily/pngdtr


SYS@pngitms1 >select GROUP#,TYPE,MEMBER from v$logfile;  --Take note on standbyDB

SYS@pngitms1 > show parameter control_files;

NAME                                 TYPE        VALUE
------------------------------------ ----------- ------------------------------
control_files                        string      +DATA/PNGITMS/CONTROLFILE/cont 
                                                 rol01.ctl, +FRA/PNGITMS/CONTRO
                                                 LFILE/control02.ctl
												 
------backup controlfile------

RMAN> restore standby controlfile from '/flashback/rmanbkp/daily/pngdtr/incr/pngdtr_ctrl_file_8o2drc44_8472_1_1.bkp';

restore primary controlfile from '/flashback/rmanbkp/daily/pngitms/ITMS_UAT_REFRESH/pngitms_ctrl_file_up2u5k02_15321_1_1.bkp';

RMAN> catalog start with '/flashback/rmanbkp/daily/iconcept/iconcept_full_backup/';


run {
         set newname for database to "+DATA/DNGDTR/DATAFILE/%b";
         restore database;
		 recover database;
}

nohup rman target / @/flashback/expdp/pngitms_restore.full log=/flashback/expdp//pngitms_restore.ful.log &

SCN - FROM STANDBY - select current_scn from v$database;
SYS@pngitms1 >select GROUP#,TYPE,MEMBER from v$logfile;    select GROUP#,TYPE,MEMBER from v$logfile;

    GROUP# TYPE    MEMBER
---------- ------- --------------------------------------------------
         1 ONLINE  +DATA/PNGITMS/ONLINELOG/group_1.1014.1049290995
         1 ONLINE  +FRA/PNGITMS/ONLINELOG/group_1.463.1049290997
         2 ONLINE  +DATA/PNGITMS/ONLINELOG/group_2.1015.1049290997
         2 ONLINE  +FRA/PNGITMS/ONLINELOG/group_2.464.1049290997
         3 ONLINE  +DATA/PNGITMS/ONLINELOG/group_3.1022.1049291787
         3 ONLINE  +FRA/PNGITMS/ONLINELOG/group_3.468.1049291787
         4 ONLINE  +DATA/PNGITMS/ONLINELOG/group_4.1023.1049291787
         4 ONLINE  +FRA/PNGITMS/ONLINELOG/group_4.469.1049291787
         5 STANDBY +REDO/PNGITMS/ONLINELOG/group_5.409.1079260935
         6 STANDBY +REDO/PNGITMS/ONLINELOG/group_6.410.1079260935
         7 STANDBY +REDO/PNGITMS/ONLINELOG/group_7.411.1079260937

    GROUP# TYPE    MEMBER
---------- ------- --------------------------------------------------
         8 STANDBY +REDO/PNGITMS/ONLINELOG/group_8.412.1079260937
         9 STANDBY +REDO/PNGITMS/ONLINELOG/group_9.413.1079260973

ASMCMD> ls
group_10.296.1061723349
group_11.297.1061723351
group_12.298.1061723353
group_13.299.1061723353
group_14.300.1061723355
group_5.334.1079260965
group_6.335.1079260967
group_7.336.1079260967
group_8.337.1079260967
group_9.338.1079260969

alter system set standby_file_management=manual;

alter database rename file '+REDO/PNGITMS/ONLINELOG/group_5.409.1079260935' to '+REDO/DNGITMS/ONLINELOG/group_5.334.1079260965';
alter database rename file '+REDO/PNGITMS/ONLINELOG/group_6.410.1079260935' to '+REDO/DNGITMS/ONLINELOG/group_6.335.1079260967';
alter database rename file '+REDO/PNGITMS/ONLINELOG/group_7.411.1079260937' to '+REDO/DNGITMS/ONLINELOG/group_7.336.1079260967';
alter database rename file '+REDO/PNGITMS/ONLINELOG/group_8.412.1079260937' to '+REDO/DNGITMS/ONLINELOG/group_8.337.1079260967';
alter database rename file '+REDO/PNGITMS/ONLINELOG/group_9.413.1079260973' to '+REDO/DNGITMS/ONLINELOG/group_9.338.1079260969';

alter system set standby_file_management=auto;
alter system set standby_file_management=manual;


edit database pngcfrm set state=TRANSPORT-OFF;
edit database dngcfrm set state=APPLY-OFF;

edit database pngcfrm set state=TRANSPORT-ON;
edit database dngcfrm set state=APPLY-OFF;

ALTER SYSTEM SET dg_broker_start=true scope=both sid='*';


11		STANDBY	+REDO/PNGCFM/ONLINELOG/stb_redo1.log	NO	0 THREAD 1
12		STANDBY	+REDO/PNGCFM/ONLINELOG/stb_redo2.log	NO	0 THREAD 1
13		STANDBY	+REDO/PNGCFM/ONLINELOG/stb_redo3.log	NO	0 THREAD 1
14		STANDBY	+REDO/PNGCFM/ONLINELOG/stb_redo04.log	NO	0 THREAD 2
15		STANDBY	+REDO/PNGCFM/ONLINELOG/stb_redo05.log	NO	0 THREAD 2
16		STANDBY	+REDO/PNGCFM/ONLINELOG/stb_redo06.log	NO	0 THREAD 2

ALTER DATABASE ADD STANDBY LOGFILE GROUP 10 ('+DATA/PNGITMS/ONLINELOG/stbylog_10.1','+FRA/PNGITMS/ONLINELOG/stbylog_10.2') SIZE 200M; 
alter database add standby logfile group 17( '/p01/oradata/test_dr/onlinelog/stbyloggrp17_1.log', '/p01/fra/test_dr/onlinelog/stbyloggrp17_2.log') SIZE 1024M;

alter database add standby logfile group 11 THREAD 1 ('+REDO/PNGCFM/ONLINELOG/stb_redo1.log') size 4096M;
alter database add standby logfile group 12 THREAD 1 ('+REDO/PNGCFM/ONLINELOG/stb_redo2.log') size 4096M;
alter database add standby logfile group 13 THREAD 1 ('+REDO/PNGCFM/ONLINELOG/stb_redo3.log') size 4096M;
alter database add standby logfile group 14 THREAD 2 ('+REDO/PNGCFM/ONLINELOG/stb_redo04.log') size 4096M;
alter database add standby logfile group 15 THREAD 2 ('+REDO/PNGCFM/ONLINELOG/stb_redo05.log') size 4096M;
alter database add standby logfile group 16 THREAD 2 ('+REDO/PNGCFM/ONLINELOG/stb_redo06.log') size 4096M;

==ICONCEPT RESTORE===========
DR
2	ONLINE	+REDO/DCONCEPT/ONLINELOG/group_2.345.1152807615
1	ONLINE	+REDO/DCONCEPT/ONLINELOG/group_1.344.1152807613
3	ONLINE	+REDO/DCONCEPT/ONLINELOG/group_3.346.1152807617
4	ONLINE	+REDO/DCONCEPT/ONLINELOG/group_4.347.1152807619
10	STANDBY	+REDO/ICONCEPT/ONLINELOG/stnbylog_10
11	STANDBY	+REDO/ICONCEPT/ONLINELOG/stnbylog_11
12	STANDBY	+REDO/ICONCEPT/ONLINELOG/stnbylog_12
13	STANDBY	+REDO/ICONCEPT/ONLINELOG/stnbylog_13
14	STANDBY	+REDO/ICONCEPT/ONLINELOG/stnbylog_14

ASMCMD
group_1.297.1074081545
group_1.344.1152807613
group_10.333.1079024623
group_11.332.1079024625
group_12.331.1079024627
group_13.330.1079024629
group_14.329.1079024631
group_2.298.1074081547
group_2.345.1152807615
group_3.299.1074081547
group_3.346.1152807617
group_4.300.1074081549
group_4.347.1152807619
stnbylog_10
stnbylog_11
stnbylog_12
stnbylog_13
stnbylog_14

NAME                                 TYPE        VALUE
------------------------------------ ----------- ------------------------------
control_files                        string      +REDO/ICONCEPT/CONTROLFILE/con
                                                 trol01.ctl, +DATA/ICONCEPT/CON
                                                 TROLFILE/control02.ctl


Checked list of database backup
LIST BACKUP OF ARCHIVELOG until time '(SYSDATE-1)';
LIST BACKUP OF ARCHIVELOG until time '(SYSDATE)';

RMAN> LIST BACKUP OF DATABASE COMPLETED AFTER '(SYSDATE-1)';
Checked list of archivelog backup
LIST BACKUP OF DATABASE COMPLETED AFTER '30-AUG-2024'; Run this and pick next scn on incremental back
LIST BACKUP OF ARCHIVELOG UNTIL TIME '04-SEP-2024';

LIST BACKUP OF ARCHIVELOG UNTIL SCN 13825717750097;
LIST BACKUP OF ARCHIVELOG UNTIL SCN 13825718501627;

RMAN>LIST BACKUP OF ARCHIVELOG  BETWEEN '31-AUG-24' AND '05-AUG-24';
List of backup of one datafile:

RMAN>LIST BACKUP OF DATAFILE 1 COMPLETED BETWEEN '06-OCT-2008' and '25-DEC-2008';
Other user full commands:

LIST BACKUP: list all backup sets, copies, and proxy copies of a database, tablespace, data file, archived redo log, control file, or server parameter file.

LIST COPY: list all the images copy of database files and archive log files

LIST archivelog: list all archive log files

List incarnation: list all incarnations of the database (incarnation is created when open database with resetlogs)

List script names: list the name of recovery catalog created.

List failure: it is part of data recovery advisory which list the failure present in database.

LIST BACKUP SUMMARY: provide one line summary for backup Status.

LIST BACKUP BY FILE: List backup of each datafile, archive, control file by file wise


set linesize 200;
set pagesize 100;
col inst_id for 9999999 heading 'Instance #'
col file_nr for 9999999 heading 'File #'
col file_name for A50 heading 'File name'
col checkpoint_change_nr for 99999999999999 heading 'Checkpoint #'
col checkpoint_change_time for A20 heading 'Checkpoint time'
col last_change_nr for 99999999999999 heading 'Last change #'
SELECT
      fe.inst_id,
      fe.fenum file_nr,
      fn.fnnam file_name,
      TO_NUMBER (fe.fecps) checkpoint_change_nr,
      fe.fecpt checkpoint_change_time,
      fe.fests last_change_nr,
      DECODE (
              fe.fetsn,
              0, DECODE (BITAND (fe.festa, 2), 0, 'SYSOFF', 'SYSTEM'),
              DECODE (BITAND (fe.festa, 18),
                      0, 'OFFLINE',
                      2, 'ONLINE',
                      'RECOVER')
      ) status
FROM x$kccfe fe,
     x$kccfn fn
WHERE    (   (fe.fepax != 65535 AND fe.fepax != 0 )
          OR (fe.fepax = 65535 OR fe.fepax = 0)
         )
     AND fn.fnfno = fe.fenum
     AND fe.fefnh = fn.fnnum
     AND fe.fedup != 0
     AND fn.fntyp = 4
     AND fn.fnnam IS NOT NULL
     AND BITAND (fn.fnflg, 4) != 4
ORDER BY fe.fenum
; 


select SID, OPNAME,TARGET,TARGET_DESC,TOTALWORK,UNITS,START_TIME,
LAST_UPDATE_TIME,TIMESTAMP,MESSAGE,USERNAME,SQL_ADDRESS from v$session_longops;

select * from TBAADM.ACCOUNT_LIEN_HISTORY_TABLE where rownum<=2;

select current_scn from v$database;
select GROUP#,TYPE,MEMBER from v$logfile;    select GROUP#,TYPE,MEMBER from v$logfile;

+PDATA/TNGFIN/ONLINELOG/group_1.23730.1181746465

---INCASE RECOVER FAILS

select min(sequence#),max(sequence#) from v$archived_log L, v$database D
where L.resetlogs_change# = D.resetlogs_change# and 
thread#=1;

--
select min(sequence#),max(sequence#) from v$archived_log L, v$database D
where L.resetlogs_change# = D.resetlogs_change# and 
thread#=2;


--The following query will return the minimum and maximum sequence expected by the datafiles: 

select min(fhrba_Seq), max(fhrba_Seq) from X$KCVFH x join
v$datafile d on (x.hxfil=d.file#) and d.enabled not in ('READ ONLY');


--0	209258
169517	209252
--The following query will return the minimum and maximum sequence expected by the datafiles: 

select min(fhrba_Seq), max(fhrba_Seq) from X$KCVFH x join
v$datafile d on (x.hxfil=d.file#) and d.enabled not in ('READ ONLY');


--0	209258
select max(sequence#), thread# from v$archived_log L, v$database D
where L.resetlogs_change#=D.resetlogs_change# and
L.backup_count > 0
group by L.thread#;

select fuzzy, status, checkpoint_change#,
to_char(checkpoint_time, 'DD-MON-YYYY HH24:MI:SS') as checkpoint_time,
count(*)
from v$datafile_header
group by fuzzy, status, checkpoint_change#, checkpoint_time
order by fuzzy, status, checkpoint_change#, checkpoint_time;


set linesize 200;
set pagesize 100;
col inst_id for 9999999 heading 'Instance #'
col file_nr for 9999999 heading 'File #'
col file_name for A50 heading 'File name'
col checkpoint_change_nr for 99999999999999 heading 'Checkpoint #'
col checkpoint_change_time for A20 heading 'Checkpoint time'
col last_change_nr for 99999999999999 heading 'Last change #'
SELECT
      fe.inst_id,
      fe.fenum file_nr,
      fn.fnnam file_name,
      TO_NUMBER (fe.fecps) checkpoint_change_nr,
      fe.fecpt checkpoint_change_time,
      fe.fests last_change_nr,
      DECODE (
              fe.fetsn,
              0, DECODE (BITAND (fe.festa, 2), 0, 'SYSOFF', 'SYSTEM'),
              DECODE (BITAND (fe.festa, 18),
                      0, 'OFFLINE',
                      2, 'ONLINE',
                      'RECOVER')
      ) status
FROM x$kccfe fe,
     x$kccfn fn
WHERE    (   (fe.fepax != 65535 AND fe.fepax != 0 )
          OR (fe.fepax = 65535 OR fe.fepax = 0)
         )
     AND fn.fnfno = fe.fenum
     AND fe.fefnh = fn.fnnum
     AND fe.fedup != 0
     AND fn.fntyp = 4
     AND fn.fnnam IS NOT NULL
     AND BITAND (fn.fnflg, 4) != 4
ORDER BY fe.fenum
; 

--13825719470716

select status, checkpoint_change#,
       to_char(checkpoint_time, 'DD-MON-YYYY HH24:MI:SS') as checkpoint_time,
       count(*)
from v$datafile_header
group by status, checkpoint_change#, checkpoint_time
order by status, checkpoint_change#, checkpoint_time;

ONLINE	13825717750097	03-SEP-2024 09:38:56	1929
ONLINE	13825717750097	03-SEP-2024 09:38:56	1929


--13825693466115
--13825711122840 SCN TO BE USED.
--13825717750097
--list backup of archivelog until scn=13825711122840;
list backup of archivelog until scn=13825711122840;

select SID, OPNAME,TARGET,TARGET_DESC,TOTALWORK,UNITS,START_TIME,
LAST_UPDATE_TIME,TIMESTAMP,MESSAGE,USERNAME,SQL_ADDRESS from v$session_longops;