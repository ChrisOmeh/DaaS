from datetime import datetime

print(datetime.fromtimestamp(1284286794))
print(type(13518883609085))

#====================================
def scn(current_scn, min_scn):
    CURRENT_SCN = datetime.fromtimestamp(current_scn)
    MIN_SCN = datetime.fromtimestamp(min_scn)
    print(f"THE CURRENT_SCN IS:{CURRENT_SCN}")
    print(f"THE MIN SCN IS: {MIN_SCN}")
    DIFF_SCN = CURRENT_SCN - MIN_SCN
    return  f"THE DIFFERENCE BW CURRENT SCN AND MIN SCN IS: {DIFF_SCN}"
    
if __name__ == "__main__":
    print(scn(1165261, 1161196))
