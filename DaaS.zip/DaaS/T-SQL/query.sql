--=============================================
--ORACLE MAJOR SCRIPTS
--=============================================

--ORACLE CREATE USERS
CREATE USER A246458 IDENTIFIED BY "Password";

--ORACLE CLEAR SESSION
--Query V$SESSION supplying the username for the session you want to terminate:
SELECT SID, SERIAL#, STATUS, SERVER
FROM V$SESSION
WHERE USERNAME = '<username>';

--Execute the ALTER SYSTEM command to terminate the session:
ALTER SYSTEM KILL SESSION '<sid, serial#>';