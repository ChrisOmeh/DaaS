=======================================================
ORACLE SCRIPTS
=======================================================

======================================
CHECK DUPLICATE RECORDS IN A TABLE
=====================================
select BILLER_URL, count(*)
from redbox.RBX_S_COLLECTION_BILLERS
group by BILLER_URL
having count(*) > 1;

=====================
SVRCTL COMMANDS
=====================
srvctl stop database -d PRODB -o normal
srvctl stop database -d iconcept -o immediate
srvctl stop database -d PRODB -o transactional
srvctl stop database -d PRODB -o abort
/u01/app/oracle/product/12.1.0.2/dbhome_1/bin/srvctl config database -db dummydb

=====================================
REGISTER A STANDBY AS SRVCTL DATABASE
=====================================
https://anandshdb.blogspot.com/2015/09/prcd-1120-resource-for-database-racdb.html
http://bijoos.com/oraclenotes/2013/67
[oracle@pngoda7 ~]$ srvctl add database -d dngcfm -o /u01/app/odaorahome/oracle/product/19.0.0.0/dbhome_1
[oracle@pngoda7 ~]$ srvctl add instance -d dngcapp -i pngcapp1 -n pngoda7
[oracle@pngoda7 ~]$ srvctl add instance -d dngcapp -i pngcapp2 -n pngoda8
[oracle@pngoda7 ~]$ srvctl add instance -d dconcept -i iconcept1 -n pngoda7
[oracle@pngoda7 ~]$ srvctl add instance -d dconcept -i iconcept2 -n pngoda8
[oracle@pngoda7 ~]$ srvctl add instance -d dngcfm -i pngcfm1 -n pngoda7
[oracle@pngoda7 ~]$ srvctl add instance -d dngcfm -i pngcfm2 -n pngoda8
[oracle@pngoda7 ~]$ srvctl modify database -d dconcept -p +DATA/DCONCEPT/PARAMETERFILE/spfileiconcept.ora
[oracle@pngoda7 ~]$ srvctl status database -d dngcapp
Instance pngcapp1 is not running on node pngoda7
Instance pngcapp2 is not running on node pngoda8
[oracle@pngoda7 ~]$ srvctl status database -d dconcept
Instance iconcept1 is not running on node pngoda7
Instance iconcept2 is not running on node pngoda8
[oracle@pngoda7 ~]$ srvctl start database -d dconcept
[oracle@pngoda7 ~]$ srvctl start database -d dconcept


1. To unlock account
ALTER USER account ACCOUNT UNLOCK;
ALTER USER USERNAME ACCOUNT UNLOCK; ------Unlock user account

2. To reset pssword.
ALTER USER user_name IDENTIFIED BY new_password; 

3. Reset password and Unlock User Account
ALTER USER USERNAME IDENTIFIED BY NEW_PASSWORD ACCOUNT UNLOCK;  -------Account pwd reset and Account unlock.

4. Create User in ORACLE
CREATE USER USERNAME IDENTIFIED BY User_Password; 
CREATE USER A224360 IDENTIFIED BY DEcember__2022;
REVOKE CREATE SESSION FROM USER A224360;

select name from dba_services;
select * from v$listener_network;
=============================================================================
=======================GRANTING CUSTOM_TBLS PRIVILEGES SCRIPT======================
=============================================================================
select 'REVOKE EXECUTE ON '||owner||'.'||object_name||' FROM user;'
from all_objects
where owner = 'CRMUSER'
and object_type='FUNCTION';

5. Kill sessions
kill session for session_id
kill all -u session_name/session_id

6. Running process in Linux
ps -a
ps -u
ps -x 
ps -aux

Finding a complex Process
pgrep <options> <pattern>

<option>
-l: List both the process names and the PIDs
-n: Return process that is newest
-o: Return process that is oldest
-u: Only find processes that belong to a specific user.
-x: Only find a process that matches a specific pattern
kill -9 PID
killl -15 PID 

7. DISABLE USER IN ORACLE
alter user USER_ID account lock password expire;


---SQL Server Connection String:---
Data Source=10.52.1.44;Initial Catalog=MyDB;Trusted_connection=false;Integrated Security=false;User Id=someone;Password=passw


--===========================
--DBA_OBJECTS
--===========================
USE ungrdbox
SELECT OWNER ,
OBJECT_NAME ,
OBJECT_ID ,
OBJECT_TYPE ,
CREATED ,
LAST_DDL_TIME ,
STATUS ,
NAMESPACE ,
SHARING ,
ORACLE_MAINTAINED ,
APPLICATION ,
DUPLICATED ,
SHARDED
FROM DBA_OBJECTS
WHERE STATUS = 'INVALID'
ORDER BY CREATED ASC;

select * FROM dba_users
where username = 'EBANKUSER';

select * from ALL_TABLES
where rownum <=5 and TABLE_NAME = 'MOBILEAPP_SMART_LOAN';

--RDBOX TABLES
SELECT  * FROM ALL_TABLES
WHERE ROWNUM <=5 AND TABLE_NAME = 'CMP_VENDOR';

SELECT * FROM ALL_TABLES
WHERE ROWNUM <=5 AND TABLE_NAME = 'RBX_TRANS_FEES_CONFIG';

--==============================
--DBA_USERS
--==============================
USE ungrdbox
SELECT 
USERNAME,
USER_ID,
ACCOUNT_STATUS,
DEFAULT_TABLESPACE,
TEMPORARY_TABLESPACE,
LOCAL_TEMP_TABLESPACE,
CREATED,
PROFILE,
ORACLE_MAINTAINED,
PASSWORD_CHANGE_DATE
FROM DBA_USERS
WHERE USERNAME NOT IN ('SYS','CUSTOM_TBLS')
ORDER BY ACCOUNT_STATUS ASC;

=====GETTING AND DROPPING DBLINK================
SELECT DBMS_METADATA.GET_DDL('DB_LINK',a.db_link,a.owner) 
FROM dba_db_links a;

======RESTORE DB IN SQL SERVER=============
RESTORE DATABASE [DB_NAME] WITH RECOVERY


======ORACLE SCRIPT FROM FIND RUNNING SESSIONS===================
select * from gv$process where addr In (select creator_addr from gv$session where sid=5806 and serial#=29171);

--==================================
--DBA_TABLESPACE
--==================================
SELECT * FROM DBA_TABLESPACES
WHERE TABLESPACE_NAME NOT IN ('CUSTOM_TBLS', 'SYSAUX','CUSTOM_TBLS');

select df.tablespace_name "Tablespace",
totalusedspace "Used MB",
(df.totalspace - tu.totalusedspace) "Free MB",
df.totalspace "Total MB",
round(100 * ( (df.totalspace - tu.totalusedspace)/ df.totalspace))
"Pct. Free"
from
(select tablespace_name,
round(sum(bytes) / 1048576) TotalSpace
from dba_data_files
group by tablespace_name) df,
(select round(sum(bytes)/(1024*1024)) totalusedspace, tablespace_name
from dba_segments
group by tablespace_name) tu
where df.tablespace_name = tu.tablespace_name 
order by "Pct. Free";

SELECT d.status "Status",
       d.tablespace_name "Name",
       TO_CHAR (NVL (a.bytes / 1024 / 1024 , 0), '99,999,990.90')
          "Size (MB)",
       TO_CHAR (NVL (a.bytes - NVL (f.bytes, 0), 0) / 1024 / 1024 ,
                '99999999.99')
          "Used (MB)",
       TO_CHAR (NVL (f.bytes / 1024 / 1024 , 0), '99,999,990.90')
          "Free (MB)",
       TO_CHAR (NVL ( (a.bytes - NVL (f.bytes, 0)) / a.bytes * 100, 0),
                '990.00')
          "(Used) %"
  FROM sys.dba_tablespaces d,
       (  SELECT tablespace_name, SUM (bytes) bytes
            FROM dba_data_files
        GROUP BY tablespace_name) a,
       (  SELECT tablespace_name, SUM (bytes) bytes
            FROM dba_free_space
        GROUP BY tablespace_name) f
WHERE     d.tablespace_name = a.tablespace_name(+)
       AND d.tablespace_name = f.tablespace_name(+)
       AND NOT (    d.extent_management LIKE 'LOCAL'
                AND d.contents LIKE 'TEMPORARY')
       /*AND TO_CHAR (NVL ( (a.bytes - NVL (f.bytes, 0)) / a.bytes * 100, 0),
                    '990.00') > 75*/
UNION ALL
SELECT d.status "Status",
       d.tablespace_name "Name",
       TO_CHAR (NVL (a.bytes / 1024 / 1024 , 0), '99,999,990.90')
          "Size (MB)",
       TO_CHAR (NVL (t.bytes, 0) / 1024 / 1024 , '99999999.99')
          "Used (MB)",
       TO_CHAR (NVL ( (a.bytes - NVL (t.bytes, 0)) / 1024 / 1024 , 0),
                '99,999,990.90')
          "Free (MB)",
       TO_CHAR (NVL (t.bytes / a.bytes * 100, 0), '990.00') "(Used) %"
  FROM sys.dba_tablespaces d,
       (  SELECT tablespace_name, SUM (bytes) bytes
            FROM dba_temp_files
        GROUP BY tablespace_name) a,
       (  SELECT tablespace_name, SUM (bytes_cached) bytes
            FROM v$temp_extent_pool
        GROUP BY tablespace_name) t
WHERE     d.tablespace_name = a.tablespace_name(+)
       AND d.tablespace_name = t.tablespace_name(+)
       AND d.extent_management LIKE 'LOCAL'
       AND d.contents LIKE 'TEMPORARY'
     ---  AND TO_CHAR (NVL (t.bytes / a.bytes * 100, 0), '990.00') > 75;
	 
=============================================================================
SELECT df.tablespace_name tablespace_name, max(df.autoextensible) auto_ext, round(df.maxbytes / (1024 * 1024), 2) max_ts_size, round((df.bytes - sum(fs.bytes)) / (df.maxbytes) * 100, 2) max_ts_pct_used,
 round(df.bytes / (1024 * 1024), 2) curr_ts_size, round((df.bytes - sum(fs.bytes)) / (1024 * 1024), 2) used_ts_size, round((df.bytes-sum(fs.bytes)) * 100 / df.bytes, 2) ts_pct_used,
 round(sum(fs.bytes) / (1024 * 1024), 2) free_ts_size, nvl(round(sum(fs.bytes) * 100 / df.bytes), 2) ts_pct_free FROM dba_free_space fs,
 (select tablespace_name, sum(bytes) bytes, sum(decode(maxbytes, 0, bytes, maxbytes)) maxbytes, max(autoextensible) autoextensible from dba_data_files group by tablespace_name) df
WHERE fs.tablespace_name (+) = df.tablespace_name GROUP BY df.tablespace_name, df.bytes, df.maxbytes having  NVL (ROUND (SUM (fs.bytes) * 100 / df.bytes), 2) < 25 UNION ALL
SELECT df.tablespace_name tablespace_name,  max(df.autoextensible) auto_ext, round(df.maxbytes / (1024 * 1024), 2) max_ts_size, round((df.bytes - sum(fs.bytes)) / (df.maxbytes) * 100, 2) max_ts_pct_used,
 round(df.bytes / (1024 * 1024), 2) curr_ts_size, round((df.bytes - sum(fs.bytes)) / (1024 * 1024), 2) used_ts_size, round((df.bytes-sum(fs.bytes)) * 100 / df.bytes, 2) ts_pct_used,
 round(sum(fs.bytes) / (1024 * 1024), 2) free_ts_size, nvl(round(sum(fs.bytes) * 100 / df.bytes), 2) ts_pct_free FROM (select tablespace_name, bytes_used bytes
 from V$temp_space_header group by tablespace_name, bytes_free, bytes_used) fs, (select tablespace_name, sum(bytes) bytes, sum(decode(maxbytes, 0, bytes, maxbytes)) maxbytes,
 max(autoextensible) autoextensible from dba_temp_files group by tablespace_name) df WHERE fs.tablespace_name (+) = df.tablespace_name GROUP BY df.tablespace_name, df.bytes, df.maxbytes --having  NVL (ROUND (SUM (fs.bytes) * 100 / df.bytes), 2) < 25
ORDER BY 7 DESC;

SELECT TABLESPACE_NAME TBSP_NAME
, USED_SPACE
, TABLESPACE_SIZE TBSP_SIZE
, round(USED_PERCENT,2) as USED_PERCENT
FROM SYS.DBA_TABLESPACE_USAGE_METRICS
where USED_PERCENT >=70
order by USED_PERCENT desc;

--=====================CHECK TABLE SIZE AGAINST FRAGMENTATION=======================
select
table_name,owner,round((blocks*8),2) "size (mb)" ,
round((num_rows*avg_row_len/1024*1024),2) "actual_data (mb)",
(round((blocks*8),2) - round((num_rows*avg_row_len/1024*1024),2)) "wasted_space (mb)"
from
dba_tables
where owner in ('ITX_RE','ITX_JOB','ITX_STG','ITX_CLD') and
(round((blocks*8),2) > round((num_rows*avg_row_len/1024*1024),2))-- and table_name like 'com_buyer_mst%'
order by 5 desc;

============================================
SELECT * FROM DBA_OBJECTS
WHERE OBJECT_NAME LIKE '%JOBS%';

SELECT * FROM V$RECOVERY_FILE_DEST; --V$RECOVERY_FILE_DEST, V_$RECOVERY_FILE_DEST

=================================================
CHECK DB TABLE SIZE
=================================================
select a.owner, a.segment_name as TBL_INDEX, a.GB, b.table_name
from (
   select
      owner,
      segment_name,
      bytes/1024/1024/1024 GB
   from
      dba_segments
   where
      segment_type IN ('INDEX') -- ('TABLE', 'INDEX')
   order by
      bytes/1024/1024/1024 desc) a, dba_indexes b
where
    a.segment_name = b.index_name and
   rownum <= 1000 and a.OWNER in ('ODS_DBA','STG_HIST','STG_OPS','STG_SRC', 'STG_WORK','ODS_CLIREC_USR')
   ORDER BY a.gb desc;
   
select tablespace_name, max(bytes/1024/1024/1024) size_GB, SEGMENT_NAME 
from dba_segments 
where SEGMENT_TYPE='TABLE' 
group by tablespace_name,SEGMENT_NAME,tablespace_name
order by size_GB;

select * from dba_indexes


select
   OWNER, SEGMENT_NAME AS TABLE_NAME, GB AS SIZE_IN_GB
from (
   select
      owner,
      segment_name,
      round(bytes/1024/1024/1024, 4) GB
   from
      dba_segments
   where
      segment_type = 'TABLE'
   order by
      bytes/1024/1024/1024 desc)
where
   rownum <= 1000;
   
--================================================================
--DBA CUSTOM_TBLS
SELECT USER_ID, USERNAME, DEFAULT_TABLESPACE,
CREATED,PROFILE,ACCOUNT_STATUS FROM DBA_USERS
ORDER BY USERNAME, ACCOUNT_STATUS;

--================================================================
--DBA OBJECT STATUS
SELECT OWNER,OBJECT_TYPE, 
OBJECT_NAME,CREATED,STATUS
FROM DBA_OBJECTS
WHERE STATUS = 'INVALID'
ORDER BY OWNER ASC;

--==============================================
--DBA SEQUENCE STATUS
SELECT SEQUENCE_OWNER,SEQUENCE_NAME,
LAST_NUMBER,MAX_VALUE,CYCLE_FLAG,
(CAST((CAST(LAST_NUMBER AS FLOAT)/ CAST(MAX_VALUE AS FLOAT)) AS DECIMAL(18,10)) * 100) AS PERCENTAGE_USAGE
FROM DBA_SEQUENCES
WHERE SEQUENCE_NAME LIKE '%CUSTOM%' AND CYCLE_FLAG = 'N';
--CAST(CAST(LAST_NUMBER AS FLOAT)/ CAST(MAX_VALUE AS FLOAT) AS DECIMAL(18,2)) * 100 AS [PERCENTAGE_USAGE]

--========================================================
SELECT * DUMP(MAX_VALUE) from DBA_SEQUENCES;

select count(*) from dba_objects;
select username from dba_users
where username LIKE 'A%';


--===================================
--DB REPLICATION STATUS CHECK
--====================================
SELECT * from v$database;
select min(fhscn) from x$kcvfh;

SELECT 
CURRENT_SCN, 
DATABASE_ROLE, 
SWITCHOVER_STATUS,
GUARD_STATUS as GAP_STATUS
from v$database;

--==========================================================
--DB TRANSACTIONS
--==========================================================
SELECT XID AS "txn id", XIDUSN AS "undo seg", XIDSLOT AS "slot", STATUS AS "txn status"
FROM V$TRANSACTION;

SELECT * FROM V$TRANSACTION;

--==================================
--USER SESSIONS
--=================================
SELECT * FROM V$SESSION
WHERE ROWNUM <=5;

SELECT USERNAME,SID, SERIAL#, STATUS, SERVER
FROM V$SESSION
WHERE USERNAME = 'REDBOX' AND STATUS = 'INACTIVE';

SELECT COUNT(*) FROM V$SESSION;
SELECT DISTINCT(USERNAME) FROM V$SESSION;


select s.sid
      ,s.serial#
      ,s.username
      ,s.machine
      ,s.status
      ,s.lockwait
      ,t.used_ublk
      ,t.used_urec
      ,t.start_time
from v$transaction t
inner join v$session s on t.addr = s.taddr
order by START_TIME DESC;

=======================================
FIND LOCKED SESSSIONS MAIN
==================================-===
select
b.sid, b.serial#,b.inst_id,b.machine,b.sql_exec_start,
d.start_time,c.owner,c.object_name,b.program,b.client_info,
b.status session_status,d.status transaction_status,b.state,
b.event, b.wait_time, b.seconds_in_wait
from
gv$locked_object a ,
gv$session b,
dba_objects c,
gV$transaction d
where b.sid = a.session_id
and a.object_id = c.object_id
and d.ses_addr = b.saddr 
--and c.owner not in ('SYS')
and b.username is not null 
--and b.username not in ('SYS','CUSTOM_TBLS')
--and ((b.sql_exec_start <  (sysdate - 1/24)) )
order by d.start_time asc;

set linesize 900
column SQL_TEXT format a70
column MACHINE format a20
column program format a30
column terminal format a30
SELECT vs.username, vs.osuser, vs.program, vp.spid,vs.PROCESS ,vs.sid, vs.serial#,
       vs.machine, vs.terminal, vq.sql_text
  FROM v$session vs, v$process vp, v$sql vq
WHERE vs.paddr = vp.addr
   AND vs.sql_address = vq.address(+)
   AND vs.sql_hash_value = vq.hash_value(+)
    AND vp.spid = '&ospid';

-KILL THE SESSION
alter system kill session '10,123,@45645' immediate;  ---first number is SID and second is Serial Number


--================================
ORACLE TRANSACTIONS
---===============================
----Find the uncommitted or incomplete transaction in Oracle
Query with V$transaction give result which transaction is not commited yet.

set lines 250
column start_time format a20
column sid format 999
column serial# format 999999
column username format a10
column status format a10
column schemaname format a10

select t.start_time,s.sid,s.serial#,s.username,s.status,s.schemaname,
s.osuser,s.process,s.machine,s.terminal,s.program,s.module,to_char(s.logon_time,'DD/MON/YY HH24:MI:SS') logon_time
from v$transaction t, v$session s
where s.saddr = t.ses_addr
order by start_time;

---Find the SQL statement for uncommitted transaction in Oracle

SELECT S.SID, S.SERIAL#, S.USERNAME, S.OSUSER, S.PROGRAM, S.EVENT
  ,TO_CHAR(S.LOGON_TIME,'YYYY-MM-DD HH24:MI:SS') 
  ,TO_CHAR(T.START_DATE,'YYYY-MM-DD HH24:MI:SS') 
  ,S.LAST_CALL_ET, S.BLOCKING_SESSION, S.STATUS
  ,( 
    SELECT Q.SQL_TEXT 
    FROM V$SQL Q 
    WHERE Q.LAST_ACTIVE_TIME=T.START_DATE 
    AND ROWNUM<=1) AS SQL_TEXT 
FROM V$SESSION S, 
  V$TRANSACTION T 
WHERE S.SADDR = T.SES_ADDR;

----Check your current session has uncommitted transaction if return one then it has uncommitted transaction

SELECT COUNT(*)
       FROM v$transaction t, v$session s, v$mystat m
      WHERE t.ses_addr = s.saddr
        AND s.sid = m.sid
        AND ROWNUM = 1;

--===================================================
--ORACLE DATABASE DICTIONARY
--===================================================
SELECT * FROM DICTIONARY
WHERE TABLE_NAME LIKE '%x$kcvfh%';

--ORDER BY TABLE_NAME;

SELECT file_name from dba_data_files;

select * from dba_data_files;

--=======================================
select open_mode, database_role, switchover_status from V$database
where ROWNUM <=2;

--====================================DATA GAUARD===================
SELECT name, value, datum_time, time_computed FROM V$DATAGUARD_STATS
WHERE name like 'apply lag';


======ORACLE DBA_REGISTERY========
select COMP_ID, COMP_NAME, VERSION, STATUS from dba_registry;

select count(*) from dba_objects
where status = 'INVALID';


=====SGA AND PGA IN ORACLE DATABASE=======
select PGA_ALLOCATED from DBA_HIST_ACTIVE_SESS_HISTORY
order by PGA_ALLOCATED DESC;

select name,value 
from v$parameter 
where name in ('memory_max_target','memory_target','sga_max_size',
'pga_aggregate_target','pga_aggregate_limit','shared_pool_size',
'large_pool_size','java_pool_size','db_cache_size','streams_pool_size')
ORDER BY value desc;

select name,value from v$parameter where name in ('memory_max_target','memory_target','sga_max_size',
'pga_aggregate_target','pga_aggregate_limit','shared_pool_size','large_pool_size','java_pool_size','db_cache_size','streams_pool_size');

=======ORACLE TIMEZONE VERSION=======
SELECT * FROM v$timezone_file;


SELECT TZNAME, TZABBREV 
FROM V$TIMEZONE_NAMES
ORDER BY TZNAME, TZABBREV;

SELECT UNIQUE TZNAME
FROM V$TIMEZONE_NAMES;


SELECT * FROM V$TRANSACTION
WHERE STATUS='ACTIVE';


SELECT tz_version FROM registry$database;

SELECT * FROM v$timezone_file;


======REVOKE PRIVILEGES FROM DB CUSTOM_TBLS=====
======REVOKE INSERT ON [TABLE] CUSTOM.FI_BULK_RATE_MOD FROM 'CRMUSER'=======
REVOKE INSERT ON TABLE_NAME FROM USER;
REVOKE INSERT ON [TABLE]  FROM USER
----------------------------------------------------
REVOKE INSERT ON CUSTOM.FI_BULK_RATE_MOD FROM USER_NAME;


==================FIND LOCKED CUSTOM_TBLS SESSIONS==========================
SELECT a.session_id, a.oracle_username, a.os_user_name,
b.owner "OBJECT OWNER", b.object_name, b.object_type, a.locked_mode
FROM (SELECT object_id, session_id, oracle_username, os_user_name,
locked_mode
FROM v$locked_object) a,
(SELECT object_id, owner, object_name, object_type
FROM dba_objects) b
WHERE a.object_id = b.object_id;


SELECT a.object_id, a.session_id, substr(b.object_name, 1, 40)
FROM v$locked_object a, dba_objects b
WHERE a.object_id = b.object_id
AND b.object_name like 'SYS%'
ORDER BY b.object_name;

=====Query to Check Failed Jobs in Oracle Database.=======

select JOB,LAST_DATE,THIS_DATE,NEXT_DATE,BROKEN,FAILURES,WHAT from dba_jobs where failures>0;

select count(*) from dba_jobs where FAILURES>0;

---Check status of user scheduled job-----
SELECT to_char(log_date, 'DD-MON-YY HH24:MM:SS') TIMESTAMP, job_name,
  job_class, operation, status FROM USER_SCHEDULER_JOB_LOG
  WHERE job_name = 'JOB2' ORDER BY log_date;
  
  
SELECT job_name, job_class, operation, status FROM USER_SCHEDULER_JOB_LOG;


select owner as schema_name,
       job_name,
       job_style,
       case when job_type is null 
                 then 'PROGRAM'
            else job_type end as job_type,  
       case when job_type is null
                 then program_name
                 else job_action end as job_action,
       start_date,
       case when repeat_interval is null
            then schedule_name
            else repeat_interval end as schedule,
       last_start_date,
       next_run_date,
       state
from sys.all_scheduler_jobs
order by owner,
         job_name;


======Find locked sessions=======
 
SELECT a.session_id, a.oracle_username, a.os_user_name,
b.owner "OBJECT OWNER", b.object_name, b.object_type, a.locked_mode
FROM (SELECT object_id, session_id, oracle_username, os_user_name,
locked_mode
FROM v$locked_object) a,
(SELECT object_id, owner, object_name, object_type
FROM dba_objects) b
WHERE a.object_id = b.object_id;

===Alternative with object name

SELECT a.object_id, a.session_id, substr(b.object_name, 1, 40)
FROM v$locked_object a, dba_objects b
WHERE a.object_id = b.object_id
AND b.object_name like 'SYS%'
ORDER BY b.object_name;
 

====Check for dead locks=====
select * from v$lock where request !=0;
 

====Killing the blocking session=====
select * from v$lock where type='TX' and id1='4718628' and id2='755268';
 

=======Another alternative to find locked sessions query========
SELECT lo.session_id AS sid,
s.serial#,
NVL(lo.oracle_username, '(oracle)') AS username,
o.owner AS object_owner,
o.object_name,
Decode(lo.locked_mode, 0, 'None',
1, 'Null (NULL)',
2, 'Row-S (SS)',
3, 'Row-X (SX)',
4, 'Share (S)',
5, 'S/Row-X (SSX)',
6, 'Exclusive (X)',
lo.locked_mode) locked_mode,
lo.os_user_name,
s.status
FROM v$locked_object lo
JOIN dba_objects o ON o.object_id = lo.object_id
JOIN v$session s ON lo.session_id = s.sid
--WHERE s.status = 'INACTIVE'
ORDER BY 1, 2, 3, 4;
 
--MY MAIN
select s.username,s.sid,s.serial#,s.last_call_et/60 mins_running,q.sql_text from v$session s 
join v$sqltext_with_newlines q
on s.sql_address = q.address
 where status='ACTIVE'
and type <>'BACKGROUND'
and last_call_et> 60
order by sid,serial#,q.piece;

select s.username,s.sid,s.serial#,round(s.last_call_et/3600) mins_running,q.sql_text from v$session s 
join v$sqltext_with_newlines q
on s.sql_address = q.address
 where status='ACTIVE'
and type <>'BACKGROUND'
and last_call_et> 60
order by sid,serial#,q.piece;

select s.INST_ID,s.sid,s.serial#,s.username,s.machine,s.status,s.last_call_et/60/60 as "Minutes",
s.sql_id,s.program from gv$session s where s.type='USER' AND s.status='ACTIVE' AND s.last_call_et>600
and s.SID='10465' and s.serial#='61930'
order by s.last_call_et/60/60 desc;

select
b.sid, b.serial#,b.inst_id,b.sql_exec_start,d.start_time,c.owner,c.object_name,b.program,b.client_info,b.status session_status,d.status transaction_status,b.state,b.event, b.wait_time, b.seconds_in_wait
from
gv$locked_object a ,
gv$session b,
dba_objects c,
gV$transaction d
where b.sid = a.session_id
and a.object_id = c.object_id
and d.ses_addr = b.saddr 
--and c.owner not in ('SYS')
and b.username is not null 
--and b.username not in ('SYS','CUSTOM_TBLS')
--and ((b.sql_exec_start <  (sysdate - 1/24)) )
order by d.start_time asc;

alter system kill session '4510,15957, @1' immediate;



select * from dba_scheduler_jobs where enabled='TRUE' and state = 'RUNNING' order by LAST_START_DATE desc;

640	34440
select * from gv$session where sid='640';

select INST_ID,SID,SERIAL#, USERNAME,STATUS,SCHEMANAME,OSUSER,MACHINE,TERMINAL,PROGRAM,
SQL_ID,MODULE,ACTION,CLIENT_INFO,EVENT,WAIT_CLASS,WAIT_TIME,STATE,SERVICE_NAME
from gv$session where sid='10465';

select * from gv$sql where SQL_ID='3hn5uatavm2r3';
select * from gv$session where inst_id=10811 and PREV_SQL_ID='fbt9jj22rgb0c';

Check SID and SQL query associated with OS Process ID(PID) in Oracle
check Session id from OS process id in Oracle


SELECT sql_id 
  FROM gv$session
 WHERE event='enq: TX - row lock contention'
   AND state='WAITING';

select INST_ID,SQL_TEXT,SQL_FULLTEXT,SQL_ID,USERS_OPENING,EXECUTIONS,END_OF_FETCH_COUNT
USER_EXECUTING,FIRST_LOAD_TIME,PARSE_CALLS,DISK_READS,APPLICATION_WAIT_TIME,CONCURRENCY_WAIT_TIME
,CLUSTER_WAIT_TIME,USER_IO_WAIT_TIME,PLSQL_EXEC_TIME,ROWS_PROCESSED,PARSING_SCHEMA_NAME,MODULE,ACTION,
CPU_TIME,ELAPSED_TIME,REMOTE,OBJECT_STATUS,LAST_LOAD_TIME,LAST_ACTIVE_TIME
from gv$sqlarea where SQL_id in('2jmvy3fd0mr6k','0yymw8q7c118f');



SELECT row_wait_obj#       AS object,
       row_wait_file#      AS datafile,
       row_wait_block#     AS datablock,
       row_wait_row#       AS rowinfo
  FROM gv$session
 WHERE event='enq: TX - row lock contention'
   AND state='WAITING'; 
 --AGENTS  
select object_name from dba_objects where object_id in (14047794);

SELECT gvs.inst_id,DECODE (request, 0, 'Holder: ', 'waiter:') || gvl.sid     sess,
         status,
         id1,
         id2,
         lmode,
         request,
         gvl.TYPE
    FROM gv$lock gvl, gv$session gvs
   WHERE     (id1, id2, gvl.TYPE) IN (SELECT id1, id2, TYPE
                                        FROM gv$lock
                                       WHERE request > 0)
         AND gvl.sid = gvs.sid and gvl.inst_id=gvs.inst_id
ORDER BY id1, request;

--2	Holder: 10638	INACTIVE	32768018	1732572	6	0	TX
select SADDR,serial# from gv$session where sid in (6611,8368) and inst_id=2; --0000001702F8D388

select saddr,inst_id,sid,sql_id,sql_text,LAST_SQL_ACTIVE_TIME, CURSOR_TYPE from gv$open_cursor  
where saddr in ('00000016A29CE9F0','0000001702C73508') and inst_id=2 and cursor_type='OPEN'
order by LAST_SQL_ACTIVE_TIME desc;  --2jmvy3fd0mr6k b6xbdu1hfkjyd


select INST_ID,SQL_TEXT,SQL_FULLTEXT,SQL_ID,USERS_OPENING,EXECUTIONS,END_OF_FETCH_COUNT
USER_EXECUTING,FIRST_LOAD_TIME,PARSE_CALLS,DISK_READS,APPLICATION_WAIT_TIME,CONCURRENCY_WAIT_TIME
,CLUSTER_WAIT_TIME,USER_IO_WAIT_TIME,PLSQL_EXEC_TIME,ROWS_PROCESSED,PARSING_SCHEMA_NAME,MODULE,ACTION,
CPU_TIME,ELAPSED_TIME,REMOTE,OBJECT_STATUS,LAST_LOAD_TIME,LAST_ACTIVE_TIME
from gv$sqlarea where SQL_id in('95yk65q50sa2n','2cwczzga82hzh');


SELECT b.spid,
a.sid,
a.serial#,
a.username,
a.osuser
FROM v$session a, v$process b
WHERE a.paddr = b.addr AND b.spid = '&spid'
ORDER BY b.spid

Check SQL statement associated with Process id in Oracle

SELECT RPAD('USERNAME : ' || s.username, 80) ||
RPAD('OSUSER : ' || s.osuser, 80) ||
RPAD('PROGRAM : ' || s.program, 80) ||
RPAD('SPID : ' || p.spid, 80) ||
RPAD('SID : ' || s.sid, 80) ||
RPAD('SERIAL# : ' || s.serial#, 80) ||
RPAD('MACHINE : ' || s.machine, 80) ||
RPAD('TERMINAL : ' || s.terminal, 80)
--RPAD('SQL TEXT : ' || q.sql_text, 80)
FROM v$session s ,v$process p ,v$sql q
WHERE s.paddr = p.addr AND s.sql_address = q.address AND s.sql_hash_value = q.hash_value
AND p.spid = '&spid'

===Kill locked session====
ALTER CUSTOM_TBLS KILL SESSION 'sid,serial# @instance ID' immediate;
select 'alter system kill session ''' ||sid|| ',' || serial#|| ''' immediate;' from gv$session where program like 'HXFER%';
alter system kill session 'sid,serial# @instance ID';

alter system kill session '9850,37810, @2' immediate;

SQL> ALTER SYSTEM DISCONNECT SESSION '245,23' IMMEDIATE;

System altered.

SQL> ALTER SYSTEM DISCONNECT SESSION '245,23' IMMEDIATE;

System altered.

SQL> select sid, serial#,status from v$session where sid=245;

select * from dba_lock;


===========================================
KILL A SESSION BLOCKING PACKAGE RECOMPILE
==========================================
BREAK ON sid ON lock_id1 ON kill_sid

COL sid            FOR 999999
COL lock_type      FOR A38
COL mode_held      FOR A12
COL mode_requested FOR A12
COL lock_id1       FOR A20
COL lock_id2       FOR A20
COL kill_sid       FOR A50

SELECT s.sid,
       l.lock_type,
       l.mode_held,
       l.mode_requested,
       l.lock_id1,
       'alter system kill session '''|| s.sid|| ','|| s.serial#|| ''' immediate;' kill_sid
FROM   dba_lock_internal l,
       v$session s
WHERE  s.sid = l.session_id
AND    UPPER(l.lock_id1) LIKE '%&package_name%'
AND    l.lock_type = 'Body Definition Lock'
/

NOTE: If your dba_lock_internal view doesn’t exist, you can create this by running: $ORACLE_HOME/rdbms/admin/catblock.sql

Check out what the offending session is doing:

BREAK ON sid ON username ON osuser ON os_pid ON program

SELECT s.sid,
       NVL(s.username, 'ORACLE PROC') username,
       s.osuser,
       p.spid os_pid,
       s.program,
       t.sql_text
FROM   v$session s,
       v$sqltext t,
       v$process p
WHERE  s.sql_hash_value = t.hash_value
AND    s.paddr = p.addr
AND    s.sid = &session_id
AND    t.piece = 0 -- optional to list just the first line
ORDER BY s.sid, t.hash_value, t.piece
/


https://snapdba.com/2013/03/how-to-recompile-a-plsql-package-locked-by-another-user/

==========================================================
==Another alternative to find locked sessions query====
==========================================================

SELECT
c.sid,
substr(object_name,1,20) OBJECT,
c.username,
substr(c.program,length(c.program)-20,length(c.program)) image,
DECODE(b.type,
'MR', 'Media Recovery',
'RT', 'Redo Thread',
'UN', 'User Name',
'TX', 'Transaction',
'TM', 'DML',
'UL', 'PL/SQL User Lock',
'DX', 'Distributed Xaction',
'CF', 'Control File',
'IS', 'Instance State',
'FS', 'File Set',
'IR', 'Instance Recovery',
'ST', 'Disk Space Transaction',
'TS', 'Temp Segment',
'IV', 'Library Cache Invalidation',
'LS', 'Log Start or Switch',
'RW', 'Row Wait',
'SQ', 'Sequence Number',
'TE', 'Extend Table',
'TT', 'Temp Table',
b.type) lock_type,
DECODE(b.lmode,
0, 'None', /* Mon Lock equivalent */
1, 'Null', /* NOT */
2, 'Row-SELECT (SS)', /* LIKE */
3, 'Row-X (SX)', /* redbox.R */
4, 'Share', /* SELECT */
5, 'SELECT/Row-X (SSX)', /* C */
6, 'Exclusive', /* X */
to_char(b.lmode)) mode_held,
DECODE(b.request,
0, 'None', /* Mon Lock equivalent */
1, 'Null', /* NOT */
2, 'Row-SELECT (SS)', /* LIKE */
3, 'Row-X (SX)', /* redbox.R */
4, 'Share', /* SELECT */
5, 'SELECT/Row-X (SSX)', /* C */
6, 'Exclusive', /* X */
to_char(b.request)) mode_requested
FROM sys.dba_objects a, sys.v_$lock b, sys.v_$session c WHERE
a.object_id = b.id1 AND b.sid = c.sid AND OWNER NOT IN ('SYS','CUSTOM_TBLS');



====Another alternative to find locked sessions query=====

  SELECT lo.session_id,
         lo.oracle_username,
         lo.os_user_name,
         lo.process,
         do.object_name,
         DECODE (lo.locked_mode,
                 0, 'None',
                 1, 'Null',
                 2, 'Row Share (SS)',
                 3, 'Row Excl (SX)',
                 4, 'Share',
                 5, 'Share Row Excl (SSX)',
                 6, 'Exclusive',
                 TO_CHAR (lo.locked_mode))
             mode_held
    FROM v$locked_object lo, dba_objects do
   WHERE lo.object_id = do.object_id
ORDER BY 1, 5



=====ARCHIVING TABLE IN FINACLE=======
create table tbaadm.mcd_09JAN2023 AS select * from tbaadm.mcd;


--then 

delete from tbaadm.mcd where commodity_code='OT'

commit;


=====RUN ORACLE(FINANCLE) PACKAGES========
BEGIN    

	CRMUSER.STE_MAIN_PKG.MONTHLY_STATEMENT_QUERIES();  
	COMMIT;
END; 

BEGIN  
  
	CRMUSER.STE_MAIN_PKG.MONTHLY_LOAN_STATEMENT_QUERIES();  
	COMMIT;
END;

 
 
 
===RESOLVING RESOLVABLE GAP AND LOG_SWITCH_GAP IN ORACLE DATABASE===



======INCREASING SQL SERVER DB DATAFILE=======
ALTER DATABASE [NewDatabase]
MODIFY FILE
(NAME = 'NewDatabase_log',
SIZE = 200MB,
FILEGROWTH = 1MB)


=======CHECK PROCEDURES IN ORACLE DATABASE=======
SELECT * FROM USER_PROCEDURES
WHERE ROWNUM <=2;

SELECT * FROM ALL_PROCEDURES
WHERE OWNER = 'CRMUSER' AND OBJECT_NAME = 'ISRM_PKG';-- AND ROWNUM<=2;

SELECT * FROM DBA_PROCEDURES
WHERE OWNER = 'CRMUSER' AND OBJECT_NAME = 'ISRM_PKG';


SELECT * FROM USER_OBJECTS
WHERE OBJECT_NAME = 'ISRM_PKG';


========ADDING A DATAFILE FROM ORACLE DATABASE TABLESPACE=========
asmcmd  ----Automatic Storage Manager Command Prompt

rm -  ----This adds 3 datafiles to the tablespace.

ALTER TABLESPACE CUSTOM_TBLS ADD DATAFILE SIZE 32767M AUTOEXTEND ON NEXT 1G MAXSIZE UNLIMITED;


ALTER TABLESPACE UNDOTBS2 ADD DATAFILE SIZE 31G AUTOEXTEND ON NEXT 1G MAXSIZE UNLIMITED;

+DATA/PNGFIB/DATAFILE/undotbs1.1005.1049289575 to 31
+DATA/PNGFIB/DATAFILE/undotbs1.2881.1055497975 to 31

Alter database datafile '+DATA/PNGFIB/DATAFILE/undotbs1.1005.1049289575' resize 31G;
Alter database datafile '+DATA/PNGFIB/DATAFILE/undotbs1.2881.1055497975' resize 31G;

Alter database datafile '+DATA/PNGFIB/DATAFILE/undotbs2.2886.1055497887' resize 31G;
Alter database datafile '+DATA/PNGFIB/DATAFILE/undotbs2.2977.1055497661' resize 31G;
Alter database datafile '+DATA/PNGFIB/DATAFILE/undotbs2.2882.1055497955' resize 31G;
Alter database datafile '+DATA/PNGFIB/DATAFILE/undotbs2.2884.1055497921' resize 31G;
Alter database datafile '+DATA/PNGFIB/DATAFILE/undotbs2.2888.1055497853' resize 31G;	
Alter database datafile '+DATA/PNGFIB/DATAFILE/undotbs2.2963.1055497819' resize 31G;	
Alter database datafile '+DATA/PNGFIB/DATAFILE/undotbs2.2966.1055497783' resize 31G;	
Alter database datafile '+DATA/PNGFIB/DATAFILE/undotbs2.2969.1055497743' resize 31G;	
Alter database datafile '+DATA/PNGFIB/DATAFILE/undotbs1.2978.1055497655' resize 31G;	

+DATA/PNGFIB/DATAFILE/undotbs1.2978.1055497655



====================Mongodb connection string===============
mongodb://A226547:STanbic_1234#@pngmobiledb02v:27017/?directConnection=trueQ'[&]' authMechanism=DEFAULTQ'[&]' readPreference=secondaryPreferredQ'[&]' authSource=stanbic

mongodb://<user>:<password>@pngmobiledb02v:27017/?directConnection=trueQ'[&]' authMechanism=DEFAULTQ'[&]' readPreference=secondaryPreferredQ'[&]' authSource=stanbic
STanbic_1234#

===============CHECK ORACLE DATABASE SERVICES STATUS============
sudo systemctl status oracle-database

sudo systemctl status oracle_database_name

======DB LINK=============
--Create A dblink
CREATE DATABASE LINK LINK_NAME
CONNECT FROM DB_USERNAME
IDENTIFIED BY DB_USERNAME'S_PASSWORD
USING 'SERVICE_NAME';

--DROP PUBLIC DATABASE LINK EBANKING_LINK; 
CREATE PUBLIC DATABASE LINK EBANKING_LINK
CONNECT FROM APPLOGIN
IDENTIFIED BY applogin
USING '(DESCRIPTION =    
(ADDRESS = (PROTOCOL = TCP)(HOST = 10.234.206.141)(PORT = 1521))    
(CONNECT_DATA =    (SERVER = DEDICATED)    (SERVICE_NAME = ungrdbox)))';

SELECT DB_LINK, USERNAME, HOST FROM ALL_DB_LINKS;
--DBA_DB_LINKS - All DB links defined in the database
--ALL_DB_LINKS - All DB links the current user has access to
--USER_DB_LINKS - All DB links owned by current user

DESC DBA_DB_LINKS;

SELECT * FROM DBA_DB_LINKS;

SELECT * FROM USER_DB_LINKS;


--set up the link:

exec sp_addlinkedserver  @server='10.10.0.10\MyDS';

--set up the access for remote user, example below:

exec sp_addlinkedsrvlogin  '10.10.0.10\MyDS', 'false', null, 'adm', 'pwd';

--see the linked servers and user logins:

exec sp_linkedservers;

select * from sys.servers;

select * from  sys.linked_logins;

--run the remote query:

select * from [10.10.0.10\MyDS].MyDB.dbo.TestTable;

--drop the linked server and the created login users (adm/pwd)

exec sp_dropserver '10.10.0.10\MyDS', 'droplogins'; -- drops server and logins




===PROFILE ON CYBERARK=====
10.234.18.75
10.234.17.83

12.1 not 19.

line 2 to 8 should come under oda

Security control standards on jump server
Jobs that kill long running sessions that in Oracle.
Grafana

Disbaling users on database after 30 days of inactivity.

17.15 is old datastore
timeline regarding dates


=====EXECUTE JOBS====================
DESC CRMUSER.REDBOX_REVERSAL_JOB;

DECLARE 
SYS.DBMS_SCHEDULER varchar2(25);
BEGIN
  SYS.DBMS_SCHEDULER.STOP_JOB
    (job_name   => 'CRMUSER.REDBOX_REVERSAL_JOB'
    ,force      => FALSE);
END;


DESC CRMUSER.REDBOX_REVERSAL_JOB;
begin
  dbms_scheduler.stop_job( job_name => 'CRMUSER.REDBOX_REVERSAL_JOB');
end;


DESC CRMUSER.REDBOX_REVERSAL_JOB;
begin
  dbms_scheduler.stop_job( job_name => 'CRMUSER.REDBOX_REVERSAL_JOB');
end;
EXEC DBMS_SCHEDULER.STOP_JOB (job_name => 'JOB_NAME');


===CHECK COUNT AND ACTIVE SESSIONS=======
SELECT name, value, type,DESCRIPTION
FROM v$parameter
WHERE name = 'sessions';

--The number of sessions currently active
SELECT COUNT(*)
FROM v$session




---------------------------------------------------
File Type 	           Where to Find Statistics 
---------------------------------------------------
Database Files -------- V$FILESTAT, V$SYSTEM_EVENT, V$SESSION_EVENT
 
Log Files ------------ V$SYSSTAT, V$SYSTEM_EVENT, V$SESSION_EVENT
 
Archive Files ------  V$SYSTEM_EVENT, V$SESSION_EVENT
 
Control Files -----  V$SYSTEM_EVENT, V$SESSION_EVENT

SELECT NAME, PHYRDS, PHYWRTS
FROM V$DATAFILE df, V$FILESTAT fs
WHERE df.FILE# = fs.FILE#;


--===================================
ORACLE RESOURCES LIMITS
=======================================
SELECT name, value, type,DESCRIPTION FROM v$parameter WHERE name = 'sessions';

SELECT * FROM v$resource_limit;
select * from v$spparameter;

select resource_name,current_utilization, limit_value from v$resource_limit 
where resource_name in ('sessions','processes','transactions') order by resource_name;

SELECT name, value, type,DESCRIPTION FROM v$parameter where name in ('sessions','processes','transactions') order by name;

processes=X

session = (1.5 * PROCESSES) + 22

transactions = sessions * 1.1


======SQL COMMAND LINE(SQLcl)=======================
sql mekus/password@oracle:1521/racdb1

info table_or_dictionary to see detail info. eg

info v$database
info v$parameter
info v$parameter2
info v$spparameter
info v$system_parameter2


set sqlformat;
set markup csv on;

=========================================================
=======================ADRCI=======================
=========================================================
show homes;
show alert;

select SHORTP_POLICY, LONGP_POLICY from ADR_CONTROL;  ---This show ADR rentention policy
/u01/app/oracle/diag/rdbms
/u01/app/oracle/diag/rdbms/pngrdbox/pngrdbox1:

SHORT RENTENTION policy is used for traces and core dumps
LONG RENTENTION is used for incident and alert logs

PURGE -age 1440 -type ALERT
PURGE -age 1440 -type TRACE

===MODIFY SPFILE LOCATION=====
svrctl modify database -d database_name -spfile path_to_spfile

svrctl config database ---shows database running in the RAC.

======================================
====GENERATE ORACLE AWR=============
======================================
select output 
from table(dbms_workload_repository.awr_report_html(3998855182, 1, 21655, 21656));

select output 
from table(dbms_workload_repository.awr_report_text(3998855182, 1, 21655, 21656)); --3998855182

select dbid from v$database; --to find dbid 4202697316

select snap_id,
       begin_interval_time
       end_interval_time
from dba_hist_snapshot
order by begin_interval_time desc; --to find snap_id  18012 18013

SQL script for getting AWR Report on RAC database:
SQL>@$ORACLE_HOME/rdbms/admin/awrgrpt.sql

SQL script for getting AWR Report for  single instance:
SQL>@$ORACLE_HOME/rdbms/admin/awrrpt.sql

SQL script for getting ASH Report on RAC database:
SQL>@$ORACLE_HOME/rdbms/admin/ashrpti.sql

SQL script for getting ASH Report for single Instance:
SQL>@$ORACLE_HOME/rdbms/admin/ashrpt.sql

SQL script for getting ADDM Report on RAC database:
SQL>@$ORACLE_HOME/rdbms/admin/addmrpti.sql

SQL script for getting ADDM Report for single instance:
SQL>@$ORACLE_HOME/rdbms/admin/addmrpt.sql

/tfactl diagcollect -all -from "Dec/24/2023 04:00:00" -to " Dec/24/2023 09:00:00"

$TFA_HOME/bin/tfactl diagcollect -srdc dbperf

================================
GENERATE TFA_HOME/bin/tfactl
==================================
  978  gzip help
  979  gzip -c messages > messages-10.gz
  980  ls
  981  gzip -d messages-10.gz
  982  ls
  983  cat messages-10
  984  ls
  985  rm messages-10
  986  clear
  987  ls -lrt
  988  clear
  989  gzip -c messages > messages-10.gz
  990  chmod 775 messages-10.gz
  991  history
  992  exit
  993  cd /opt/oracle.ahf

Alert Log of the same period above – Only send trim of the 24 hour within EOM period. Not all the large
alertlog
SQL>@$diagnostic_dest/diag/dbname/SID/trace/alert_SID.log


Optionally collect and review latest orachk output
- Download latest Orachk - Health Checks for the Oracle Stack(Doc ID 1268927.2)
$ orachk –a -o v

--Gather Database dictionary statistics. To gather stats run below:
exec DBMS_STATS.GATHER_DICTIONARY_STATS;

--Gather database Fixed Object statistics
execute dbms_stats.gather_fixed_objects_stats;


--Consider Gathering fresh statistics for the Application schemas
EXEC DBMS_STATS.GATHER_SCHEMA_STATS
('<schema_name>');
Or
BEGIN
DBMS_STATS.GATHER_TABLE_STATS('<schema_nam
e>', '<table_name>');
END;
/
You can add more stats gathering options to go
more granular as desired.


=====================================================
ORACLE CUSTOM_TBLS ROLE AND PRIVILEGES
=====================================================
select * from 
((dba_tab_privs d 
inner join dba_sys_privs s
on d.GRANTEE = s.GRANTEE)
inner join dba_role_privs rl
on d.GRANTEE = rl.GRANTEE)
where d.GRANTEE = 'USERNAME_HERE';


select al.table_name,al.owner,al.tablespace_name,t.grantee, r.granted_role,t.privilege from ((ALL_TABLES al
left join dba_tab_privs t
on al.owner = t.owner)
left join dba_role_privs r
on t.GRANTEE = r.GRANTEE)
where t.grantee = 'A204505' and r.granted_role = 'APPS_LEVEL_3'
order by t.privilege desc;

select al.table_name,al.owner,al.tablespace_name,t.grantee, r.granted_role,t.privilege from ((ALL_TABLES al
inner join dba_tab_privs t
on al.owner = t.owner)
inner join dba_role_privs r
on t.GRANTEE = r.GRANTEE)
where t.grantee = 'A204505' and r.granted_role = 'APPS_LEVEL_3'
order by t.privilege desc;

select al.table_name,al.owner,al.tablespace_name,t.grantee, r.granted_role,t.privilege from ((ALL_TABLES al
left join dba_tab_privs t
on al.owner = t.owner)
left join dba_role_privs r
on t.GRANTEE = r.GRANTEE)
where t.grantee IN 
('A204505',  
'EA244708T1',
'EA258882T1',
'EA255145T1',
'EA238413T1',
'A253761',
'EA255332T1',
'EA244258T1',
'A243684',
'EA225523',  
'EA255205T1',
'EA254727T1',
'EA255136T1',
'A250333',
'EA255009T1',
'EA249603T1')
and r.granted_role != 'CONNECT'
order by t.privilege desc;

select al.table_name,al.owner,t.grantee as USERNAME, r.granted_role,t.privilege from ((ALL_TABLES al
left join dba_tab_privs t
on al.owner = t.owner)
left join dba_role_privs r
on t.GRANTEE = r.GRANTEE)
where t.grantee IN 
('A204505',
'EA244708T1',
'EA258882T1',
'EA255145T1',
'EA238413T1',
'A253761',
'EA255332T1',
'EA244258T1',
'A243684',
'EA225523',  
'EA255205T1',
'EA254727T1',
'EA255136T1',
'A250333',
'EA255009T1',
'EA249603T1')
and r.granted_role != 'CONNECT'
order by t.grantee asc;


--=======================================
---CHECK ACTIVE SESSION FOR PDB DATABASES
--=======================================
select
s.type,
p.name,
p.inst_id,
s.status,
s.server,
s.module, --s.type,p.name,p.inst_id,s.status,s.server,s.machine,s.module
s.machine,
count(*) cnt
from
gv$session s inner join gv$pdbs p on p.con_id = s.con_id and p.inst_id = s.inst_id
group by s.type,p.name,p.inst_id,s.status,s.server,s.module,s.machine
order by 1,2,3;


============================
FIND LONG RUNNING SESSIONS
============================
select SID, OPNAME,TARGET,TARGET_DESC,TOTALWORK,UNITS,START_TIME,
LAST_UPDATE_TIME,TIMESTAMP,MESSAGE,USERNAME,SQL_ADDRESS from v$session_longops;


===================
SEGMENT CHECKS
=======================
select a.owner, a.segment_name as TBL_INDEX, a.GB, b.table_name
from (
   select
      owner,
      segment_name,
      bytes/1024/1024/1024 GB
   from
      dba_segments
   where
      segment_type IN ('INDEX') -- ('TABLE', 'INDEX')
   order by
      bytes/1024/1024/1024 desc) a, dba_indexes b
where
    a.segment_name = b.index_name and
   rownum <= 1000 and a.OWNER in ('ODS_DBA','STG_HIST','STG_OPS','STG_SRC', 'STG_WORK','ODS_CLIREC_USR')
   ORDER BY a.gb desc;
   
select * from dba_indexes


select
   OWNER, SEGMENT_NAME AS TABLE_NAME, GB AS SIZE_IN_GB
from (
   select
      owner,
      segment_name,
      bytes/1024/1024/1024 GB
   from
      dba_segments
   where
      segment_type = 'TABLE'
   order by
      bytes/1024/1024/1024 desc)
where
   rownum <= 1000;
   
   
SELECT df.tablespace_name "Tablespace",
  totalusedspace "Used MB",
  (df.totalspace - tu.totalusedspace) "Free MB",
  df.totalspace "Total MB",
  ROUND(100 * ( (df.totalspace - tu.totalusedspace)/ df.totalspace)) "% Free"
FROM
  (SELECT tablespace_name,
    ROUND(SUM(bytes) / 1048576) TotalSpace
  FROM dba_data_files
  GROUP BY tablespace_name
  ) df,
  (SELECT ROUND(SUM(bytes)/(1024*1024)) totalusedspace,
    tablespace_name
  FROM dba_segments
  GROUP BY tablespace_name
  ) tu
WHERE df.tablespace_name = tu.tablespace_name;

====================
ORACLE ASM
====================
select GROUP_NUMBER,NAME,BLOCK_SIZE,STATE,TYPE,TOTAL_MB/1024 as TOTAL_GB,FREE_MB/1024 as FREE_GB from v$asm_diskgroup;

select GROUP_NUMBER,NAME,STATE,TYPE,round(TOTAL_MB/1024/1024) TOTAL_MB, round(FREE_MB/1024/1024)  FREE_MB from v$asm_diskgroup;
select GROUP_NUMBER,NAME,STATE,TYPE,TOTAL_MB/1024/1024 TOTAL_TB, FREE_MB/1024/1024 FREE_TB from v$asm_diskgroup;

select
   g.name "GROUP_NAME",
   g.group_number,
   d.header_status,
   sum(d.total_mb) "TOTAL_MB",
   sum(d.free_mb) "FREE_MB",
   sum(d.total_mb)-sum(d.free_mb) "USED_MB",
  round((sum(d.total_mb)-sum(d.free_mb)) / sum(d.total_mb) * 100) "PERCENT_USED"
from
   v$asm_disk d,
   v$asm_diskgroup g
where
   d.group_number = g.group_number (+)
and
   d.header_status = 'MEMBER'
group by
   g.name,
   g.group_number,
   d.header_status
order by
   g.name;
 
 
Here is another query using v$asm_diskgroup:

with t as (
   select
      t.group_name,
      t.group_number,
      t.header_status,
      t.total_mb,
      t.free_mb,t.used_mb,
      round(t.used_mb/t.total_mb,2)*100 percent_calc
   from
      v$asm_diskgroup t)

select
   t.group_name,
   t.group_number,
   t.header_status,
   t.total_mb,
   t.free_mb - n.decompte free_mb,
   t.used_mb + n.decompte used_mb,
   round((t.used_mb + n.decompte)/t.total_mb,2)*100 percent
from
   t,
  (select (level-1)*5000 decompte from dual connect by level <= 10) n
where
   t.group_name = 'FRA';
   
   
===========================================================
ADD ASM DISK GROUP
==========================================================
alter diskgroup PDATA add disk '/dev/ora-pdata108';

alter diskgroup PDATA add disk '/dev/ora-pdata92';

alter diskgroup PDATA add disk '/dev/ora-pdata91';
ALTER DISKGROUP PDATA REBALANCE POWER 11 NOWAIT;
   
=============================
FRA CHECKS
=============================

show parameter db_recovery_file_dest;

The Current FRA size we can check with the help of view v$recovery_area_usage for each file usage.
select * from v$recovery_area_usage;

Check overall size and usages of FRA with the help of v$recovery_file_dest view.
select name,round(space_limit / 1024 / 1024) size_mb,round(space_used/1024/1024) used_mb,decode(nvl(space_used,0),0,0,round((space_used/space_limit) * 100)) pct_used
from v$recovery_file_dest order by name;

=============================================
EXPORT DBCA AND RUNINSTALLER DISPLAY
=============================================
export DISPLAY=10.234.22.48:0.0
export CV_ASSUME_DISTID=OEL7.9


export DISPLAY=10.234.178.82:0.0


./gridSetup.sh -applyRU /u01/app/19.0.0/34130714/


./runInstaller.sh -applyRU /u01/app/oracle/34130714/

./emcli login -username=sysman

./emcli sync

./emcli get_supported_platforms


./emcli get_agentimage -destination=/tmp/agentinstaller -platform="Linux x86-64"

=======================
ODA ENVIRONMENT DETAILS
=======================
https://dev.mysql.com/doc/mysql-yum-repo-quick-guide/en/
https://pngoda7:7093/mgmt/index.html
SQwer_1234#

==============================
ORACLE AUTONOMOUS DB TRAINING
===============================
bit.ly/mdw_lab
bit.ly/mdw_freetrial


=============================================
ORACLE DATABASE QUERY TUNNING TASK
=============================================
set serveroutput on
DECLARE l_sql_tune_task_id VARCHAR2(100);
BEGIN
l_sql_tune_task_id := DBMS_SQLTUNE.create_tuning_task (
sql_id => 'f6n3p9zp8m3dq',
scope =>  DBMS_SQLTUNE.scope_comprehensive,
time_limit => 500,
task_name => 'f6n3p9zp8m3dq_tune_task',
description => 'Tunning task for sql statement f6n3p9zp8m3dq');
DBMS_OUTPUT.put_line('l_sql_tune_task_id: ' || l_sql_tune_task_id);
END;
/
l_sql_tune_task_id: f6n3p9zp8m3dq_tune_task

=======================
As per ADDM reports :
=======================  
Please generate the SQL Tuning Advisor for sql ids 3vv0uzwkm9kag and aq7r3w3rccup4
 
 
---creating the tuning task
set serveroutput on
declare
 l_sql_tune_task_id  varchar2(100);
 
begin
 l_sql_tune_task_id := dbms_sqltune.create_tuning_task (
                         sql_id      => '3vv0uzwkm9kag',
                         scope       => dbms_sqltune.scope_comprehensive,
                         time_limit  => 600,
                         task_name   => 't1',
                         description => 'tuning task for statement your_sql_id.');
 dbms_output.put_line('l_sql_tune_task_id: ' || l_sql_tune_task_id);
 
end;
 
/
 
-- executing the tuning task
 
exec dbms_sqltune.execute_tuning_task(task_name => 't1');
  
-- displaying the recommendations
 
set long 100000;
set longchunksize 1000
set pagesize 10000
set linesize 100
select dbms_sqltune.report_tuning_task('t1') as recommendations from dual;

Using the DBMS_SQLTUNE Package to Run the SQL Tuning Advisor (Doc ID 262687.1)



=============================
Below script will display execution history of an sql_id from AWR. It will join dba_hist_sqlstat and dba_hist_sqlsnapshot table to get the required information.
select a.instance_number inst_id, a.snap_id,a.plan_hash_value, to_char(begin_interval_time,'dd-mon-yy hh24:mi') btime, abs(extract(minute from (end_interval_time-begin_interval_time)) + extract(hour from (end_interval_time-begin_interval_time))*60 + extract(day from (end_interval_time-begin_interval_time))*24*60) minutes,executions_delta executions, round(ELAPSED_TIME_delta/1000000/greatest(executions_delta,1),4) "avg duration (sec)" from dba_hist_SQLSTAT a, dba_hist_snapshot bwhere sql_id='&sql_id' and a.snap_id=b.snap_idand a.instance_number=b.instance_numberorder by snap_id desc, a.instance_number;


DECLARE

  l_sql_tune_task_id  VARCHAR2(100);

BEGIN

  l_sql_tune_task_id := DBMS_SQLTUNE.create_tuning_task (

                          sql_id      => '90pfsknfb50w5',

                          scope       => DBMS_SQLTUNE.scope_comprehensive,

                          time_limit  => 60,

                          task_name   => '90pfsknfb50w5_a_tuning_task',

                          description => 'Tuning task for statement 90pfsknfb50w5');

  DBMS_OUTPUT.put_line('l_sql_tune_task_id: ' || l_sql_tune_task_id);

END;

/
 
 
EXEC DBMS_SQLTUNE.execute_tuning_task(task_name => '90pfsknfb50w5_a_tuning_task');
 
---SELECT * FROM dba_advisor_log 	where task_name='1wmd6ujvzrvk5_tuning_task'
 
 
SET LONG 10000;

SET PAGESIZE 4000

SET LINESIZE 300

SELECT DBMS_SQLTUNE.report_tuning_task('90pfsknfb50w5_a_tuning_task') AS recommendations FROM dual;

SET PAGESIZE 24
 
.
tuningtask1.txt
 


DECLARE

  l_sql_tune_task_id  VARCHAR2(100);

BEGIN

  l_sql_tune_task_id := DBMS_SQLTUNE.create_tuning_task (

                          sql_id      => '3vv0uzwkm9kag',

                          scope       => DBMS_SQLTUNE.scope_comprehensive,

                          time_limit  => 60,

                          task_name   => '3vv0uzwkm9kag_a_tuning_task',

                          description => 'Tuning task for statement 3vv0uzwkm9kag');

  DBMS_OUTPUT.put_line('l_sql_tune_task_id: ' || l_sql_tune_task_id);

END;

/
 
EXEC DBMS_SQLTUNE.execute_tuning_task(task_name => '3vv0uzwkm9kag_a_tuning_task');
 
SET LONG 10000;

SET PAGESIZE 4000

SET LINESIZE 300

SELECT DBMS_SQLTUNE.report_tuning_task('3vv0uzwkm9kag_a_tuning_task') AS recommendations FROM dual;

SET PAGESIZE 24
 
DECLARE

  l_sql_tune_task_id  VARCHAR2(100);

BEGIN

  l_sql_tune_task_id := DBMS_SQLTUNE.create_tuning_task (

                          sql_id      => '2jmvy3fd0mr6k',

                          scope       => DBMS_SQLTUNE.scope_comprehensive,

                          time_limit  => 60,

                          task_name   => '2jmvy3fd0mr6k_a_tuning_task',

                          description => 'Tuning task for statement 2jmvy3fd0mr6k');

  DBMS_OUTPUT.put_line('l_sql_tune_task_id: ' || l_sql_tune_task_id);

END;

/
 
EXEC DBMS_SQLTUNE.execute_tuning_task(task_name => '2jmvy3fd0mr6k_a_tuning_task');
 
SET LONG 10000;

SET PAGESIZE 4000

SET LINESIZE 300

SELECT DBMS_SQLTUNE.report_tuning_task('2jmvy3fd0mr6k_a_tuning_task') AS recommendations FROM dual;

SET PAGESIZE 24
 
DECLARE

  l_sql_tune_task_id  VARCHAR2(100);

BEGIN

  l_sql_tune_task_id := DBMS_SQLTUNE.create_tuning_task (

                          sql_id      => '95gaxng1cqpjq	',

                          scope       => DBMS_SQLTUNE.scope_comprehensive,

                          time_limit  => 60,

                          task_name   => '95gaxng1cqpjq	_a_tuning_task',

                          description => 'Tuning task for statement 95gaxng1cqpjq	');

  DBMS_OUTPUT.put_line('l_sql_tune_task_id: ' || l_sql_tune_task_id);

END;

/
 
EXEC DBMS_SQLTUNE.execute_tuning_task(task_name => '95gaxng1cqpjq	_a_tuning_task');
 
SET LONG 10000;

SET PAGESIZE 4000

SET LINESIZE 300

SELECT DBMS_SQLTUNE.report_tuning_task('95gaxng1cqpjq	_a_tuning_task') AS recommendations FROM dual;

SET PAGESIZE 24
 

=============================================
MONITOR DATA PUMP IMPORT AND EXPORT PROGRESS
=============================================
SELECT b.username, a.sid,b.SQL_ID, b.opname, b.target,
round(b.SOFAR*100/b.TOTALWORK,0) || '%' as "%COMPLETED", b.TIME_REMAINING,
b.start_time, b.LAST_UPDATE_TIME, b.MESSAGE
FROM v$session_longops b, v$session a
WHERE a.sid = b.sid
and b.username in ('TBAADMR','SYS')
and round(b.SOFAR*100/b.TOTALWORK,0)<100
ORDER BY 6 desc;



=================================================
CHECK TABLESPACE UTILIZATION OF SOME TABLESPACES
==================================================
SELECT d.status "Status",
d.tablespace_name "Tablespace Name",
TO_CHAR (NVL (a.bytes / 1024 / 1024 / 1024, 0), '99,999,990.90') "Size (GB)",
TO_CHAR (NVL (a.bytes - NVL (f.bytes, 0), 0) / 1024 / 1024 / 1024,'99999999.99') "Used (GB)",
TO_CHAR (NVL (f.bytes / 1024 / 1024 / 1024, 0), '99,999,990.90') "Free (GB)",
TO_CHAR (NVL ( (a.bytes - NVL (f.bytes, 0)) / a.bytes * 100, 0),'990.00') "PCT USED"
FROM sys.dba_tablespaces d,
(SELECT tablespace_name, SUM (bytes) bytes
FROM dba_data_files
GROUP BY tablespace_name) a,
(SELECT tablespace_name, SUM (bytes) bytes
FROM dba_free_space
GROUP BY tablespace_name) f
WHERE d.tablespace_name = a.tablespace_name(+)
AND d.tablespace_name = f.tablespace_name(+)
AND NOT(d.extent_management LIKE 'LOCAL' AND d.contents LIKE 'TEMPORARY')
AND d.tablespace_name in ( 'PART_TAB_HTD_Q1_TBLSPC','PART_TAB_HTD_Q2_TBLSPC','CUSTOM_TBLS','PART_TAB_HTD_Q4_TBLSPC','PART_IDX_HTD_TBLSPC','UNDOTBS1')
order by TO_CHAR (NVL ( (a.bytes - NVL (f.bytes, 0)) / a.bytes * 100, 0),'990.00') desc;

SELECT d.status "Status",
       d.tablespace_name "Name",
       TO_CHAR (NVL (a.bytes / 1024 / 1024 / 1024, 0), '99,999,990.90')
          "Size (GB)",
       TO_CHAR (NVL (a.bytes - NVL (f.bytes, 0), 0) / 1024 / 1024 / 1024,
                '99999999.99')
          "Used (GB)",
       TO_CHAR (NVL (f.bytes / 1024 / 1024 / 1024, 0), '99,999,990.90')
          "Free (GB)",
       TO_CHAR (NVL ( (a.bytes - NVL (f.bytes, 0)) / a.bytes * 100, 0),
                '990.00')
          "(Used) %"
  FROM sys.dba_tablespaces d,
       (  SELECT tablespace_name, SUM (bytes) bytes
            FROM dba_data_files
        GROUP BY tablespace_name) a,
       (  SELECT tablespace_name, SUM (bytes) bytes
            FROM dba_free_space
        GROUP BY tablespace_name) f
WHERE     d.tablespace_name = a.tablespace_name(+)
       AND d.tablespace_name = f.tablespace_name(+)
       AND NOT (    d.extent_management LIKE 'LOCAL'
                AND d.contents LIKE 'TEMPORARY')
       AND TO_CHAR (NVL ( (a.bytes - NVL (f.bytes, 0)) / a.bytes * 100, 0),
                    '990.00') > 80;

===========================================
SCHEDULE A JOB USING SYS FROM KILL INACTIVE SESSIONS
============================================
BEGIN
  SYS.DBMS_SCHEDULER.DROP_JOB
    (job_name  => 'SYS.KILLCHACTMGRSESSION');
END;
/

BEGIN
  SYS.DBMS_SCHEDULER.CREATE_JOB
    (
       job_name        => 'SYS.KILLCHACTMGRSESSION'
      ,start_date      => TO_TIMESTAMP_TZ('2023/05/01 00:30:25.952716 +01:00','yyyy/mm/dd hh24:mi:ss.ff tzh:tzm')
      ,repeat_interval => 'FREQ=MINUTELY;INTERVAL= 5'
      ,end_date        => NULL
      ,job_class       => 'DEFAULT_JOB_CLASS'
      ,job_type        => 'PLSQL_BLOCK'
      ,job_action      => 'begin SYS.KillChactmgrsessions(); end;'
      ,comments        => NULL
    );
  SYS.DBMS_SCHEDULER.SET_ATTRIBUTE
    ( name      => 'SYS.KILLCHACTMGRSESSION'
     ,attribute => 'RESTARTABLE'
     ,value     => FALSE);
  SYS.DBMS_SCHEDULER.SET_ATTRIBUTE
    ( name      => 'SYS.KILLCHACTMGRSESSION'
     ,attribute => 'LOGGING_LEVEL'
     ,value     => SYS.DBMS_SCHEDULER.LOGGING_OFF);
  SYS.DBMS_SCHEDULER.SET_ATTRIBUTE_NULL
    ( name      => 'SYS.KILLCHACTMGRSESSION'
     ,attribute => 'MAX_FAILURES');
  SYS.DBMS_SCHEDULER.SET_ATTRIBUTE_NULL
    ( name      => 'SYS.KILLCHACTMGRSESSION'
     ,attribute => 'MAX_RUNS');
  SYS.DBMS_SCHEDULER.SET_ATTRIBUTE
    ( name      => 'SYS.KILLCHACTMGRSESSION'
     ,attribute => 'STOP_ON_WINDOW_CLOSE'
     ,value     => FALSE);
  SYS.DBMS_SCHEDULER.SET_ATTRIBUTE
    ( name      => 'SYS.KILLCHACTMGRSESSION'
     ,attribute => 'JOB_PRIORITY'
     ,value     => 3);
  SYS.DBMS_SCHEDULER.SET_ATTRIBUTE_NULL
    ( name      => 'SYS.KILLCHACTMGRSESSION'
     ,attribute => 'SCHEDULE_LIMIT');
  SYS.DBMS_SCHEDULER.SET_ATTRIBUTE
    ( name      => 'SYS.KILLCHACTMGRSESSION'
     ,attribute => 'AUTO_DROP'
     ,value     => FALSE);
  SYS.DBMS_SCHEDULER.SET_ATTRIBUTE
    ( name      => 'SYS.KILLCHACTMGRSESSION'
     ,attribute => 'RESTART_ON_RECOVERY'
     ,value     => FALSE);
  SYS.DBMS_SCHEDULER.SET_ATTRIBUTE
    ( name      => 'SYS.KILLCHACTMGRSESSION'
     ,attribute => 'RESTART_ON_FAILURE'
     ,value     => FALSE);
  SYS.DBMS_SCHEDULER.SET_ATTRIBUTE
    ( name      => 'SYS.KILLCHACTMGRSESSION'
     ,attribute => 'STORE_OUTPUT'
     ,value     => TRUE);

  SYS.DBMS_SCHEDULER.ENABLE
    (name                  => 'SYS.KILLCHACTMGRSESSION');
END;
/

--THE PROCEDURE THAT THE ABOVE SCHEDULED JOB WILL BE USING
CREATE OR REPLACE procedure SYS.KillChactmgrsessions
as
BEGIN
  FOR r IN (select distinct b.serial#, b.sid, b.INST_ID
from
gv$locked_object a ,
gv$session b,
dba_objects c,
gV$transaction d
where b.sid = a.session_id
and a.object_id = c.object_id
and d.ses_addr = b.saddr
and c.owner ='CRMUSER'
and b.username is not null
and b.username not in ('SYS','CUSTOM_TBLS','FIEJB')
and b.program like '%chactmgr%'
and ((sysdate - d.start_date)  * 24 * 60) > 15
and ((sysdate - b.PREV_EXEC_START)  * 24 * 60) > 15
and b.status = 'INACTIVE')
--and b.client_info not like '%NGFIVUSR%')
  LOOP
      EXECUTE IMMEDIATE 'alter system kill session ''' || r.sid  || ','
        || r.serial# || ',@' || r.INST_ID || ''' immediate';
  END LOOP;
END;
/


===========================================
FIXING LOCK CONTENTION ON ORACLE DATABASE
===========================================
SELECT sql_id 
  FROM gv$session
 WHERE event='enq: TX - row lock contention'
   AND state='WAITING';

select INST_ID,SQL_TEXT,SQL_FULLTEXT,SQL_ID,USERS_OPENING,EXECUTIONS,END_OF_FETCH_COUNT
USER_EXECUTING,FIRST_LOAD_TIME,PARSE_CALLS,DISK_READS,APPLICATION_WAIT_TIME,CONCURRENCY_WAIT_TIME
,CLUSTER_WAIT_TIME,USER_IO_WAIT_TIME,PLSQL_EXEC_TIME,ROWS_PROCESSED,PARSING_SCHEMA_NAME,MODULE,ACTION,
CPU_TIME,ELAPSED_TIME,REMOTE,OBJECT_STATUS,LAST_LOAD_TIME,LAST_ACTIVE_TIME
from gv$sqlarea where SQL_id in('2jmvy3fd0mr6k','0yymw8q7c118f');



SELECT row_wait_obj#       AS object,
       row_wait_file#      AS datafile,
       row_wait_block#     AS datablock,
       row_wait_row#       AS rowinfo
  FROM gv$session
 WHERE event='enq: TX - row lock contention'
   AND state='WAITING'; 
 --AGENTS  
select object_name from dba_objects where object_id = 14047794;

SELECT gvs.inst_id,DECODE (request, 0, 'Holder: ', 'waiter:') || gvl.sid     sess,
         status,
         id1,
         id2,
         lmode,
         request,
         gvl.TYPE
    FROM gv$lock gvl, gv$session gvs
   WHERE     (id1, id2, gvl.TYPE) IN (SELECT id1, id2, TYPE
                                        FROM gv$lock
                                       WHERE request > 0)
         AND gvl.sid = gvs.sid and gvl.inst_id=gvs.inst_id
ORDER BY id1, request;

--2	Holder: 10638	INACTIVE	32768018	1732572	6	0	TX
select SADDR,serial# from gv$session where sid=4457 and inst_id=2; --00000016A2F33090

select saddr,inst_id,sid,sql_id,sql_text,LAST_SQL_ACTIVE_TIME, CURSOR_TYPE from gv$open_cursor  
where saddr='00000016C2638150' and inst_id=2 and cursor_type='OPEN'
order by LAST_SQL_ACTIVE_TIME desc;


select INST_ID,SQL_TEXT,SQL_FULLTEXT,SQL_ID,USERS_OPENING,EXECUTIONS,END_OF_FETCH_COUNT
USER_EXECUTING,FIRST_LOAD_TIME,PARSE_CALLS,DISK_READS,APPLICATION_WAIT_TIME,CONCURRENCY_WAIT_TIME
,CLUSTER_WAIT_TIME,USER_IO_WAIT_TIME,PLSQL_EXEC_TIME,ROWS_PROCESSED,PARSING_SCHEMA_NAME,MODULE,ACTION,
CPU_TIME,ELAPSED_TIME,REMOTE,OBJECT_STATUS,LAST_LOAD_TIME,LAST_ACTIVE_TIME
from gv$sqlarea where SQL_id in('6wfz266r0kwrc','8d09bkvcdf535');
https://dincosman.com/2024/09/01/enq-tx-row-lock/


========================================================
REVOKE A USER TRUNCATE ON A TABLE USING STORED PROCEDURE
=======================================================
CREATE OR REPLACE procedure misuser.trunc_rbx_a_salesforce_product_loan
AS
BEGIN
execute immediate 'TRUNCATE TABLE misuser.rbx_a_salesforce_product_loan';
end;
/

REVOKE EXECUTE on misuser.trunc_rbx_t_salesforce_product_loan FROM CUSTOM;


CREATE OR REPLACE procedure misuser.trunc_rbx_a_salesforce_product_loan
AS
BEGIN
execute immediate 'TRUNCATE TABLE misuser.rbx_t_salesforce_product_loan';
end;
/

REVOKE EXECUTE on misuser.trunc_rbx_t_salesforce_product_loan FROM CUSTOM;


=====================================
HANDLING LOB OBJECTS IN ORACLE
=====================================
select l.table_name,
       l.column_name,
       l.segment_name lob_name
  from user_lobs l
       join user_objects o
         on( o.object_name = l.segment_name );
         
         
select object_name, object_type, status from dba_objects
where object_type like 'LOB%' and status = 'INVALID';


select * from dba_recyclebin
where TS_NAME = 'MASTER';

SELECT MIN(TRAN_DATE),MAX(TRAN_DATE) FROM REDBOX.RBX_T_FNDABL_WALLET_TXN_CHRGS;

SELECT l.table_name,
       l.column_name,
       l.segment_name lob_name
  FROM DBA_lobs l
       JOIN DBA_objects o
         ON( o.object_name = l.segment_name );
		 
col segment_name for a25
col owner for a20
set linesize 20
set linesize 200

SELECT owner,segment_name,
ROUND(SUM(bytes)/1024/1024/1024, 3) AS schema_size_gb
FROM dba_segments
WHERE owner = 'REDBOX' AND SEGMENT_NAME LIKE '%RBX%'
GROUP BY owner,segment_name
ORDER BY schema_size_gb DESC;

SELECT
 table_name,
 column_name,
 ROUND(SUM(bytes)/1024/1024/1024,3) AS size_gb
FROM dba_segments s
JOIN dba_lobs l
 ON s.segment_name = l.segment_name
WHERE l.table_name LIKE '%RBX%'
--AND l.column_name IN ('SIG_TEXT')
GROUP BY table_name, column_name
ORDER BY SIZE_GB DESC;

		 
		 
===CHECK REPLICATION STATUS================

select max(sequence#) from v$log_history;
MAX(SEQUENCE#);

select sequence#,process,status from v$managed_standby;

select type,status,gap_status from v$archive_dest_status where DEST_ID=2;

SELECT   a.thread#,  b. last_seq, a.applied_seq, a. last_app_timestamp, b.last_seq-a.applied_seq   ARC_DIFF 
FROM (SELECT  thread#, MAX(sequence#) applied_seq, 
MAX(next_time) last_app_timestamp FROM gv$archived_log WHERE applied = 'YES' GROUP BY thread#) a,
(SELECT  thread#, MAX (sequence#) last_seq FROM gv$archived_log GROUP BY thread#) b WHERE a.thread# = b.thread#;

==CHECK ERROR IN DATAGUARD STATUS====
select * from V$DATAGUARD_STATUS where severity = 'Error'
order by TIMESTAMP desc;

select * from v$flash_recovery_area_usage;

select max(sequence#) from v$log_history;

select a.event, a.wait_time, a.seconds_in_wait from gv$session_wait a, gv$session b where a.sid=b.sid and 
b.sid=(select SID from v$session where PADDR=(select PADDR from v$bgprocess where NAME='MRP0'));

==CHECK REPLICATION STATUS===
select thread#,sequence#,process,client_process,status,blocks from v$managed_standby;



--==================
RESTORE AN ORACLE DB
--==================
Take bkp of spfile from prod
take bkp of the control file
restore spfile and contrpl file to traget db 
create a pfile from restored spfile
edit the pfile to suit the target db file paths
put the on nomount mode
Restore the control file
Put the db in mount mode
Verify the back to ensure control file is point to where it should be
catalog the backup set
restore the DATABASE
restore archivelog if necessary
recover the DATABASE
alter the database to open in restlog mode.

step 1
set echo on;
run {
         set newname for database to "+PDATA/UNGFIN/DATAFILE/%b";
         restore database;
}

run {

set until time "to_date('01/07/2011 01:30','dd/mm/yyyy hh24:mi')";

restore database;

recover database;

};

Link to check restore status:
https://ittutorial.org/rman-backup-and-restore-status-in-oracle-database/

alter session set nls_date_format='DD-MON-YYYY HH24:MI:SS';
set line 2222;
set pages 2222;
set long 6666;
select sl.sid, sl.opname,
to_char(100*(sofar/totalwork), '990.9')||'%' pct_done,
sysdate+(TIME_REMAINING/60/60/24) done_by
from v$session_longops sl, v$session s
where sl.sid = s.sid
and sl.serial# = s.serial#
and sl.sid in (select sid from v$session where module like 'backup%' or module like 'restore%' or module like 'rman%')
and sofar != totalwork
and totalwork > 0
/

--select * from RC_RMAN_STATUS
set pagesize 100 echo on feedback on
select s.client_info,
sl.message,
sl.sid, sl.serial#, p.spid,
sl.start_time, sl.last_update_time,
sl.time_remaining, sl.elapsed_seconds, sl.time_remaining + sl.elapsed_seconds as total_seconds,
sl.time_remaining/60 "Remaining (Min)", sl.elapsed_seconds/60 "Elapsed (Min)",
round(sl.sofar/sl.totalwork*100,2) || '%' "Completed"
from v$session_longops sl, v$session s, v$process p
where p.addr = s.paddr
and sl.sid=s.sid
and sl.serial#=s.serial#
and opname LIKE 'RMAN%'
and opname NOT LIKE '%aggregate%'
and totalwork != 0
and sofar=totalwork;

set numwidth 30;
set pagesize 50000;
alter session set nls_date_format = 'DD-MON-RRRR HH24:MI:SS';
select status,checkpoint_change#,checkpoint_time, resetlogs_change#, resetlogs_time, count(*), fuzzy 
from v$datafile_header group by status,checkpoint_change#,checkpoint_time, resetlogs_change#, resetlogs_time, fuzzy;


=======================
RENAME REDO LOG

alter system set standby_file_management=manual;

alter database rename file '+REDO/PNGITMS/ONLINELOG/group_9.413.1079260973' to '+REDO/DNGITMS/ONLINELOG/group_9.338.1079260969';


==========================================================================================================
Using RMAN to Safely Clone a Database onto the Same Storage as the Source Database (Doc ID 2289796.1)
==========================================================================================================
https://docs.oracle.com/en/database/oracle/oracle-database/19/bradv/rman-duplicating-databases.html#GUID-F31F9FCE-B610-49EB-B9DB-44B9AA4E838F
https://docs.oracle.com/en/database/oracle/oracle-database/23/bradv/rman-duplicating-databases.html#GUID-F31F9FCE-B610-49EB-B9DB-44B9AA4E838F
Creating a Physical Standby database using RMAN restore database from service (Doc ID 2283978.1)


impdp version=19.0 directory=EXPDP_DIR dumpfile=omnichan181123.dmp logfile=omnichann.log schemas=omnichanneluser REMAP_TABLESPACE=MASTER:MASTER,MASTER:IDX_MASTER table_exists_action=drop
expdp content=METADATA_ONLY directory=EXPDP_DIR dumpfile=rbx_t_famous_banks_221123.dmp logfile=rbx_t_famous_banks.log tables=REDBOX.RBX_T_FAMOUS_BANKS

impdp version=19.0 directory=EXPDP_DIR dumpfile=rbx_t_famous_banks_221123.dmp logfile=rbx_t_famous_banks.log tables=REDBOX.RBX_T_FAMOUS_BANKS table_exists_action=replace

expdp content=METADATA_ONLY directory=EXPDP_DIR dumpfile=EXPORT_TBL_221123.dmp logfile=EXPORT_TBL.log tables=REDBOX.EXPORT_TBL

impdp directory=EXPDP_DIR dumpfile=EXPORT_TBL_221123.dmp logfile=EXPORT_TBL.log tables=REDBOX.EXPORT_TBL REMAP_TABLE=REDBOX.EXPORT_TBL:EXPORT_TBL_TEST


impdp version=19.0 directory=EXPDP_DIR dumpfile=rbx_t_famous_banks_221123.dmp logfile=rbx_t_famous_banks.log tables=REDBOX.RBX_T_FAMOUS_BANKS table_exists_action=replace



===========================================
FIXING DISTRIBUTED TRANSACTION ISSUES 2PC
===========================================
ORA-01591: lock held by in-doubt distributed transaction 600.3.1161469
========================================================================
You can take the backup of the below tables but DO NOT insert back the records. Use insert script as shared below.

==========SOLUTION===========================
delete from sys.pending_trans$ where local_tran_id = '600.3.1161469';
delete from sys.pending_sessions$ where local_tran_id = '600.3.1161469';
delete from sys.pending_sub_sessions$ where local_tran_id ='600.3.1161469';
commit;

alter system disable distributed recovery;

insert into pending_trans$ (
LOCAL_TRAN_ID,
GLOBAL_TRAN_FMT,
GLOBAL_ORACLE_ID,
STATE,
STATUS,
SESSION_VECTOR,
RECO_VECTOR,
TYPE#,
FAIL_TIME,
RECO_TIME)
values( '600.3.1161469', /* <== Replace this with your local tran id */
306206, /* */
'XXXXXXX.12345.1.2.3', /* These values can be used without any */
'prepared','P', /* modification. Most of the values are */
hextoraw( '00000001' ), /* constant. */
hextoraw( '00000000' ), /* */
0, sysdate, sysdate );

insert into pending_sessions$
values( '600.3.1161469',/* <==Replace only this with your local tran id */
1, hextoraw('05004F003A1500000104'),
'C', 0, 30258592, '',
146
);
commit;

commit force '600.3.1161469';

exec dbms_transaction.purge_lost_db_entry('600.3.1161469');


=========================
CREATE REDO LOGS
=========================
Find out redo log group using

select group#, thread#, sequence#, status from v$standby_log;

alter database drop logfile group 9;

alter database drop logfile group 8;

alter database drop logfile group 7;

alter database drop logfile group 6;

alter database drop logfile group 5;
 
 
alter database add standby logfile thread 0 group 9 '+REDO' size 200M;

alter database add standby logfile thread 0 group 8 '+REDO' size 200M;

alter database add standby logfile thread 0 group 7'+REDO' size 200M;

alter database add standby logfile thread 0 group 6 '+REDO' size 200M;

alter database add standby logfile thread 0 group 5 '+REDO' size 200M;


========================
RECOMPILE AN INVALID OBJECT
====================================
There are several SYS and SYSMAN objects that are invalid. Please compile them as follows:

1) Run <DB HOME>/rdbms/admin/utlrp.sql on the Repository Database to compile the invalid objects.

sqlplus / as sysdba

SQL>@$ORACLE_HOME/rdbms/admin/utlrp.sql
/u01/app/oracle/product/12.2.0.1/dbhome_2/rdbms/admin/utlrp.sql

2) Verify no invalids are present for SYS and SYSMAN schema in Repository Database.

select owner, object_name, object_type from dba_objects where status!='VALID' order by owner;
select count(*) from dba_objects where status!='VALID' order by owner;




select COUNT(*)  from MISUSER.GMO_TBILLTYPE; --40
select COUNT(*)  from MISUSER.ISRM_BANK_ACCOUNT_PENDING; --12
select COUNT(*)  from MISUSER.UMP_APPLICATION; --10
select COUNT(*)  from MISUSER.EDL_DOCUMENT_SUB_CATEGORY; 

DOC> The following query reports the number of exceptions caught during
DOC> recompilation. If this number is non-zero, please query the error
DOC> messages in the table UTL_RECOMP_ERRORS to see if any of these errors
DOC> are due to misconfiguration or resource constraints that must be
DOC> fixed before objects can compile successfully.
DOC> Note: Typical compilation errors (due to coding errors) are not
DOC>       logged into this table: they go into DBA_ERRORS instead.
DOC>#


=======================
CREATING UNIQUE CONSTRAINTS
=============================
ALTER TABLE Redbox.rbx_t_Nibss_notify
ADD CONSTRAINT Unique_Session_id UNIQUE (SESSION_ID);



--========================================
--GENERATE DDL OF VARIOUS ORACLE DATABASE OBJECTS/ USERS
--========================================================
set long 100000
set head off
set echo off
set pagesize 0
set verify off
set feedback off
select dbms_metadata.get_ddl('USER', du.username) AS DDL_SCRIPT
from   dba_users du
where  du.username = 'TBAADM'
union all
select dbms_metadata.get_granted_ddl('TABLESPACE_QUOTA', dtq.username) AS DDL_SCRIPT
from   dba_ts_quotas dtq
where  dtq.username = 'TBAADM'
and    rownum = 1
union all
SELECT DBMS_METADATA.get_ddl ('TABLE', table_name, owner)
FROM all_tables
WHERE owner = UPPER('TBAADM')
union all
select dbms_metadata.get_granted_ddl('ROLE_GRANT', drp.grantee) AS DDL_SCRIPT
from   dba_role_privs drp
where  drp.grantee = 'TBAADM'
and    rownum = 1
union all
select dbms_metadata.get_granted_ddl('SYSTEM_GRANT', dsp.grantee) AS DDL_SCRIPT
from   dba_sys_privs dsp
where  dsp.grantee = 'TBAADM'
and    rownum = 1
union all
select dbms_metadata.get_granted_ddl('OBJECT_GRANT', dtp.grantee) AS DDL_SCRIPT
from   dba_tab_privs dtp
where  dtp.grantee = 'TBAADM'
and    rownum = 1
union all
select dbms_metadata.get_granted_ddl('DEFAULT_ROLE', drp.grantee) AS DDL_SCRIPT
from   dba_role_privs drp
where  drp.grantee = 'TBAADM'
and    drp.default_role = 'YES'
and    rownum = 1;



-- -----------------------------------------------------------------------------------
-- File Name    : https://oracle-base.com/dba/script_creation/role_ddl.sql
-- Author       : Tim Hall
-- Description  : Displays the DDL for a specific role.
-- Call Syntax  : @role_ddl (role)
-- Last Modified: 27/07/2022 - Increase long to 1000000.
-- -----------------------------------------------------------------------------------

set long 1000000 longchunksize 20000 pagesize 0 linesize 1000 feedback off verify off trimspool on
column ddl format a1000

begin
   dbms_metadata.set_transform_param (dbms_metadata.session_transform, 'SQLTERMINATOR', true);
   dbms_metadata.set_transform_param (dbms_metadata.session_transform, 'PRETTY', true);
end;
/
 
variable v_role VARCHAR2(30);

exec :v_role := upper('&1');

select dbms_metadata.get_ddl('ROLE', r.role) AS ddl
from   dba_roles r
where  r.role = :v_role
union all
select dbms_metadata.get_granted_ddl('ROLE_GRANT', rp.grantee) AS ddl
from   dba_role_privs rp
where  rp.grantee = :v_role
and    rownum = 1
union all
select dbms_metadata.get_granted_ddl('SYSTEM_GRANT', sp.grantee) AS ddl
from   dba_sys_privs sp
where  sp.grantee = :v_role
and    rownum = 1
union all
select dbms_metadata.get_granted_ddl('OBJECT_GRANT', tp.grantee) AS ddl
from   dba_tab_privs tp
where  tp.grantee = :v_role
and    rownum = 1
/

set linesize 80 pagesize 14 feedback on verify on



--=====================================
--DB SESSION INFORMATION
--=====================================
select * from gv$resource_limit where resource_name in('processes','sessions');

select RESOURCE_NAME,PROFILE, LIMIT
from dba_profiles
WHERE RESOURCE_NAME = 'SESSIONS_PER_USER'
AND PROFILE = 'REDBOX_PROFILE'; --5120

ALTER PROFILE REDBOX_PROFILE LIMIT SESSIONS_PER_USER UNLIMITED;

SELECT DISTINCT username, 
                profile, 
                resource_name, 
                limit
FROM   dba_profiles 
       NATURAL JOIN dba_users 
WHERE RESOURCE_NAME = 'SESSIONS_PER_USER'
AND PROFILE = 'REDBOX_PROFILE';


=======================================================
RESOLVE SHARED MEMORY ERROR PREVENTING DATABASE STARTUP
=======================================================
sysresv

ipcrm -m

===============================
OPEN CURSOR CHECK ON DB
===============================
select sid,sql_text,user_name,count(*) as "OPEN CURSOR"
FROM gv$open_cursor 
--WHERE SID='478'
having count(*) >2000
group by sid,sql_text,user_name order by 4 desc;
select * from gv$open_cursor;

select sid,sql_text,user_name,count(*) as "OPEN CURSOR"
FROM gv$open_cursor 
WHERE SID='2324'
having count(*) >3000
group by sid,sql_text,user_name order by 4 desc;
select * from gv$open_cursor
WHERE SID='2324';

SELECT * FROM GV$SQL
WHERE SQL_ID='9zg9qd9bm4spu';


select a.value, s.username, s.sid, s.serial#
from v$sesstat a, v$statname b, v$session s
where a.statistic# = b.statistic#  and s.sid=a.sid
and b.name = 'opened cursors current';

select  sql_text, count(*) as "OPEN CURSORS", user_name from v$open_cursor
group by sql_text, user_name order by count(*) desc;

COLUMN USER_NAME FORMAT A15

SELECT s.machine, oc.user_name, oc.sql_text, count(1) 
FROM v$open_cursor oc, v$session s
WHERE oc.sid = s.sid
GROUP BY user_name, sql_text, machine
HAVING COUNT(1) > 2
ORDER BY count(1) DESC
;



====================================
TROUBLESHOOTING HIGH CPU/MEMORY UTILIZATION
=====================================

1. Go to the OS having high CPU and run TOP COMMAND
2. Observer for a while so see if top processes are Oracle processes.
3. Copy the first 10 Processes PID.
4. Run below query to get all information about thr process PID.
set lines 300 pages 1000 long 2000

col sql_text for a30

col process for a20

col username for a15

col svr_pid for a7

col sid_serial# for a10

col time for a12

select distinct a.sql_id,username||'/'||osuser username,to_char(logon_time,'DD-MON-YY@HH24:mi:ss') TIME,

s.process CLT_PID,  s.sid||'|'||serial# sid_serial#,program||'@'||machine process,STATUS,

sql_text from v$session s, v$sqlarea a

where

sql_address = address and 

s.sid in 

('3783197',
'2664',
'336433'
'3780844',
'339649',
'252256',
'2963413',
'3555532',
'3913827',
'339829',
'1674166',
'3414431',
'3558122',
'293949',
'312530',
'252349',
'3555512',
'3555519',
'3555508',
'3555516',
'263427');
 
set linesize 900

column SQL_TEXT format a70

column MACHINE format a20

column program format a30

column terminal format a30

SELECT vs.username, vs.osuser, vs.program, vp.spid,vs.PROCESS ,vs.sid, vs.serial#,

       vs.machine, vs.terminal, vq.sql_text

  FROM v$session vs, v$process vp, v$sql vq

WHERE vs.paddr = vp.addr

   AND vs.sql_address = vq.address(+)

   AND vs.sql_hash_value = vq.hash_value(+)

    AND vp.spid  in 

('3975533',

'393399',

'638070',

'670753',

'3966978',

'592521',

'1753022',

'633020',

'673295',

'3371132',

'3911035',

'2710560',

'3908570',

'3975555',

'1752055',

'1753009',

'3913532',

'3976032',

'39939',

'666344',

'1749338',

'1752993',

'3912727',

'665183',

'556547');

5. Identify SQL ID of expensive queries 
 
set lines 300 pages 1000 long 2000

col sql_text for a30

col process for a20

col username for a15

col svr_pid for a7

col sid_serial# for a10

col time for a12

select distinct a.sql_id,username||'/'||osuser username,to_char(logon_time,'DD-MON-YY@HH24:mi:ss') TIME,

s.process CLT_PID,  s.sid||'|'||serial# sid_serial#,program||'@'||machine process,STATUS,

sql_text from v$session s, v$sqlarea a

where

sql_address = address and 

s.sid in 

('85bk049188x2g','394uut5pz0ukc','gndj7dgb7m7jz');
 
 
set lines 300 pages 1000 long 2000

col sql_text for a30

col process for a20

col username for a15

col svr_pid for a7

col sid_serial# for a10

col time for a12

select username||'/'||osuser username,to_char(logon_time,'DD-MON-YY@HH24:mi:ss') TIME,

s.process CLT_PID,  s.sid||'|'||serial# sid_serial#,program||'@'||machine process,STATUS,

sql_text from v$session s, v$sqlarea a

where

sql_address = address and a.sql_id in 

('85bk049188x2g','394uut5pz0ukc','gndj7dgb7m7jz');


6. Running query tunning advisor.
 
DECLARE

  l_sql_tune_task_id  VARCHAR2(100);

BEGIN

  l_sql_tune_task_id := DBMS_SQLTUNE.create_tuning_task (

                          sql_id      => '85bk049188x2g',

                          scope       => DBMS_SQLTUNE.scope_comprehensive,

                          time_limit  => 60,

                          task_name   => '85bk049188x2g_a_tuning_task',

                          description => 'Tuning task for statement 85bk049188x2g');

  DBMS_OUTPUT.put_line('l_sql_tune_task_id: ' || l_sql_tune_task_id);

END;

/
 
EXEC DBMS_SQLTUNE.execute_tuning_task(task_name => '85bk049188x2g_a_tuning_task');
 
SET LONG 10000;

SET PAGESIZE 1000
SET LINESIZE 200
SELECT DBMS_SQLTUNE.report_tuning_task('85bk049188x2g_a_tuning_task') AS recommendations FROM dual;
SET PAGESIZE 24
DECLARE
  l_sql_tune_task_id  VARCHAR2(100);

BEGIN
  l_sql_tune_task_id := DBMS_SQLTUNE.create_tuning_task (
                          sql_id      => '394uut5pz0ukc',
                          scope       => DBMS_SQLTUNE.scope_comprehensive,
                          time_limit  => 60,
                          task_name   => '394uut5pz0ukc_a_tuning_task',
                          description => 'Tuning task for statement 394uut5pz0ukc');
  DBMS_OUTPUT.put_line('l_sql_tune_task_id: ' || l_sql_tune_task_id);

END;

/
 
EXEC DBMS_SQLTUNE.execute_tuning_task(task_name => '394uut5pz0ukc_a_tuning_task');
SET LONG 10000;
SET PAGESIZE 1000
SET LINESIZE 200
SELECT DBMS_SQLTUNE.report_tuning_task('394uut5pz0ukc_a_tuning_task') AS recommendations FROM dual;
SET PAGESIZE 24

7. Check tables and indexes to know if there is need to gather statistic
If there is a lot of UPDATE, INSERT AND DELETE ON A TABLE, with often SELECTS, Is advisable to run statistics UPDATE 
and TABLE DEFRAGMENTATION.

select object_name, object_type, owner from dba_objects where object_name='USSD_CUSTDET_ONEOFF'

 
select last_analyzed, table_name, owner from dba_tables where table_name in ('PHONEEMAIL','ACCOUNTS');

 
select sum(bytes/1024/1024/1024), segment_name, owner from dba_segments where segment_name in in ('PHONEEMAIL','ACCOUNTS');
 
 
select sum(bytes/1024/1024/1024), segment_name, owner from dba_segments 

where segment_name in in ('PHONEEMAIL','ACCOUNTS') 

group by segment_name, owner ;
 
Abisola  Awoluyi (Unverified) left the chat.

 
select index_name,table_name, owner from dba_indexes where table_name in ('PHONEEMAIL','ACCOUNTS');

 
 
 ==================================
 RECLAIM UNUSED SPACE ON DATABASE
 ==================================
 https://support.dbagenesis.com/post/reclaim-unused-space-in-oracle
 
 
 
 Yes, sir. I tried that also.

SQL> ALTER SYSTEM DISCONNECT SESSION '245,23' IMMEDIATE;

System altered.

SQL> ALTER SYSTEM DISCONNECT SESSION '245,23' IMMEDIATE;

System altered.

SQL> select sid, serial#,status from v$session where sid=245;

       SID    SERIAL# STATUS
---------- ---------- --------
       245         23 KILLED
	   
select INST_ID,SQL_TEXT,SQL_FULLTEXT,SQL_ID,USERS_OPENING,EXECUTIONS,END_OF_FETCH_COUNT
USER_EXECUTING,FIRST_LOAD_TIME,PARSE_CALLS,DISK_READS,APPLICATION_WAIT_TIME,CONCURRENCY_WAIT_TIME
,CLUSTER_WAIT_TIME,USER_IO_WAIT_TIME,PLSQL_EXEC_TIME,ROWS_PROCESSED,PARSING_SCHEMA_NAME,MODULE,ACTION,
CPU_TIME,ELAPSED_TIME,REMOTE,OBJECT_STATUS,LAST_LOAD_TIME,LAST_ACTIVE_TIME
from gv$sqlarea --WHERE ROWNUM<=2
--WHERE FIRST_LOAD_TIME >='2024-11-21/05:13:02'
WHERE LAST_ACTIVE_TIME>='21-NOV-2024'-- 10:00:00 AM'
order by CPU_TIME DESC;--USER_IO_WAIT_TIME desc; EXECUTIONS DESC;--
--SELECT * FROM GV$SQLAREA WHERE SQL_id='8g5hdk2hgad41';
d007ka2652ch9
9c1wqryp2fuhw


select INST_ID,SQL_TEXT,SQL_FULLTEXT,SQL_ID,USERS_OPENING,EXECUTIONS,END_OF_FETCH_COUNT
USER_EXECUTING,FIRST_LOAD_TIME,PARSE_CALLS,DISK_READS,APPLICATION_WAIT_TIME,CONCURRENCY_WAIT_TIME
,CLUSTER_WAIT_TIME,USER_IO_WAIT_TIME,PLSQL_EXEC_TIME,ROWS_PROCESSED,PARSING_SCHEMA_NAME,MODULE,ACTION,
CPU_TIME,ELAPSED_TIME,REMOTE,OBJECT_STATUS,LAST_LOAD_TIME,LAST_ACTIVE_TIME
from gv$sqlarea where SQL_id='bad54c6pnyp8k';

select * from gv$sql where SQL_id='8g5hdk2hgad41';

--============================================================
--GENERATE INSERT FROM SQL SERVER
--============================================================
="INSERT INTO MISUSER.CORP_WRITEOFF_DETAILS VALUES('"&A2&"','"&B2&"','"&C2&"','"&D2&"','"&E2&"','"&F2&"','"&G2&"','"&H2&"','"&I2&"','"&J2&"',
'"&K2&"','"&L2&"','"&M2&"','"&N2&"','"&O2&"','"&P2&"','"&Q2&"','"&R2&"','"&S2&"','"&T2&"','"&U2&"','"&V2&"','"&W2&"','"&X2&"','"&Y2&"','"&Z2&"');"