COMMANDS=[
    'hostname',
    'mpstat',
    'free',
    'df -h',
    'odaadmcli show disk'   
]