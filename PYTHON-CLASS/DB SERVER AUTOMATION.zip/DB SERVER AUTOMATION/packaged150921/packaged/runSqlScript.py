import csv
import pandas as pd 
import sys
import cx_Oracle
import databaseconfig
import sqlscripts
import sendemail
import sqlsequencecheck

def sqlScriptRun():
    df_list_total=[]
    scripts=sqlscripts.SQLSCRIPT
    seqcheckscriptfin=sqlsequencecheck.SQLSEQUENCEFIN
    seqcheckscriptrdbx=sqlsequencecheck.SQLSEQUENCERDBX
    seqcheckscriptfib=sqlsequencecheck.SQLSEQUENCEFIB
    for num,login_details in databaseconfig.CONFIG.items():
        df_list=[]
        a=login_details
        a=[(x,y) for x,y in a.items()]
        conn_string=a[0][0]
        login=a[0][1]
        login=list(zip(login.keys(),login.values()))[0]
        username,password=login
        print(conn_string)
        try:
            connection = cx_Oracle.connect(user=username,
                                        password=password,
                                        dsn=conn_string,
                                        encoding='utf-8',
                                        mode=cx_Oracle.SYSDBA
                                        )
        except Exception as err:
            print('There was an error connecting: ', err)
        else:
            for script in scripts:
                # Sql statement needed to be executed
                try:
                    cursor = connection.cursor()
                    r = cursor.execute(script)
                except Exception as err:
                    print('There was an err: ', err)
                else:
                    col_names = [row[0] for row in cursor.description]
                    try:
                        df = pd.DataFrame(r, columns=col_names)
                    except Exception as err:
                        pass
                    df_list.append(df)

                    #sendemail.sendEmail(html)
            
            # Addition of sequence check for Finacle
            if conn_string=='pngcordb-scan:1521/pngfin':
                for script in seqcheckscriptfin:
                # Sql statement needed to be executed
                    try:
                        cursor = connection.cursor()
                        r = cursor.execute(script)
                    except Exception as err:
                        print('There was an err: ', err)
                    else:
                        col_names = [row[0] for row in cursor.description]
                        df = pd.DataFrame(r, columns=col_names)
                        df_list.append(df)
            # Addition of sequence check for Redbox
            if conn_string=='pngcordb-scan:1521/pngrdbox':
                for script in seqcheckscriptrdbx:
                # Sql statement needed to be executed
                    try:
                        cursor = connection.cursor()
                        r = cursor.execute(script)
                    except Exception as err:
                        print('There was an err: ', err)
                    else:
                        col_names = [row[0] for row in cursor.description]
                        df = pd.DataFrame(r, columns=col_names)
                        df_list.append(df)
            # Addition of sequence check for Internet banking
            if conn_string=='pngcordb-scan:1521/pngfib':
                for script in seqcheckscriptfib:
                # Sql statement needed to be executed
                    try:
                        cursor = connection.cursor()
                        r = cursor.execute(script)
                    except Exception as err:
                        print('There was an err: ', err)
                    else:
                        col_names = [row[0] for row in cursor.description]
                        df = pd.DataFrame(r, columns=col_names)
                        df_list.append(df)
        finally:
            cursor.close()
            connection.close()
        df_list_total.append(df_list)
    return df_list_total

