
SQLSCRIPT=[
    '''select NAME,OPEN_MODE, DB_UNIQUE_NAME from v$database''',
    '''SELECT df.tablespace_name tablespace_name, max(df.autoextensible) auto_ext, round(df.maxbytes / (1024 * 1024), 2) max_ts_size, round((df.bytes - sum(fs.bytes)) / (df.maxbytes) * 100, 2) max_ts_pct_used,
 round(df.bytes / (1024 * 1024), 2) curr_ts_size, round((df.bytes - sum(fs.bytes)) / (1024 * 1024), 2) used_ts_size, round((df.bytes-sum(fs.bytes)) * 100 / df.bytes, 2) ts_pct_used,
 round(sum(fs.bytes) / (1024 * 1024), 2) free_ts_size, nvl(round(sum(fs.bytes) * 100 / df.bytes), 2) ts_pct_free FROM dba_free_space fs,
 (select tablespace_name, sum(bytes) bytes, sum(decode(maxbytes, 0, bytes, maxbytes)) maxbytes, max(autoextensible) autoextensible from dba_data_files group by tablespace_name) df
WHERE fs.tablespace_name (+) = df.tablespace_name GROUP BY df.tablespace_name, df.bytes, df.maxbytes UNION ALL
SELECT df.tablespace_name tablespace_name,  max(df.autoextensible) auto_ext, round(df.maxbytes / (1024 * 1024), 2) max_ts_size, round((df.bytes - sum(fs.bytes)) / (df.maxbytes) * 100, 2) max_ts_pct_used,
 round(df.bytes / (1024 * 1024), 2) curr_ts_size, round((df.bytes - sum(fs.bytes)) / (1024 * 1024), 2) used_ts_size, round((df.bytes-sum(fs.bytes)) * 100 / df.bytes, 2) ts_pct_used,
 round(sum(fs.bytes) / (1024 * 1024), 2) free_ts_size, nvl(round(sum(fs.bytes) * 100 / df.bytes), 2) ts_pct_free FROM (select tablespace_name, bytes_used bytes
 from V$temp_space_header group by tablespace_name, bytes_free, bytes_used) fs, (select tablespace_name, sum(bytes) bytes, sum(decode(maxbytes, 0, bytes, maxbytes)) maxbytes,
 max(autoextensible) autoextensible from dba_temp_files group by tablespace_name) df WHERE fs.tablespace_name (+) = df.tablespace_name GROUP BY df.tablespace_name, df.bytes, df.maxbytes
ORDER BY 7 DESC''',
'''select owner,object_name,object_type,created,last_ddl_time from dba_objects where created > to_timestamp(sysdate-7)
and owner not in ('SYS','SYSTEM') order by created desc''',
    '''select NAME, TOTAL_MB,FREE_MB, USABLE_FILE_MB  from v$asm_diskgroup''',
    """SELECT SOFAR BLOCKS_PROCESSED,TOTALWORK TOTAL_WORK,
TOTALWORK-SOFAR TOTAL_WORK_LEFT,START_TIME START_TIME,ROUND((ELAPSED_SECONDS/60),0) ELAPSED_MINUTES,
SUBSTR(MESSAGE,1,33) MESSAGE,USERNAME, ROUND(SOFAR/TOTALWORK*100,2) || '%' "COMPLETED"
FROM GV$SESSION_LONGOPS WHERE TOTALWORK-SOFAR > 0 ORDER BY START_TIME DESC""",
    '''select (SPACE_LIMIT/1024/1024/1024) TOTAL_GB, (SPACE_USED/1024/1024/1024) USED_GB, NUMBER_OF_FILES 
                    from V$RECOVERY_FILE_DEST''',
    '''select name, (bytes/1024/1024/1024) as total from v$datafile where bytes< 2048''',
    '''SELECT trunc (first_time) "Date",
                    to_char (trunc (first_time),'Dy') "Day",
                    sum (decode (to_number (to_char (FIRST_TIME, 'HH24')), 0, 1)) "00",
                    sum (decode (to_number (to_char (FIRST_TIME, 'HH24')), 1, 1)) "01",
                    sum (decode (to_number (to_char (FIRST_TIME, 'HH24')), 2, 1)) "02",
                    sum (decode (to_number (to_char (FIRST_TIME, 'HH24')), 3, 1)) "03",
                    sum (decode (to_number (to_char (FIRST_TIME, 'HH24')), 4, 1)) "04",
                    sum (decode (to_number (to_char (FIRST_TIME, 'HH24')), 5, 1)) "05",
                    sum (decode (to_number (to_char (FIRST_TIME, 'HH24')), 6, 1)) "06",
                    sum (decode (to_number (to_char (FIRST_TIME, 'HH24')), 7, 1)) "07",
                    sum (decode (to_number (to_char (FIRST_TIME, 'HH24')), 8, 1)) "08",
                    sum (decode (to_number (to_char (FIRST_TIME, 'HH24')), 9, 1)) "09",
                    sum (decode (to_number (to_char (FIRST_TIME, 'HH24')), 10, 1)) "10",
                    sum (decode (to_number (to_char (FIRST_TIME, 'HH24')), 11, 1)) "11",
                    sum (decode (to_number (to_char (FIRST_TIME, 'HH24')), 12, 1)) "12",
                    sum (decode (to_number (to_char (FIRST_TIME, 'HH24')), 13, 1)) "13",
                    sum (decode (to_number (to_char (FIRST_TIME, 'HH24')), 14, 1)) "14",
                    sum (decode (to_number (to_char (FIRST_TIME, 'HH24')), 15, 1)) "15",
                    sum (decode (to_number (to_char (FIRST_TIME, 'HH24')), 16, 1)) "16",
                    sum (decode (to_number (to_char (FIRST_TIME, 'HH24')), 17, 1)) "17",
                    sum (decode (to_number (to_char (FIRST_TIME, 'HH24')), 18, 1)) "18",
                    sum (decode (to_number (to_char (FIRST_TIME, 'HH24')), 19, 1)) "19",
                    sum (decode (to_number (to_char (FIRST_TIME, 'HH24')), 20, 1)) "20",
                    sum (decode (to_number (to_char (FIRST_TIME, 'HH24')), 21, 1)) "21",
                    sum (decode (to_number (to_char (FIRST_TIME, 'HH24')), 22, 1)) "22",
                    sum (decode (to_number (to_char (FIRST_TIME, 'HH24')), 23, 1)) "23"
                    from v$log_history
                    where trunc (first_time) >= (trunc(sysdate) - 1) -- last X days. 0 = today only. 1 = today and yesterday
                    group by trunc (first_time)
                    order by trunc (first_time) DESC''',
                    '''select type,status,gap_status from v$archive_dest_status where DEST_ID=2''',
                    '''select username, account_status, expiry_date from dba_users where expiry_date < (sysdate + 7)''',
                    '''select username, account_status, created from dba_users where created > (sysdate - 7) order by created''',
                    '''select user_id,username, default_tablespace,created,profile, account_status from dba_users order by username''',
                    '''select count(*) all_dba_users from dba_users''',
                    """select count(account_status) account_expired from dba_users where account_status like '%EXPIRED%'""",
                    '''select name "db_recovery_file_dest",ceil(space_limit/1024/1024) TOTAL_MB, ceil( space_used /1024/1024) USED_MB,
                        decode( nvl(space_used, 0),0,0,ceil(( space_used /space_limit) * 100)) PERCENTAGE(%)
                        from v$recovery_file_dest
                        order by 1''',
                    '''SELECT (select min(creation_time) from v$datafile) "Create Time", (select name from v$database) "Database Name",
                        ROUND((SUM(USED.BYTES) / 1024 / 1024 ),2) || ' MB' "Database Size",
                        ROUND((SUM(USED.BYTES) / 1024 / 1024 ) - ROUND(FREE.P / 1024 / 1024 ),2) || ' MB' "Used Space",
                        ROUND(((SUM(USED.BYTES) / 1024 / 1024 ) - (FREE.P / 1024 / 1024 )) / ROUND(SUM(USED.BYTES) / 1024 / 1024 ,2)*100,2) || '% MB' "Used in %",
                        ROUND((FREE.P / 1024 / 1024 ),2) || ' MB' "Free Space",ROUND(((SUM(USED.BYTES) / 1024 / 1024 ) - ((SUM(USED.BYTES) / 1024 / 1024 ) - ROUND(FREE.P / 1024 / 1024 )))/ROUND(SUM(USED.BYTES) / 1024 / 1024,2 )*100,2) || '% MB' "Free in %",
                        ROUND(((SUM(USED.BYTES) / 1024 / 1024 ) - (FREE.P / 1024 / 1024 ))/(select sysdate-min(creation_time) from v$datafile),2) || ' MB' "Growth DAY",
                        ROUND(((SUM(USED.BYTES) / 1024 / 1024 ) - (FREE.P / 1024 / 1024 ))/(select sysdate-min(creation_time) from v$datafile)/ROUND((SUM(USED.BYTES) / 1024 / 1024 ),2)*100,3) || '% MB' "Growth DAY in %",
                        ROUND(((SUM(USED.BYTES) / 1024 / 1024 ) - (FREE.P / 1024 / 1024 ))/(select sysdate-min(creation_time) from v$datafile)*7,2) || ' MB' "Growth WEEK",
                        ROUND((((SUM(USED.BYTES) / 1024 / 1024 ) - (FREE.P / 1024 / 1024 ))/(select sysdate-min(creation_time) from v$datafile)/ROUND((SUM(USED.BYTES) / 1024 / 1024 ),2)*100)*7,3) || '% MB' "Growth WEEK in %"
                        FROM (SELECT BYTES FROM V$DATAFILE UNION ALL SELECT BYTES FROM V$TEMPFILE UNION ALL SELECT BYTES FROM V$LOG) USED,
                        (SELECT SUM(BYTES) AS P FROM DBA_FREE_SPACE) FREE GROUP BY FREE.P
                        ''',
                    '''select to_char(creation_time, 'MM-RRRR') "Month", sum(bytes)/1024/1024/1024 "Growth in GB"
                        from sys.v_$datafile where to_char(creation_time,'RRRR')='2022' group by to_char(creation_time, 'MM-RRRR') order by to_char(creation_time, 'MM-RRRR');
                    ''',
                    '''SELECT owner, job_name,status,LOG_DATE, ERROR#, ( EXTRACT (SECOND FROM run_duration) /60 + EXTRACT (MINUTE FROM run_duration) + EXTRACT (HOUR FROM run_duration) * 60 + EXTRACT (DAY FROM run_duration) * 60 * 24) MINUTES,ADDITIONAL_INFO 
                        FROM dba_scheduler_job_run_details
                        WHERE LOG_DATE > SYSDATE - 1 AND status != 'SUCCEEDED' and owner not in ('APEX_030200') ORDER BY 1 ASC, 4 DESC''',
                    '''select name,value from v$dataguard_stats''',
                    '''select name "db_recovery_file_dest",ceil(space_limit/1024/1024) TOTAL_MB, ceil( space_used /1024/1024) USED_MB,
                        decode( nvl(space_used, 0),0,0,ceil(( space_used /space_limit) * 100)) "PERCENTAGE(%)"
                        from v$recovery_file_dest
                        order by 1''',
                    '''select * from (select ss.sql_text,a.SQL_ID,sum(CPU_TIME_DELTA),sum(DISK_READS_DELTA),count(*)
                        from DBA_HIST_SQLSTAT a, dba_hist_snapshot s,v$sql ss where s.snap_id = a.snap_id and a.sql_id=ss.sql_id
                        and s.begin_interval_time > sysdate -1 group by ss.sql_text,a.SQL_ID
                        order by sum(CPU_TIME_DELTA) desc) where rownum < 20''',
                        '''select * from(select sql_text ,buffer_gets,disk_reads,sorts,cpu_time/1000000 cpu_sec,executions,rows_processed
                            from v$sqlstats order by cpu_time DESC) where rownum < 11''',
                    """SELECT SUBSTR (MESSAGE_TEXT, 1, 300) MESSAGE_TEXT, COUNT (*) cnt FROM X$DBGALERTEXT WHERE (MESSAGE_TEXT LIKE '%ORA-%' OR UPPER (MESSAGE_TEXT) LIKE '%ERROR%')
                             AND CAST (ORIGINATING_TIMESTAMP AS DATE) > SYSDATE - 1
                        GROUP BY SUBSTR (MESSAGE_TEXT, 1, 300)""",
                        '''SELECT TO_CHAR (start_time, 'DD-MM-YYYY HH24:MI:SS') start_time, input_type, status, ROUND (elapsed_seconds / 3600, 1) time_hr,INPUT_BYTES/1024/1024/1024 IN_GB,OUTPUT_BYTES/1024/1024/1024 OUT_GB ,OUTPUT_DEVICE_TYPE FROM
                        v$rman_backup_job_details WHERE START_TIME > SYSDATE - 3 ORDER BY start_time DESC''',
                        '''Select owner, object_type, object_name, created, status from dba_objects Where status != 'VALID' and owner not in ('PUBLIC','DBSNMP','GGS','GSMADMIN_INTERNAL','SYS','WMSYS','XDB','AUDSYS','APEX_030200',
                            'FLOWS_FILES','SYSMAN','SYSTEM','DVSYS','CTXSYS','LBACSYS','MDSYS','ORDPLUGINS','ORDSYS')
                            Order by owner, object_type''',
                    """
                        select username, account_status, expiry_date from dba_users where account_status = 'OPEN' and username not in ('SYS','SYSTEM','DBSNMP') and expiry_date < SYSDATE - 31
                    """
                        ]