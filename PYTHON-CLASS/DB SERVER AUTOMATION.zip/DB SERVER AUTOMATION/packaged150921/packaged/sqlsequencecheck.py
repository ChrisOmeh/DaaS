SQLSEQUENCEFIN=[
    '''select (sequence_owner || '.' || sequence_name ) as SequenceName, last_number, MAX_VALUE, CYCLE_FLAG,('Sequence Percentage Usage is : ' || round(last_number / MAX_VALUE, 2) * 100 || '%') as "Percentage Usage" from dba_sequences where sequence_owner in ('TBAADM','CUSTOM','MISUSER')  and last_number / MAX_VALUE >= .90'''
    ]

SQLSEQUENCERDBX=['''select (sequence_owner || '.' || sequence_name ) as SequenceName, last_number, MAX_VALUE, CYCLE_FLAG,('Sequence Percentage Usage is : ' || round(last_number / MAX_VALUE, 2) * 100 || '%') as "Percentage Usage" from dba_sequences where sequence_owner='REDBOX' and last_number / MAX_VALUE >= .90''']

SQLSEQUENCEFIB=['''select (sequence_owner || '.' || sequence_name ) as SequenceName, last_number, MAX_VALUE, CYCLE_FLAG,('Sequence Percentage Usage is : ' || round(last_number / MAX_VALUE, 2) * 100 || '%') as "Percentage Usage" from dba_sequences where sequence_owner IN ('ECECUSER','EBANKUSER') and last_number / MAX_VALUE >= .90''']