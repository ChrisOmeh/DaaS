SYSTEM={"10.234.203.10":["root",'P@ssw0rd',22],
        "10.234.203.11":["root",'P@ssw0rd',22],
        "pngoda5":["root",'sqwer1234',22],
        "pngoda6":["root",'sqwer1234',22]
        }