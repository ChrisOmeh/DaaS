'''
This includes the login details to the database


FORMAT
------
num:{connection_string:{username,password}}
'''

CONFIG={1:{'pngcordb-scan:1521/pngfin':{'SYS':'qwer1234'}},
        2:{'pngcordb-scan:1521/pngrdbox':{'SYS':'qwer1234'}},
        3:{'pngcordb-scan:1521/pngfib':{'SYS':'qwer1234'}},
        4:{'pngcordb-scan:1521/pngesb':{'SYS':'qwer1234'}},
        5:{'pngcordb-scan:1521/pngcem':{'SYS':'qwer1234'}},
        6:{'pngcordb-scan:1521/pngctm':{'SYS':'qwer1234'}},
        7:{'pngcordb-scan:1521/pngitms':{'SYS':'qwer1234'}},
        8:{'pngcordb-scan:1521/pngcog':{'SYS':'qwer1234'}},
        9:{'pngcordb-scan:1521/pngaud':{'SYS':'qwer1234'}},
        10:{'pngcordb-scan:1521/pngpas':{'SYS':'qwer1234'}},
        11:{'pngcordb-scan:1521/pngdtr':{'SYS':'qwer1234'}},
        12:{'pngcordb-scan:1521/pngabank':{'SYS':'qwer1234'}},
        13:{'pngoda5:1521/iconcept.ng.sbicdirectory.com':{'SYS':"SQwer_1234#"}},
        14:{'pngoda5:1521/pngcfm.ng.sbicdirectory.com':{'SYS':"SQwer_1234#"}},
        15:{'pngoda5:1521/pngcapp':{'SYS':"SQwer_1234#"}}}