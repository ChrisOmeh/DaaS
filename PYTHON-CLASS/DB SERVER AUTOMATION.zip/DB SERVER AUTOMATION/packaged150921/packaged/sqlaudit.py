SCRIPTS=["""SELECT USERNAME

            FROM DBA_USERS_WITH_DEFPWD

            WHERE USERNAME NOT LIKE '%XS$NULL%'
            """,

            """SELECT USERNAME

            FROM ALL_USERS

            WHERE USERNAME IN ('BI','HR','IX','OE','PM','SCOTT','SH')"""]