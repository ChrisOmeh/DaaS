SEND_FROM='OSandDBSupport@mail.standardbank.com'
SEND_TO=['michael.okwuwa@stanbicibtc.com',
        'ernest.oduba@stanbicibtc.com',
        'jamiu.afolabi@stanbicibtc.com',
        'chukwuemeka.eze@stanbicibtc.com'
        ]
#PASSWORD='password'

HOST='10.234.174.102'
PORT=25

EMAIL_SUBJECT='DAILY DATABASE SYSTEM CHECKS'

