import databaseconfig

for num,login_details in databaseconfig.CONFIG.items():
        a=login_details
        a=[(x,y) for x,y in a.items()]
        conn_string=a[0][0]
        login=a[0][1]
        login=list(zip(login.keys(),login.values()))[0]
        username,password=login
        print(conn_string)