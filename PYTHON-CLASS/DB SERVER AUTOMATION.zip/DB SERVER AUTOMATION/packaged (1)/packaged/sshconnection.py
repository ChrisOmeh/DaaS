import sysconfiguration
import syscommands
import paramiko
import pandas as pd


def sysTables():
    df_list=[]
    for system,login_details in sysconfiguration.SYSTEM.items():
        host = system
        port = login_details[2]
        username = login_details[0]
        password = login_details[1]

        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        for command in syscommands.COMMANDS:
            try:
                ssh.connect(host, port, username, password,banner_timeout=200)
                stdin, stdout, stderr = ssh.exec_command(command)
            except Exception as err:
                print('There was an error ', err)
            else:
                lines = stdout.readlines()
                new_line=[tuple(line.split()) for line in lines]
                df=pd.DataFrame(new_line)
                columns=df.iloc[0]
                df.columns=columns
                df.drop(index=df.index[0],axis=0,inplace=True)
                if command=='df -h':
                    df.drop('on',axis=1,inplace=True)
                df_list.append(df)

    return df_list


                    
