import csv
import pandas as pd 
import sys
import cx_Oracle
import databaseconfig
import sqlscripts
import sendemail

def sqlScriptRun():
    df_list=[]
    scripts=sqlscripts.SQLSCRIPT
    for num,login_details in databaseconfig.CONFIG.items():
        a=login_details
        a=[(x,y) for x,y in a.items()]
        conn_string=a[0][0]
        login=a[0][1]
        login=list(zip(login.keys(),login.values()))[0]
        username,password=login
        print(conn_string)
        try:
            connection = cx_Oracle.connect(user=username,
                                        password=password,
                                        dsn=conn_string,
                                        encoding='utf-8',
                                        mode=cx_Oracle.SYSDBA
                                        )
        except Exception as err:
            print('There was an error connecting: ', err)
        else:
            for script in scripts:
                # Sql statement needed to be executed
                try:
                    cursor = connection.cursor()
                    r = cursor.execute(script)
                except Exception as err:
                    print('There was an err: ', err)
                else:
                    col_names = [row[0] for row in cursor.description]
                    df = pd.DataFrame(r, columns=col_names)
                    df_list.append(df)

                    #sendemail.sendEmail(html)
        finally:
            cursor.close()
            connection.close()
    return df_list

