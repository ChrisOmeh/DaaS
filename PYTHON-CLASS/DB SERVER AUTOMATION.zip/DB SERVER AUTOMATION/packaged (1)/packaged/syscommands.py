COMMANDS=[
    'hostname',
    'mpstat',
    'free',
    'df -h',
    
]