conn_string=[
    'DRIVER={ODBC Driver 17 for SQL Server};SERVER=10.234.18.215;DATABASE=master;UID=A204778;PWD=P@ssw0rd',
    'DRIVER={ODBC Driver 17 for SQL Server};SERVER=10.234.18.152;DATABASE=master;UID=A204778;PWD=P@ssw0rd',
    'DRIVER={ODBC Driver 17 for SQL Server};SERVER=10.234.18.153;DATABASE=master;UID=A204778;PWD=P@ssw0rd',
    'DRIVER={ODBC Driver 17 for SQL Server};SERVER=10.234.18.23;DATABASE=master;UID=alwayson;PWD=P@ssw0rd',
    'DRIVER={ODBC Driver 17 for SQL Server};SERVER=10.234.18.24;DATABASE=master;UID=alwayson;PWD=P@ssw0rd',
    'DRIVER={ODBC Driver 17 for SQL Server};SERVER=10.234.18.25;DATABASE=master;UID=alwayson;PWD=P@ssw0rd',
    'DRIVER={ODBC Driver 17 for SQL Server};SERVER=10.234.18.26;DATABASE=master;UID=alwayson;PWD=P@ssw0rd',
    'DRIVER={ODBC Driver 17 for SQL Server};SERVER=10.234.18.27;DATABASE=master;UID=alwayson;PWD=P@ssw0rd',
    'DRIVER={ODBC Driver 17 for SQL Server};SERVER=10.234.18.28;DATABASE=master;UID=alwayson;PWD=P@ssw0rd',
    'DRIVER={ODBC Driver 17 for SQL Server};SERVER=10.234.18.29;DATABASE=master;UID=alwayson;PWD=P@ssw0rd',
    'DRIVER={ODBC Driver 17 for SQL Server};SERVER=10.234.18.30;DATABASE=master;UID=alwayson;PWD=P@ssw0rd',
]