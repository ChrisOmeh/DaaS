import sqlalchemy

print(sqlalchemy.__version__)