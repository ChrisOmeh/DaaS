SEND_FROM='OSandDBSupport@mail.standardbank.com'
SEND_TO=['DBA-NG@mail.standardbank.com'
        ]
#PASSWORD='password'

HOST='10.234.174.102'
PORT=25

EMAIL_SUBJECT='DAILY SQL SERVER DATABASE SYSTEM CHECKS'

