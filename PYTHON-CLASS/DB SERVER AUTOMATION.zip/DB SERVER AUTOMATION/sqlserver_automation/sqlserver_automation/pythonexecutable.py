import sqlalchemy

sqlalchemy.__version__