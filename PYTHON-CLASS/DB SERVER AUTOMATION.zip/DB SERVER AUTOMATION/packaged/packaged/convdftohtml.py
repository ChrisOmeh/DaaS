import pandas as pd



def convert(df_list,systable=False):
    '''
    PARAMETERS
    ----------
    df_list: List of Dataframes to be converted to html

    RETURNS
    html_list: List of the Formatted DataFrame
    
    '''
    html_list=[]

    for i,df in enumerate(df_list):
        if systable==False:
            if i==0:
                name=str(df.NAME).split()
                open_mode=str(df.OPEN_MODE).split()
                db_unique_name=str(df.DB_UNIQUE_NAME).split()
                db_unique=db_unique_name[1]
                mode=open_mode[4].strip(',')
                name=name[1]
                html='''
                    <html>
                        <head>
                        </head>
                        <body>
                            <br>
                            <h3>Database Name: {0}</h3>
                            <h3>Unique Name: {1}</h3>
                            <h3>Open State: {2}</h3>
                            <hr>
                        </body>
                    </html>
                    '''.format(name,db_unique,mode)
            else:
                html_tab=df.to_html(classes='table table-striped',index=False)
                html='''\
                    <html>
                        <head>
                            <style>
                            table, th, td {{
                                border: 1px solid black;
                                border-collapse: collapse;
                                }}
                                th, td {{
                                    padding: 5px;
                                    text-align: left;    
                                }}  
                            </style>
                        </head>
                        <body>
                            <br>
                            {0}
                        </body>
                    </html>
                    '''.format(html_tab)
        else:
            if i==0:
                sysheader=df.columns[0]
                html='''\
                    <html>
                        <head>
                        </head>
                        <body>
                            <br>
                            <h3>Hostname: {0}</h3>
                            <hr>
                        </body>
                    </html>
                    '''.format(sysheader)
            elif i==1:
                mems_string=list(df.columns)
                name=''
                new_list=[x for x in mems_string if x!=None]
                name=name.join(new_list)
                df.drop(df.index[0],axis=0,inplace=True)
                df.columns=df.iloc[0]
                df.drop(df.index[0],axis=0,inplace=True)
                df.columns.name=None
                html_tab=df.to_html(classes='table table-striped',index=False)
                html='''\
                    <html>
                        <head>
                            <style>
                            table, th, td {{
                                border: 1px solid black;
                                border-collapse: collapse;
                                }}
                                th, td {{
                                    padding: 5px;
                                    text-align: left;    
                                }}  
                            </style>
                        </head>
                        <body>
                            <br>
                            <h3>{0}</h3>
                            {1}
                        </body>
                    </html>
                    '''.format(name,html_tab)
            elif i==2:
                headers=list(df.columns)
                new_header=[x for x in headers if x!=None]
                new_header.insert(0,'index')
                df.columns=new_header
                html_tab=df.to_html(classes='table table-striped',index=False)
                html='''\
                    <html>
                        <head>
                            <style>
                            table, th, td {{
                                border: 1px solid black;
                                border-collapse: collapse;
                                }}
                                th, td {{
                                    padding: 5px;
                                    text-align: left;    
                                }}  
                            </style>
                        </head>
                        <body>
                            <br>
                            {0}
                        </body>
                    </html>
                    '''.format(html_tab)
            else:
                html_tab=df.to_html(classes='table table-striped',index=False)
                html='''\
                    <html>
                        <head>
                            <style>
                            table, th, td {{
                                border: 1px solid black;
                                border-collapse: collapse;
                                }}
                                th, td {{
                                    padding: 5px;
                                    text-align: left;    
                                }}  
                            </style>
                        </head>
                        <body>
                            <br>
                            {0}
                        </body>
                    </html>
                    '''.format(html_tab)
        html_list.append(html)
        
    return html_list
        


