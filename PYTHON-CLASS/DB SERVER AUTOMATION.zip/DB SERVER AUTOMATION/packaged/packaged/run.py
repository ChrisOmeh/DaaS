import runSqlScript
import convdftohtml
import sshconnection
import newSendemail

if __name__=='__main__':
    sql_list=runSqlScript.sqlScriptRun()
    systab_list=sshconnection.sysTables()

    html_sys_tab_list=convdftohtml.convert(systab_list,systable=True)
    html_sql_list=convdftohtml.convert(sql_list)
    

    newSendemail.sendEmail(html_sys_tab_list,html_sql_list)